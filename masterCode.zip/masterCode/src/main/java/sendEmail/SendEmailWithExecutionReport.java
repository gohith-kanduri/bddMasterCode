package sendEmail;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.SeleniumUtils.SeleniumUtils;
import com.SeleniumUtils.TestDataManager;

import java.util.Date;
import java.util.Properties;

public class SendEmailWithExecutionReport extends SeleniumUtils {

	static TestDataManager _testDataManage = new TestDataManager();

//	public static void main(String[] args) {
//		SendEmailWithExecutionReport demo = new SendEmailWithExecutionReport();
//		demo.sendEmailWithExecutionReport();
//	}

	public void sendEmailWithReport() {
		
		final String from = _testDataManage.getData("SendEmail", "From");
		final String to1 = _testDataManage.getData("SendEmail", "To1");
		final String to2 = _testDataManage.getData("SendEmail", "To2");
		final String subject = _testDataManage.getData("SendEmail", "Subject");
		final String bodyText = _testDataManage.getData("SendEmail", "Body");
	
//		String from = "Krishna.Kotha@thehartford.com";
//		String to = "Nikhil.Tapkir@thehartford.com";
//		String subject = "Automation Test Email4";
//		String bodyText = "Automation Test EMail";

		String attachmentName = System.getProperty("user.dir") + "\\target\\Extent\\Report.html"; 

		Properties props = new Properties();
		props.put("mail.smtp.host", "higmx.thehartford.com");
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.port", "25");
		Session session = Session.getDefaultInstance(props);

		try {
			InternetAddress fromAddress = new InternetAddress(from);
			//InternetAddress toAddress = new InternetAddress(to);
			InternetAddress[] toAddresses = { new InternetAddress(to1),new InternetAddress(to2) };
			MimeMessage msg = new MimeMessage(session);
			msg.setFrom(fromAddress);
			//msg.setRecipient(Message.RecipientType.TO, toAddresses);
			msg.setRecipients(Message.RecipientType.TO, toAddresses);
			msg.setSubject(subject);
			msg.setSentDate(new Date());

			MimeBodyPart messagePart = new MimeBodyPart();
			messagePart.setText(bodyText);

			FileDataSource fileDataSource = new FileDataSource(attachmentName);

			MimeBodyPart attachmentPart = new MimeBodyPart();
			attachmentPart.setDataHandler(new DataHandler(fileDataSource));
			attachmentPart.setFileName(fileDataSource.getName());

			// Create Multipart E-Mail.
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messagePart);
			multipart.addBodyPart(attachmentPart);

			msg.setContent(multipart);
			Transport.send(msg);
			System.out.println("Email has been sent..!");
		} catch (MessagingException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}