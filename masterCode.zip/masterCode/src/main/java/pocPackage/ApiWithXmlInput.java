package pocPackage;

import org.openqa.selenium.WebDriver;
import com.BusinessComponents.Glass_Ascend_NonFL.MyWorkPage;
import com.SeleniumUtils.SeleniumUtils;
import com.SeleniumUtils.TestDataManager;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.Cookie;


/*
 * Configure json jar for this to work - java-json.jar
 */
public class ApiWithXmlInput extends SeleniumUtils {

	public ApiWithXmlInput(WebDriver Browser, TestDataManager testDataManage) {
		this._Browser = Browser;
		this._testDataManage = testDataManage;
	}

	public void xmlPOC() throws Exception {
		String insuredName = _testDataManage.getData("GenericData", "Insured Name");
//		selectXMLPackage(insuredName, "QI");
		String cookieValue = getCookieValue();
//		String riskGuid = executeSearchPOSTCall(cookieValue, insuredName);
		String refNum = executeSearchPOSTCall(cookieValue, insuredName);
		
		_testDataManage.putDatasheet("Ref Num", "GenericData", refNum);
		String storeCheck = _testDataManage.getData("GenericData", "Ref Num");
		if (!storeCheck.equalsIgnoreCase(refNum)) {
			_testDataManage.putDatasheet("Ref Num", "GenericData", refNum);
		}
		
//		String formattedXml = packageXmlPOSTCall(cookieValue, refNum);
//		saveXmlToNotePad(formattedXml);
	}

	public void selectXMLPackage(String insuredName,String status) throws Exception {
		
		MyWorkPage _nMyWorkPage = new MyWorkPage(_Browser, _testDataManage);
		
			_nMyWorkPage.editByNameAndAccountStatus(insuredName, status, "XML - Package");
	}
	
	public String getCookieValue() {
		String cookieValue = ""; 
      	/*
      	 * For loop to get all Cookies of the session appended into a single variable
      	 */
          for(Cookie ck : _Browser.manage().getCookies())							
          {              
              cookieValue = cookieValue + ck.getName()+"="+ck.getValue()+"; ";
              System.out.println(cookieValue);
          } 
          return cookieValue;
	}
	
	public String executeSearchPOSTCall(String cookieValue, String insuredName) throws Exception {		  
		String insuredNameFromResponse = "";
		String riskGuid = "";
		String refNum = "";
		
	        try		
	        {           
	            /*
	             * Prepare request body in JSON format
	             */
	            String rulesPayload = "{'field':'InsuredName','op':'cn','data':'" + insuredName + "'}," +
	            					  "{'field':'RenewingReferenceNumberDisplay','op':'eq','data':'-1'}";
	            		
	            String filtersPayload = "\"{'groupOp':'AND'," +
	            						"'rules':[" + rulesPayload + "]}\"";
	            
	            String payload = "{\"_search\":true, " +
	            				"\"nd\":0," +
	        					"\"rows\":10," + 
	            				"\"page\":1," +
	        					"\"sidx\":\"LastUpdatedDate\"," +
	            				"\"sord\":\"desc\"," +
	        					"\"filters\":" + filtersPayload + "," +
	            				"\"search\":{\"Advanced\":null}}";
	            
	            /*
	             * Execute POST call for Execute Search route
	             */
	            String executeSearchUrl = "http://svusstmapps37q1:8089/Search/ExecuteSearch";
		        URL executeSearchObj = new URL(executeSearchUrl);
		        HttpURLConnection executeSearchCon = (HttpURLConnection) executeSearchObj.openConnection();
		        executeSearchCon.setRequestMethod("POST");
		        executeSearchCon.setRequestProperty("Content-Type", "application/json; utf-8");
		        executeSearchCon.setRequestProperty("Cookie", cookieValue);
		        executeSearchCon.setDoOutput(true);
		        String executeSearchReqBody = payload;
		        
		        OutputStream os = executeSearchCon.getOutputStream();
		            byte[] input = executeSearchReqBody.getBytes("utf-8");
		            os.write(input, 0, input.length); 
		            os.close();		        
		        
		        String searchResponseStatus = executeSearchCon.getResponseMessage();		        
		        System.out.println("Staus code is :" + searchResponseStatus);
		        
		        BufferedReader in = new BufferedReader(new InputStreamReader(executeSearchCon.getInputStream()));
		        String inputLine;
		        StringBuffer searchResponseJSONBody = new StringBuffer();
		        while ((inputLine = in.readLine()) != null) {
		        	searchResponseJSONBody.append(inputLine);
		        }
		        in.close();		        
		        String searchResponseBody = searchResponseJSONBody.toString();		        
		        executeSearchCon.disconnect();          	        
		        
		        JSONObject jsonObject = new JSONObject(searchResponseBody);
		        
		        JSONArray rowsData = jsonObject.getJSONArray("rows");		        
		        System.out.println("Rows data is :" + rowsData);
		        /*
		         * For loop to get the guid of desired Insured Name
		         */
		        for (int i = 0; i < rowsData.length(); ++i) {	        	
		            JSONObject rec = rowsData.getJSONObject(i);
		            insuredNameFromResponse = rec.getString("InsuredName");
		            if (insuredNameFromResponse.equals(insuredName))
		            {
		            	riskGuid = rec.getString("RiskGuid");
		            	refNum = rec.getString("ReferenceNumber");
		            	break;
		            }
		        } 	        
		        
	        }
	        
	        catch(Exception ex)					
	        {		
	            ex.printStackTrace();			
	        }
//	        if (!riskGuid.equals("")) {
//	        	return riskGuid;
//	        }
	        if (!riskGuid.equals("")) {
	        	return refNum;
	        }
	        else {
	        	//Quit Operation
	        	return null;
	        }
	        
	}
	
	public String packageXmlPOSTCall(String cookieValue, String riskGuid) throws Exception {
		  
		try {
			/*
             * Execute POST call to retrieve Package XML
             */
			String packageXmlurl = "http://svusstmapps37q1:8089/Package/PackageXmlFromGuid";
	        URL packageXmlObj = new URL(packageXmlurl);
	        HttpURLConnection packageXmlCon = (HttpURLConnection) packageXmlObj.openConnection();
	        packageXmlCon.setRequestMethod("POST");
	        packageXmlCon.setRequestProperty("Content-Type", "application/json; utf-8");
	        packageXmlCon.setRequestProperty("Accept", "application/xml; utf-8");
	        packageXmlCon.setRequestProperty("Cookie", cookieValue);         
	        packageXmlCon.setDoOutput(true);
	        String guid = "{\"riskGuid\":\"" + riskGuid + "\"" + "}";
	        		        
	        OutputStream os2 = packageXmlCon.getOutputStream();
	            byte[] packageXmlInput = guid.getBytes("utf-8");
	            os2.write(packageXmlInput, 0, packageXmlInput.length); 
	            os2.close();		        
	        
	        String packageXmlResponseStatus = packageXmlCon.getResponseMessage();
	        System.out.println("Staus code is :" + packageXmlResponseStatus);
	        
	        BufferedReader in1 = new BufferedReader(new InputStreamReader(packageXmlCon.getInputStream()));
	        String inputLine1;
	        StringBuffer packageXmlResponseJSONBody = new StringBuffer();
	        while ((inputLine1 = in1.readLine()) != null) {
	        	packageXmlResponseJSONBody.append(inputLine1);
	        }
	        in1.close();
	        
	        String packageXmlResponseBody = packageXmlResponseJSONBody.toString();		        
	        System.out.println("Final response is :" + packageXmlResponseBody); 
	        
	        /*
	         * Code to Format Xml
	         */
	        
	        String formattedXml = prettyFormat(packageXmlResponseBody);
	        System.out.println("Formatted response is :" + formattedXml); 
	        return formattedXml;
		}
		catch(Exception ex)					
        {		
            ex.printStackTrace();	
            return null;
        }
		
	} 	
	
	public static String prettyFormat(String input) {
		return prettyFormat(input, "2");
	}

	public static String prettyFormat(String input, String indent) {
		Source xmlInput = new StreamSource(new StringReader(input));
		StringWriter stringWriter = new StringWriter();
		try {
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, "yes");
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			transformer.setOutputProperty("{https://xml.apache.org/xslt}indent-amount", indent);
			transformer.transform(xmlInput, new StreamResult(stringWriter));
			return stringWriter.toString().trim();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public void saveXmlToNotePad(String textToPaste) throws Exception
	{
		try {			
			String user = _testDataManage.getData("GenericData", "User Space");
			String TestFile = "C:\\Users\\" + user + "\\Documents\\packageXml.txt";
			  File xmlText = new File(TestFile);
			  xmlText.createNewFile();
			  
			  FileWriter FW = new FileWriter(TestFile);
			  BufferedWriter BW = new BufferedWriter(FW);
			  BW.write(textToPaste);		  
			  BW.close();
		}	  
		
		catch (IOException ex) {		 
		 System.out.println(ex);
		 }
	}	
}