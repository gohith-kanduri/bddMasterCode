/*
 * Author - Chandni  Dulani
 * Date - 2-DEC-2020
 * Purpose- Set up the test base. 
 */
package com.TestBase;

import java.net.URL;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.CommonUtills.ExecutionScreenRecorder;
import com.cucumber.listener.Reporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {

	public static WebDriver driver;

	/*
	 * Author - Chandni Dulani Date - 2-DEC-2020 Purpose- Return the Browser based
	 * on selected browser and OS .
	 */
	public static WebDriver selectBrowser(String browser) throws Exception {
		 String scenarioName=  System.getProperty("ScenarioName");
		// ExecutionScreenRecorder.startRecording(scenarioName); //Krishna Kotha; Sep 15 2021, To record the execution flow
		try {

			switch (browser) {
			case "Chrome":
//				String ChromDriverDirectory = System.getProperty("ConfigPath")
//				+ "//BrowserDrivers//ChromeDriver//chromedriver.exe";
//				System.setProperty("webdriver.chrome.driver", ChromDriverDirectory);
				String ChromeBinaryPath = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe";
				DesiredCapabilities dc = new DesiredCapabilities();
				dc.setCapability("chrome.binary", ChromeBinaryPath);
				dc.setCapability("applicationCacheEnabled", false);
				dc.setBrowserName(DesiredCapabilities.chrome().getBrowserName());
				if (System.getProperty("SystemName").equalsIgnoreCase("localhost")) {				
					ChromeOptions options = new ChromeOptions();						
					options.addArguments(new String[] { "--disable-extensions" });
					options.addArguments(new String[] { "test-type" });
					options.addArguments(new String[] { "--no-sandbox" });
					options.addArguments(new String[] { "---printing" });
					options.addArguments(new String[] { "start-maximized" });
					
					//Faisal - Logic for headless execution
//					options.addArguments(new String[] { "--headless" });
//					options.addArguments(new String[] { "--window-size=1920,1080" });
					
					options.setExperimentalOption("useAutomationExtension", false);
					WebDriverManager.chromedriver().clearCache();
//					WebDriverManager.chromedriver().version("91.0.4472.77").setup();
					WebDriverManager.chromedriver().setup();
					driver = new ChromeDriver(options);
					driver.manage().window().maximize();
					driver.manage().deleteAllCookies();
				}else if (System.getProperty("SystemName").equalsIgnoreCase("BrowserStack")) {
					final String AUTOMATE_USERNAME = "krishnakotha1";
					final String AUTOMATE_ACCESS_KEY = "xKkjJKnSqszuracJwUAQ";
					final String URL = "https://" + AUTOMATE_USERNAME + ":" + AUTOMATE_ACCESS_KEY
							+ "@hub-cloud.browserstack.com/wd/hub";
					DesiredCapabilities caps = new DesiredCapabilities();
					caps.setCapability("os_version", "10");
					caps.setCapability("resolution", "1920x1080");
					caps.setCapability("browser", "Chrome");
					caps.setCapability("browser_version", "latest");
					caps.setCapability("os", "Windows");
					caps.setCapability("name", "The Hartfod Automation"); // test name
					caps.setCapability("build", "Build Number 1"); // CI/CD job or build name
					driver = new RemoteWebDriver(new URL(URL), caps);
				}else {
					System.out.println("http://" + System.getProperty("SystemName") + ":" + System.getProperty("PortNo") + "/wd/hub");
					driver = new RemoteWebDriver(
							new URL("http://" + System.getProperty("SystemName") + ":" + System.getProperty("PortNo") + "/wd/hub"), dc);
					driver.manage().window().maximize();
					driver.manage().deleteAllCookies();

				}
				break;
			case "IE":
//				System.setProperty("webdriver.ie.driver",
//						System.getProperty("user.dir") + "/src/main/resources/drivers/IEDriver/IEDriverServer.exe");
				DesiredCapabilities IEcapablities = DesiredCapabilities.internetExplorer();
				IEcapablities.setCapability("nativeEvents", false);
				IEcapablities.setCapability("unexpectedAlertBehaviour", "accept");
				IEcapablities.setCapability("ignoreProtectedModeSettings", true);
				IEcapablities.setCapability("disable-popup-blocking", true);
				IEcapablities.setCapability("enablePersistentHover", true);
				IEcapablities.setCapability("ignoreZoomSetting", true);
				IEcapablities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
						true);
				InternetExplorerOptions options = new InternetExplorerOptions();
				options.merge(IEcapablities);

				WebDriverManager.iedriver().setup();
				driver = new InternetExplorerDriver(options);
				driver.manage().window().maximize();
				break;
			case "Edge":
				String IEEDriverDirectory = System.getProperty("user.dir")
							+ "//src//main//resources//drivers//EdgeDriver//msedgedriver.exe";
				System.setProperty("webdriver.edge.driver", IEEDriverDirectory);
				DesiredCapabilities EdgeCapablities = DesiredCapabilities.edge();
				//					EdgeCapablities.setBrowserName(DesiredCapabilities.edge().getBrowserName());
				if (System.getProperty("SystemName").equalsIgnoreCase("localhost")) {
					//						System.setProperty("webdriver.edge.driver", IEEDriverDirectory);						
//					WebDriverManager.edgedriver().setup();
					driver = new EdgeDriver();
					driver.manage().window().maximize();
					driver.manage().deleteAllCookies();

				} else {
					System.out.println("http://" + System.getProperty("SystemName") + ":" + System.getProperty("PortNo") + "/d/hub");
					driver = new RemoteWebDriver(
							new URL("http://" + System.getProperty("SystemName") + ":" + System.getProperty("PortNo") + "/wd/hub"), EdgeCapablities);

					driver.manage().window().maximize();
				}
				break;
			case "Safari":
				DesiredCapabilities Safaricapablities = DesiredCapabilities.safari();
				Safaricapablities.setBrowserName(DesiredCapabilities.safari().getBrowserName());
				if (System.getProperty("SystemName").equalsIgnoreCase("localhost")) {
					driver = new SafariDriver();
				} else {
					System.out.println("http://" + System.getProperty("SystemName") + ":" + System.getProperty("PortNo") + "/d/hub");
					driver = new RemoteWebDriver(
							new URL("http://" + System.getProperty("SystemName") + ":" + System.getProperty("PortNo") + "/wd/hub"), Safaricapablities);

					driver.manage().window().maximize();
				}
				break;
			case "Firefox":
				if (System.getProperty("SystemName").equalsIgnoreCase("localhost")) {
					System.setProperty("webdriver.gecko.driver",
							System.getProperty("ConfigPath") + "//BrowserDrivers//GeckoDriver//geckodriver.exe");
					try {
						DesiredCapabilities dc1 = new DesiredCapabilities();
						dc1.setCapability("firefox_binay", "C:\\Program Files\\Mozilla Firefox\\firefox.exe");
						dc1.setCapability("marionette", true);
						dc1.setAcceptInsecureCerts(true);
						driver = new FirefoxDriver(dc1);
						System.out.println("Firefox browser has launched");
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					DesiredCapabilities dc1 = DesiredCapabilities.firefox();
					driver = new RemoteWebDriver(
							new URL("http://" + System.getProperty("SystemName") + ":" + System.getProperty("PortNo") + "/wd/hub"), dc1);				
				}
				break;

			default:
				break;
			}
		}catch(WebDriverException WebDriverE) {
			driver = null;
			System.out.println("Error in Creating Web Driver " + WebDriverE.getMessage());
			Reporter.addScenarioLog("Error in Creating Web Driver " + WebDriverE.getMessage());
		}
		return driver;
	}

	public static void markTestStatus(String status, String reason, WebDriver driver) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("browserstack_executor: {\"action\": \"setSessionStatus\", \"arguments\": {\"status\": \""
				+ status + "\", \"reason\": \"" + reason + "\"}}");
	}

}
