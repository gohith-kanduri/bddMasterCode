package com.testRunner;

import com.testRunner.CustomAbstractTestNGCucumberTests;

import cucumber.api.CucumberOptions;

@CucumberOptions(
		features = "src/main/java/com/Features",
		glue = { "com/StepDefinitions" }, 
		plugin = {
				"pretty", 
				"html:target/cucumber-reports/cucumber-pretty", 
				"json:target/cucumber-reports/CucumberTestReport.json",
				"com.cucumber.listener.ExtentCucumberFormatter:target/Extent/Report.html"
				}
//		tags={ "@Smoke,~@Smoke1" }
		)

public class CustomGenericRunner extends CustomAbstractTestNGCucumberTests {

}

/**
 * 1. To create a generic method that will navigate to corr page
 * 2. Use Factory design patter to get the instance of corr page after the navigation
 * */