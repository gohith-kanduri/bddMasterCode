package com.testRunner;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.awt.Desktop;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.CommonUtills.ExecutionScreenRecorder;
import com.Rally.AttachReportForUserStory;
import com.Rally.CreateNewTestCase;
import com.Rally.RunTestCaseAndUpdateTestResults;
import com.SeleniumUtils.DateUtils;
import com.SeleniumUtils.TestDataManager;
import com.cucumber.listener.Reporter;

import cucumber.api.testng.CucumberFeatureWrapper;
import sendEmail.SendEmailWithExecutionReport;

public class CustomAbstractTestNGCucumberTests {
	private CustomTestNGCucumberRunner testNGCucumberRunner;
	public TestDataManager testDataManager = new TestDataManager();	
	@Parameters (
				{	"TestcaseName",
					"TestcaseDescription",
					"ScenarioName",
					"CucumberScenarioName",
					"Browser",
					"SystemName",
					"PortNo",
					"KCD_SubFlag"
				}
			)
	@BeforeClass(alwaysRun = true)
	public void setUpClass(String TestcaseName, String TestcaseDescription, String ScenarioName, 
			String CucumberScenarioName, String Browser, String SystemName, String PortNo, String KCD_SubFlag) throws Exception {
		String scenarioXlsSheetPath = System.getProperty("ApplicationURL") + "\\" + ScenarioName + ".xls";		
		System.setProperty("TestCaseName", TestcaseName);
		System.setProperty("TestcaseDescription", TestcaseDescription);
		System.setProperty("TestScenarioName", ScenarioName);
		System.setProperty("CucumberScenarioName", CucumberScenarioName);
		System.setProperty("Browser", Browser);
		System.setProperty("SystemName", SystemName);
		System.setProperty("PortNo", PortNo);
		System.setProperty("KCD_SubFlag", KCD_SubFlag);
		System.setProperty("TestDataPath", scenarioXlsSheetPath);

		System.out.println(System.getProperty("TestCaseName"));
		System.out.println(System.getProperty("TestcaseDescription"));
		System.out.println(System.getProperty("TestScenarioName"));
		System.out.println(System.getProperty("CucumberScenarioName"));
		System.out.println(System.getProperty("Browser"));
		System.out.println(System.getProperty("SystemName"));
		System.out.println(System.getProperty("PortNo"));
		System.out.println(System.getProperty("TestDataPath"));
		testNGCucumberRunner = new CustomTestNGCucumberRunner(this.getClass());
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
	public void feature(CucumberFeatureWrapper cucumberFeature) {
		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
	}

	/**
	 * @return returns two dimensional array of {@link CucumberFeatureWrapper} objects.
	 */
	@DataProvider
	public Object[][] features() {
		return testNGCucumberRunner.provideFeatures();
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		testNGCucumberRunner.finish();
	}

	@AfterSuite
	public void afterSuite() throws InterruptedException
	{
		System.out.println("Run Complete");
		Reporter.loadXMLConfig(new File("src/main/resources/extent-config.xml"));		
		Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
		Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
		Thread.sleep(4000);
		//attacheReportForRallyUserStory();
		sendEmailWithAttachReport();
		try {
			ExecutionScreenRecorder.stopRecording();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		copyExtentReportToTestResultsFolder();
	}
	
	//Krishna ; 6th Sep 2021
	public void attacheReportForRallyUserStory() {
		try {
			String rallyReportFlag = testDataManager.getData("Rally_TestData", "IntegrateRally");
			String updateTestcaseResult = testDataManager.getData("Rally_TestData", "Update_TestcaseResult");
			
			if (rallyReportFlag.equalsIgnoreCase("Yes")) {
				if (updateTestcaseResult.equalsIgnoreCase("Yes")) {
					AttachReportForUserStory attachReport = new AttachReportForUserStory();
					attachReport.attachExecutionReportForUserStory();
				} else {
					System.out.println("User has given flag as NO, to Run and Update test case results..!");
					Reporter.addStepLog("User has given flag as NO, to Run and Update test case results..!");
				}
			}else {}
		}catch (Exception e) {
			
		}
	}
	//Krishna ; 7th Sep 2021
		public void sendEmailWithAttachReport() {
			try {
				String rallyReportFlag = testDataManager.getData("SendEmail", "DoYouWantToSendEmail");
				if (rallyReportFlag.equalsIgnoreCase("Yes")) {
					SendEmailWithExecutionReport sendEmail = new SendEmailWithExecutionReport();
					sendEmail.sendEmailWithReport();
					} else {
						System.out.println("User has given flag as NO, to Send Email,If you want send Please change Flad as Yes");
						Reporter.addStepLog("User has given flag as NO, to Send Email, If you want send Please change Flad as Yes");
					}
			}catch (Exception e) {
				
			}
		}
	
	private void copyExtentReportToTestResultsFolder() {
		try {
			//getDestinationPath = System.getProperty("OverAllReportPath");
			String getDestinationPath = System.getProperty("user.dir") + "\\TestResults\\";
			getDestinationPath = getDestinationPath.replace("//", "\\");
			System.out.println("Actual time Stamp Destination is " + getDestinationPath);
			String getSourcePath = System.getProperty("user.dir") + "\\target\\Extent\\Report.html";
			getSourcePath = getSourcePath.replace("//", "\\");	
			String destinationFileName = getDestinationPath + System.getProperty("TestScenarioName") + "_"
					+ DateUtils.DateNow() + "_" + DateUtils.TimeNow() + ".html";
			Path from = Paths.get(getSourcePath);
			Path to = Paths.get(destinationFileName);			
			File srcFile = from.toFile();
			File destFile = to.toFile();			
			Files.copy(srcFile.toPath(), destFile.toPath());
			System.out.println("File copied");
			
			File htmlFile = new File(destinationFileName);
			Desktop.getDesktop().browse(htmlFile.toURI());
			
		} catch (Exception e1) {
			System.out.println(e1.getMessage());
		}
	}
}