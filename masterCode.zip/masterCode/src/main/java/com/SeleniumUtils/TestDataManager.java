package com.SeleniumUtils;

//import Report.TestCaseMistmatchException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Map;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;

public class TestDataManager
{
  public static Connection Connection = null;
  public String DbPath = null;
  public String SheetName = null;
  public String TestCase = null;
  public Connection SheduleConnection = null;
  public static Connection ResultConnection = null;
  public HSSFWorkbook wb;
  public HSSFSheet sheet;
  public HSSFRow row;
  public HSSFCell cell;
  public String colName = null;
  public int colIndex;
  public int rowIndex;
  
  
  public String setCurrenttestCaseVal(String currentTestCase) {
	  if ((currentTestCase == null) || (currentTestCase == "")) {
		  currentTestCase = System.getProperty("TestCaseName");
	  }
	  return currentTestCase;
  }
  
  public void setParameters(String testcase, String sheet)
  {
    this.TestCase = testcase;
    this.SheetName = sheet;
  }
  
  public void initialize(String testcase, String sheet, String dbpath)
  {
    try
    {
      if (dbpath.contains("%20")) {
        dbpath = dbpath.replace("%20", "");
      }
      this.DbPath = dbpath;
      setParameters(testcase, sheet);
    }
    catch (Exception ee)
    {
      System.out.println(ee.getMessage());
    }
  }
  
  
  public void setTestCaseParameters(String testcase, String sheet)
  {
//    this.TestCase = testcase;
    this.TestCase = System.getProperty("TestCaseName");
    this.SheetName = sheet;
  }
  
  public void initializeTestData(String testcase, String sheet, String dbpath)
  {
    try
    {
      if (dbpath.contains("%20")) {
        dbpath = dbpath.replace("%20", "");
      }
//      this.DbPath = dbpath;
      this.DbPath = System.getProperty("DBPath");
      setTestCaseParameters(testcase, sheet);
    }
    catch (Exception ee)
    {
      System.out.println(ee.getMessage());
    }
  }
  
  private void getConnected()
  {
    try
    {
    	if (this.DbPath == null) {
    		this.DbPath = System.getProperty("DBPath");
    	}
    	this.wb = new HSSFWorkbook(new FileInputStream(new File(this.DbPath)));      
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      e.printStackTrace();
    }
  }
  
  public String getDatasheet(String colName, String strSheetname)
    throws TestCaseMistmatchException, Exception
  {
	this.TestCase = setCurrenttestCaseVal(this.TestCase);
    String Data = getData1(colName, this.TestCase, strSheetname);
    closeConnection();
    return Data;
  }
  
  public String putDatasheet(String colName, String strSheetname, String strValue)
    throws Exception
  {    
	  
	  System.out.println("put data in" + colName  +" " +strSheetname  +" " +strValue);
	this.TestCase = setCurrenttestCaseVal(this.TestCase);
    initialize(this.TestCase, strSheetname, this.DbPath);
    String Data = putData(colName, this.TestCase, strSheetname, strValue);
    closeConnection();
    return Data;
  }
  
  public String getData1(String colName, String TestCaseName, String SheetName)
    throws TestCaseMistmatchException, Exception
  {
    String Data = "";
    if (this.wb == null) {
      getConnected();
    }
    if (System.getProperty("Region").equalsIgnoreCase("Null")) {
      this.sheet = this.wb.getSheet(SheetName);
    } else {
      this.sheet = this.wb.getSheet(System.getProperty("Region") + "_" + SheetName);
    }
    int rowCount = 0;
    if (System.getProperty("Region").equalsIgnoreCase("Null")) {
      rowCount = getRowIndex(TestCaseName, SheetName);
    } else {
      rowCount = getRowIndex(TestCaseName, System.getProperty("Region") + "_" + SheetName);
    }
    if (rowCount == 0) {
      throw new TestCaseMistmatchException("Test row count return as 0. check the Test case name");
    }
    this.rowIndex = rowCount;
    this.row = this.sheet.getRow(this.rowIndex);
    this.colIndex = getColIndex(colName);
    HSSFCell checkNull = this.row.getCell(this.colIndex, Row.RETURN_BLANK_AS_NULL);
    if (checkNull != null)
    {
      this.row.getCell(this.colIndex).setCellType(1);
      Data = this.row.getCell(this.colIndex).getStringCellValue();
    }
    return Data;
  }
  
  public String putDataReport(String colName, String testCaseName, String sheetname, String strValue)
  {
    try
    {
      if (this.wb == null) {
        getConnected();
      }
      this.sheet = this.wb.getSheet(sheetname);
    }
    catch (Exception e)
    {
      e.getMessage();
    }
    return strValue;
  }
  
  public String putData(String colName, String TestCaseName, String SheetName, String strValue)
  {
    try
    {
      if (this.wb == null) {
        getConnected();
      }
      this.sheet = this.wb.getSheet(SheetName);
      if (this.row == null)
      {
        int rowCount = getRowIndex(TestCaseName, SheetName);
        this.rowIndex = rowCount;
        this.row = this.sheet.getRow(this.rowIndex);
      }
      this.colIndex = getColIndex(colName);
      this.row.createCell(this.colIndex, 1);
      this.row.getCell(this.colIndex).setCellValue(strValue);
      FileOutputStream outfile = new FileOutputStream(new File(this.DbPath));
      this.wb.write(outfile);
      outfile.close();
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
    }
    return strValue;
  }
  
  public int getColIndex(String colName)
  {
    int j = 0;
    int colIndex = 0;
    try
    {
      for (j = this.sheet.getRow(0).getFirstCellNum(); j < this.sheet.getRow(0).getLastCellNum(); j++)
      {
        HSSFCell checkNull = this.sheet.getRow(0).getCell(j, Row.RETURN_BLANK_AS_NULL);
        if ((checkNull != null) && 
          (this.sheet.getRow(0).getCell(j).getStringCellValue().equals(colName)))
        {
          colIndex = j;
          break;
        }
      }
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
    }
    return colIndex;
  }
  
  public int getRowIndex(String TestCase, String strSheetName)
  {
    int rowIndex = 0;
    int rowCount = 0;
    try
    {
      this.sheet = this.wb.getSheet(strSheetName);
      System.out.println(this.sheet.getFirstRowNum());
      System.out.println(this.sheet.getLastRowNum());
      for (rowCount = this.sheet.getFirstRowNum(); rowCount < this.sheet.getLastRowNum(); rowCount++)
      {
        this.row = this.sheet.getRow(rowCount);
        if (this.row == null) {
          break;
        }
        if (this.sheet.getRow(rowCount).getCell(0).getStringCellValue().equals(TestCase)) {
          rowIndex = rowCount;
        }
      }
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
    }
    return rowIndex;
  }
  
  public void closeConnection()
  {
    this.wb = null;
    this.row = null;
  }
  
  public ArrayList<String> GetBusinessComponentList(String TestCaseName) {
		int rowCount = 0;
		int colCount = 0;
		ArrayList<String> arrayListBusinessFlow;
		arrayListBusinessFlow = new ArrayList<String>();
		try {
			getConnected();
			sheet = wb.getSheet(SheetName);
			for (rowCount = sheet.getFirstRowNum(); rowCount < sheet.getLastRowNum(); rowCount++) {

				row = sheet.getRow(rowCount);
				if (row == null) {
					break;
				} else {
					if (getData_main("TC_ID").equals(TestCaseName)) {
						for (colCount = 1; colCount < row.getLastCellNum(); colCount++) {
							HSSFCell checkNull = row.getCell(colCount, Row.CREATE_NULL_AS_BLANK);
							if (checkNull == null) {
								break;
							} else {
								arrayListBusinessFlow.add(checkNull.getStringCellValue());
							}
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			closeConnection();
		}
		return arrayListBusinessFlow;
	}
  public ArrayList<String> getScenariosExecutableDetail(String strSheetName, String ClnName)
  {
    int rowCount = 0;
    
    ArrayList<String> arrayList = new ArrayList();
    getConnected();
    String strjenkinTestName = System.getenv("JenkinComponentName");
    System.out.println("Read strjenkinTestName as : " + strjenkinTestName);
    if (strjenkinTestName == null)
    {
      this.sheet = this.wb.getSheet(strSheetName);
      System.out.println(this.sheet.getFirstRowNum());
      System.out.println(this.sheet.getLastRowNum());
      for (rowCount = this.sheet.getFirstRowNum(); rowCount < this.sheet.getLastRowNum(); rowCount++)
      {
        this.row = this.sheet.getRow(rowCount);
        if (this.row == null) {
          break;
        }
        if (getData_main("Execute").equals("TRUE")) {
          arrayList.add(getData_main(ClnName));
        }
      }
    }
    else
    {
      System.out.println("Else Part strjenkinTestName : " + strjenkinTestName);
      arrayList.add(strjenkinTestName);
    }
    return arrayList;
  }
  
  public ArrayList<String> getExecutableTestCaseWiseData(String strSheetName, String clnName)
  {
    String Data = "";
    
    ArrayList<String> arrayList = new ArrayList();
    int rowCount = 0;
    try
    {
      if (this.wb == null) {
        getConnected();
      }
      this.sheet = this.wb.getSheet(strSheetName);
      System.out.println();
      for (rowCount = this.sheet.getFirstRowNum(); rowCount < this.sheet.getLastRowNum(); rowCount++)
      {
        this.row = this.sheet.getRow(rowCount);
        this.colIndex = getColIndex(clnName);
        if (this.row == null) {
          break;
        }
        this.TestCase = setCurrenttestCaseVal(this.TestCase);
        if (this.row.getCell(0).getStringCellValue().equals(this.TestCase))
        {
          DataFormatter formatter = new DataFormatter();
          HSSFCell checkNull = this.row.getCell(this.colIndex, Row.CREATE_NULL_AS_BLANK);
          if (checkNull == null) {
            Data = " ";
          } else {
            switch (checkNull.getCellType())
            {
            case 1: 
              Data = checkNull.getStringCellValue();
              break;
            case 0: 
              if (DateUtil.isCellDateFormatted(checkNull))
              {
                SimpleDateFormat dateFormat = new SimpleDateFormat("d-MMM-yyyy");
                Data = dateFormat.format(checkNull.getDateCellValue());
              }
              else
              {
                Double value = Double.valueOf(checkNull.getNumericCellValue());
                Long longValue = Long.valueOf(value.longValue());
                Data = new String(longValue.toString());
              }
              break;
            case 4: 
              Data = new String(new Boolean(checkNull.getBooleanCellValue()).toString());
              break;
            case 3: 
              Data = "";
              break;
            }
          }
          arrayList.add(Data);
          System.out.println("Data As per Columns" + Data);
        }
      }
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
    }
    return arrayList;
  }
  
  public ArrayList<String> getExecutableWorksheetData(String strSheetName, String clnName)
  {
    String Data = "";
    
    ArrayList<String> arrayList = new ArrayList();
    int rowCount = 0;
    try
    {
      if (this.wb == null) {
        getConnected();
      }
      this.sheet = this.wb.getSheet(strSheetName);
      System.out.println();
      for (rowCount = this.sheet.getFirstRowNum(); rowCount <= this.sheet.getLastRowNum(); rowCount++)
      {
        this.row = this.sheet.getRow(rowCount);
        this.colIndex = getColIndex(clnName);
        if (this.row == null) {
          break;
        }
//        if (this.row.getCell(0).getStringCellValue().equals(this.TestCase))
//        {
          DataFormatter formatter = new DataFormatter();
          HSSFCell checkNull = this.row.getCell(this.colIndex, Row.CREATE_NULL_AS_BLANK);
          if (checkNull == null) {
            Data = " ";
          } else {
            switch (checkNull.getCellType())
            {
            case 1: 
              Data = checkNull.getStringCellValue();
              break;
            case 0: 
              if (DateUtil.isCellDateFormatted(checkNull))
              {
                SimpleDateFormat dateFormat = new SimpleDateFormat("d-MMM-yyyy");
                Data = dateFormat.format(checkNull.getDateCellValue());
              }
              else
              {
                Double value = Double.valueOf(checkNull.getNumericCellValue());
                Long longValue = Long.valueOf(value.longValue());
                Data = new String(longValue.toString());
              }
              break;
            case 4: 
              Data = new String(new Boolean(checkNull.getBooleanCellValue()).toString());
              break;
            case 3: 
              Data = "";
              break;
            }
          }
          arrayList.add(Data);
          System.out.println("Data As per Columns" + Data);
        }
      //}
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
    }
    return arrayList;
  }
  
  public ArrayList<String> getExecutableDetail(String strSheetName, String ClnName)
  {
    int counter = 1;
    int rowCount = 0;
    System.out.println(strSheetName  +"   strSheetName ");
    ArrayList<String> arrayList = new ArrayList();
    getConnected();
    this.sheet = this.wb.getSheet(strSheetName);
    
    System.out.println(this.sheet  +"  /// strSheetName ");
    for (rowCount = this.sheet.getFirstRowNum(); rowCount < this.sheet.getLastRowNum(); rowCount++)
    {
      this.row = this.sheet.getRow(rowCount);
      if (this.row == null) {
        break;
      }
      if (getData_main("Execute").equals("TRUE")) {
        arrayList.add(getData_main(ClnName));
      }
    }
    return arrayList;
  }
  
  private void setSrNo(int counter, String SheetName, String colName)
  {
    try
    {
      if (this.wb == null) {
        getConnected();
      }
      this.sheet = this.wb.getSheet(SheetName);
      if (this.row == null) {
        this.row = this.sheet.getRow(counter);
      }
      this.colIndex = getColIndex(colName);
      this.row.createCell(this.colIndex, 1);
      this.row.getCell(this.colIndex).setCellValue(String.valueOf(counter));
      FileOutputStream outfile = new FileOutputStream(new File(this.DbPath));
      this.wb.write(outfile);
      outfile.close();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public ArrayList<String> getExecutableDetailForTestCase(String strSheetName, String strTestCaseName, String ClnName)
  {
    int rowCount = 0;
    int counter = 1;
    
    ArrayList<String> arrayList = new ArrayList();
    getConnected();
    this.sheet = this.wb.getSheet(strSheetName);
    for (rowCount = this.sheet.getFirstRowNum(); rowCount < this.sheet.getLastRowNum(); rowCount++)
    {
      this.row = this.sheet.getRow(rowCount);
      if (this.row == null) {
        break;
      }
      if (getData_main("TC_ID").equalsIgnoreCase(strTestCaseName)) {
        arrayList.add(getData_main(ClnName));
      }
    }
    return arrayList;
  }
  
  public String ScenarioData(String strSheetName, String ScenarioName, int Column)
  {
    int rowCount = 0;
    String intParalleCount = null;
    getConnected();
    this.sheet = this.wb.getSheet(strSheetName);
    for (rowCount = this.sheet.getFirstRowNum(); rowCount < this.sheet.getLastRowNum(); rowCount++)
    {
      this.row = this.sheet.getRow(rowCount);
      System.out.println(this.row.getCell(0).getStringCellValue().equals(ScenarioName));
      if (this.row.getCell(0).getStringCellValue().equals(ScenarioName))
      {
        intParalleCount = this.row.getCell(Column).getStringCellValue();
        break;
      }
    }
    closeConnection();
    return intParalleCount;
  }
  
  public String getSanityData(String sheetName, String ColumnName)
  {
    String Data = "";
    return Data;
  }
  
  public String getData(String sheetName, String colName)
  {
    String Data = "";
    try
    {
      if (this.wb == null) {
        getConnected();
      }
      System.out.println(System.getProperty("Region"));
      
      this.sheet = this.wb.getSheet(sheetName);
      this.TestCase = setCurrenttestCaseVal(this.TestCase);
      this.rowIndex = getRowIndex(this.TestCase, sheetName);
      this.row = this.sheet.getRow(this.rowIndex);
      this.colIndex = getColIndex(colName);
      DataFormatter formatter = new DataFormatter();
      HSSFCell checkNull = this.row.getCell(this.colIndex, Row.CREATE_NULL_AS_BLANK);
      if (checkNull == null) {
        Data = "";
      } else {
        switch (checkNull.getCellType())
        {
        case 1: 
          Data = checkNull.getStringCellValue();
          break;
        case 0: 
          if (DateUtil.isCellDateFormatted(checkNull))
          {
            SimpleDateFormat dateFormat = new SimpleDateFormat("d-MMM-yyyy");
            Data = dateFormat.format(checkNull.getDateCellValue());
          }
          else
          {
            Double value = Double.valueOf(checkNull.getNumericCellValue());
            Long longValue = Long.valueOf(value.longValue());
            Data = new String(longValue.toString());
          }
          break;
        case 4: 
          Data = new String(new Boolean(checkNull.getBooleanCellValue()).toString());
          break;
        case 3: 
          Data = "";
        case 2: 
            Data = checkNull.getStringCellValue();
            break;
        }
      }
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
    }
    return Data;
  }
  
  public String getData_main(String _colName)
  {
    String Data = "";
    try
    {
      if (this.wb == null) {
        getConnected();
      }
      this.colIndex = getColIndex(_colName);
      System.out.println(this.colIndex);
      HSSFCell checkNull = this.row.getCell(this.colIndex, Row.CREATE_NULL_AS_BLANK);
      if (checkNull != null)
      {
        this.row.getCell(this.colIndex).setCellType(1);
        Data = this.row.getCell(this.colIndex).getStringCellValue();
        System.out.println(Data);
      }
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
    }
    return Data;
  }
  
  private Connection getSqlConnection(String strConString)
  {
    try
    {
      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      return DriverManager.getConnection(strConString);
    }
    catch (Exception e)
    {
      System.out.println("Error Occurred");
      e.printStackTrace();
      try
      {
        Connection.close();
      }
      catch (SQLException e1)
      {
        e1.printStackTrace();
      }
    }
    return null;
  }
  
  public void UpdateOverallResults(String strBuildNo, String strEnv, String stricName, String strStatus, String exeDateTime, String strSummary)
  {
    ResultConnection = getSqlConnection(
      "jdbc: sqlserver://THDACXSR: 40001; user=reguser;password=reg123;databaseName=Automation_DashBoard;");
    try
    {
      String strQueryNew = "INSERT INTO Automation_DashBoard.dbo.CI_Execution_Results(Build_No, Test CaseName, Status, ExecutionDateTime, HighLevelSummary, MachineName, MachineUser, JenkinsInstance, Environment) Values (" + 
        strBuildNo + ", '" + stricName + "','" + strStatus + "','" + exeDateTime + "', '" + strSummary + 
        "','" + (String)System.getenv().get("COMPUTERNAME") + "','" + (String)System.getenv().get("USERNAME") + "','" + 
        System.getProperty("JenkinsInstance") + "','" + strEnv + "')";
      
      Statement stmt = ResultConnection.createStatement();
      stmt.executeUpdate(strQueryNew);
      stmt.close();
      stmt = null;
      System.out.println("Results written to DB: " + strQueryNew);
    }
    catch (SQLException e)
    {
      e.printStackTrace();
    }
  }
  
  public static void UpadateValuesInSpreadsheet(String strTCName, String strValue1, String strValue2, String strValue3, String strValue4, String strValue5, String strValue6, String strvalue7, String strValue8, String strValue9, String strValue10, String strValue11, String strValue12, String strValue13)
    throws Exception
  {
    FileOutputStream fileOut = null;
    
    String strResultPath = System.getProperty("ResultPath");
    System.out.println(strResultPath);
    String FilePath = strResultPath + "Policyl Detail.xl3";
    File file = new File(FilePath);
    String strTestCaseName = strTCName;
    try
    {
      if (!file.exists())
      {
        fileOut = new FileOutputStream(FilePath);
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet worksheet = workbook.createSheet("PolicyDetails");
        int Rent = worksheet.getPhysicalNumberOfRows();
        
        HSSFRow row1 = worksheet.createRow(0);
        
        HSSFCell cellA1 = row1.createCell((short)0);
        cellA1.setCellValue("SUIPOLFirstName");
        
        HSSFCell cellA2 = row1.createCell((short)1);
        cellA2.setCellValue("SUIPOLLastName");
        
        HSSFCell cellA3 = row1.createCell((short)2);
        cellA3.setCellValue("SUIPOLStAdd");
        
        HSSFCell cellA4 = row1.createCell((short)3);
        cellA4.setCellValue("SUIPOLCity");
        
        HSSFCell cellA5 = row1.createCell((short)4);
        cellA5.setCellValue("SUIPOLState");
        
        HSSFCell cellA6 = row1.createCell((short)5);
        cellA6.setCellValue("SUIPOLPostcode");
        
        HSSFCell cellA7 = row1.createCell((short)6);
        cellA7.setCellValue("SUIPOLPhnllum");
        
        HSSFCell cellA8 = row1.createCell((short)7);
        cellA8.setCellValue("SUIPolNumber");
        
        HSSFCell cellA9 = row1.createCell((short)8);
        cellA9.setCellValue("SUIPoleffectDate");
        
        HSSFCell cellA10 = row1.createCell((short)9);
        cellA10.setCellValue("SUIPolTERM");
        
        HSSFCell cellA11 = row1.createCell((short)10);
        cellA11.setCellValue("SUIPolPremium");
        
        HSSFCell cellA12 = row1.createCell((short)11);
        cellA12.setCellValue("SUIPolDwnPay");
        
        HSSFCell cellA13 = row1.createCell((short)12);
        cellA13.setCellValue("SUIPoligntName");
        
        HSSFCell cellA14 = row1.createCell((short)13);
        cellA14.setCellValue("TestCaseID");
        
        HSSFRow row1V = worksheet.createRow((short)Rent + 1);
        
        HSSFCell cellA1V = row1V.createCell((short)0);
        cellA1V.setCellValue(strValue1);
        
        HSSFCell cellA2V = row1V.createCell((short)1);
        cellA2V.setCellValue(strValue2);
        
        HSSFCell cellA3V = row1V.createCell((short)2);
        cellA3V.setCellValue(strValue3);
        
        HSSFCell cellA4V = row1V.createCell((short)3);
        cellA4V.setCellValue(strValue4);
        
        HSSFCell cellA5V = row1V.createCell((short)4);
        cellA5V.setCellValue(strValue5);
        
        HSSFCell cellA6V = row1V.createCell((short)5);
        cellA6V.setCellValue(strValue6);
        
        HSSFCell cellA7V = row1V.createCell((short)6);
        cellA7V.setCellValue(strvalue7);
        
        HSSFCell cellA8V = row1V.createCell((short)7);
        cellA8V.setCellValue(strValue8);
        
        HSSFCell cellA9V = row1V.createCell((short)8);
        cellA9V.setCellValue(strValue9);
        
        HSSFCell cellA10V = row1V.createCell((short)9);
        cellA10V.setCellValue(strValue10);
        
        HSSFCell cellA11V = row1V.createCell((short)10);
        cellA11V.setCellValue(strValue11);
        
        HSSFCell cellA12V = row1V.createCell((short)11);
        cellA12V.setCellValue(strValue12);
        
        HSSFCell cellA13V = row1V.createCell((short)12);
        cellA13V.setCellValue(strValue13);
        
        HSSFCell cellA14V = row1V.createCell((short)13);
        cellA14V.setCellValue(strTestCaseName);
        
        workbook.write(fileOut);
        fileOut.flush();
        fileOut.close();
      }
      else
      {
        FileInputStream filename = new FileInputStream(new File(FilePath));
        HSSFWorkbook workbook = new HSSFWorkbook(filename);
        HSSFSheet worksheet = workbook.getSheet("Policy_details");
        
        int Rcnt = worksheet.getPhysicalNumberOfRows();
        
        HSSFRow row1V = worksheet.createRow((short)Rcnt + 1);
        
        HSSFCell cellA1V = row1V.createCell((short)0);
        cellA1V.setCellValue(strValue1);
        
        HSSFCell cellA2V = row1V.createCell((short)1);
        cellA2V.setCellValue(strValue2);
        
        HSSFCell cellA3V = row1V.createCell((short)2);
        cellA3V.setCellValue(strValue3);
        
        HSSFCell cellA4V = row1V.createCell((short)3);
        cellA4V.setCellValue(strValue4);
        
        HSSFCell cellA5V = row1V.createCell((short)4);
        cellA5V.setCellValue(strValue5);
        
        HSSFCell cellA6V = row1V.createCell((short)5);
        cellA6V.setCellValue(strValue6);
        
        HSSFCell cellA7V = row1V.createCell((short)6);
        cellA7V.setCellValue(strvalue7);
        
        HSSFCell cellA8V = row1V.createCell((short)7);
        cellA8V.setCellValue(strValue8);
        
        HSSFCell cellA9V = row1V.createCell((short)8);
        cellA9V.setCellValue(strValue9);
        
        HSSFCell cellA10V = row1V.createCell((short)9);
        cellA10V.setCellValue(strValue10);
        
        HSSFCell cellA11V = row1V.createCell((short)10);
        cellA11V.setCellValue(strValue11);
        
        HSSFCell cellA12V = row1V.createCell((short)11);
        cellA12V.setCellValue(strValue12);
        
        HSSFCell cellA13V = row1V.createCell((short)12);
        cellA13V.setCellValue(strValue13);
        
        HSSFCell cellA14V = row1V.createCell((short)13);
        cellA14V.setCellValue(strTestCaseName);
        
        filename.close();
        
        FileOutputStream outFile1 = new FileOutputStream(new File(FilePath));
        workbook.write(outFile1);
      }
    }
    catch (FileNotFoundException e)
    {
      e.printStackTrace();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }
}
