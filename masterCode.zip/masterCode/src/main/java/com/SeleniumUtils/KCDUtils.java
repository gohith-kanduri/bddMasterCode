package com.SeleniumUtils;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFPicture;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.CommonUtills.ConfigFileReader;
import com.StepDefinitions.Hooks;
import com.TestBase.TestBase;

import org.apache.poi.util.Units;

/*
 * Author - Purnendu  Kumar
 * Date - 2-Feb-2021
 * Purpose- Use KCD for every event
 * 
 */

public class KCDUtils extends TestBase{
	
	  public static Hooks hk=new Hooks();
	  public static XWPFDocument doc=hk.doc;

	   public static KCDUtils kcd = new KCDUtils();
	   public static XWPFParagraph page = doc.createParagraph();
	   public static XWPFRun pageRun=null;
	   
		WebElement Element;
		static WebDriverWait wait;
		public TestDataManager  _testDataManage = new TestDataManager();
		protected WebDriver _Browser = null;
		public static  ConfigFileReader configFileReader ;
        static int HeaderCount=1;

		public void updateText(String paraText) {
			pageRun.setText(paraText);

			}
		
		public void addparaBreak(int numberoflines) {		
			for (int i=1;i<=numberoflines;i++) {
				pageRun.addBreak();
			}
		}
		
		public void captureScreenshot(int w,int h) throws AWTException, IOException, InvalidFormatException {
			
			// Take screenshot
	        Robot robot = new Robot();
	        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
	        BufferedImage screenFullImage = robot.createScreenCapture(screenRect);

	        // convert buffered image to Input Stream
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        ImageIO.write(screenFullImage, "jpeg", baos);
	        baos.flush();
	        ByteArrayInputStream bis = new ByteArrayInputStream(baos.toByteArray());
	        
	        baos.close();

	        // add image to word doc    
	        pageRun.addBreak();	       
	        pageRun.addPicture(bis, doc.PICTURE_TYPE_JPEG, "image file", Units.toEMU(w), Units.toEMU(h));
	        
	        bis.close();
		}
		
		
		public void highLighteElement(WebElement element){
			JavascriptExecutor js = (JavascriptExecutor) TestBase.driver;
			js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
			}
		
		public void unHighLighteElement(WebElement element){
			JavascriptExecutor js = (JavascriptExecutor) TestBase.driver;
			js.executeScript("arguments[0].removeAttribute('style', 'background: yellow; border: 2px solid red;');", element);
			}
		
		public static void invokeKCD(String text, int width, int height, WebElement ele) throws InterruptedException, InvalidFormatException, AWTException, IOException {
			String KCDMainFlag=System.getProperty("KCD_Flag");
			String KCDSubFlag=System.getProperty("KCD_SubFlag");
			if(KCDMainFlag.equalsIgnoreCase("YES")) {
				
				if(KCDSubFlag.equalsIgnoreCase("YES")) {
					
					kcd.addparaBreak(1);	
					kcd.updateText(text);
					kcd.highLighteElement(ele);
					
					Thread.sleep(150);
					kcd.captureScreenshot(width,height);
					Thread.sleep(150);
					
					kcd.unHighLighteElement(ele);
					kcd.addparaBreak(1);				
				}
				else
				{
					System.out.println("KCDSubFlag value is: 'NO'. Hence skiping the KCD (Snapshot) generation for " +System.getProperty("TestScenarioName"));
				}			
			}
			else
			{
				System.out.println("KCDMainFlag value is: 'NO'. Hence skiping the KCD (Snapshot) Generation for " +System.getProperty("TestScenarioName"));
			}
			
			
			
		}
		
		public static void KCD_Page(String HeaderName, String PageDetails) {
			KCD_Header(HeaderName);
			
			String KCDMainFlag=System.getProperty("KCD_Flag");
			String KCDSubFlag=System.getProperty("KCD_SubFlag");
			if(KCDMainFlag.equalsIgnoreCase("YES")) {
				
				if(KCDSubFlag.equalsIgnoreCase("YES")) {
					String[] Texts=PageDetails.split("[.]",0);
					for(String PageText:Texts)
					{
						kcd.addparaBreak(1);
						kcd.updateText(PageText +".");
						kcd.addparaBreak(1);
					}
					kcd.addparaBreak(2);
				}
				else
				{
					System.out.println("KCDSubFlag value is: 'NO'. Hence skiping the KCD (Page) Generation for " +System.getProperty("TestScenarioName"));
				}			
			}
			else
			{
				System.out.println("KCDMainFlag value is: 'NO'. Hence skiping the KCD (Page) Generation for " +System.getProperty("TestScenarioName"));
			}	
		}
		
		
		public static void KCD_Scenario() {
			String KCDMainFlag=System.getProperty("KCD_Flag");
			String KCDSubFlag=System.getProperty("KCD_SubFlag");
			if(KCDMainFlag.equalsIgnoreCase("YES")) {
				
				if(KCDSubFlag.equalsIgnoreCase("YES")) {
					
					kcd.addparaBreak(2);
					kcd.updateText("Scenario: " +hk.scenario.getName());
					kcd.addparaBreak(1);				
				}
				else
				{
					System.out.println("KCDSubFlag value is: 'NO'. Hence skiping the KCD (Scenario) Generation for " +System.getProperty("TestScenarioName"));
				}			
			}
			else
			{
				System.out.println("KCDMainFlag value is: 'NO'. Hence skiping the KCD (Scenario) Generation for " +System.getProperty("TestScenarioName"));
			}
	
		}
		
		public static void KCD_Step(String text) {
			String KCDMainFlag=System.getProperty("KCD_Flag");
			String KCDSubFlag=System.getProperty("KCD_SubFlag");
			if(KCDMainFlag.equalsIgnoreCase("YES")) {
				
				if(KCDSubFlag.equalsIgnoreCase("YES")) {
					
					kcd.addparaBreak(1);
					kcd.updateText(text);
					kcd.addparaBreak(2);				
				}
				else
				{
					System.out.println("KCDSubFlag value is: 'NO'. Hence skiping the KCD (Step) Generation for " +System.getProperty("TestScenarioName"));
				}			
			}
			else
			{
				System.out.println("KCDMainFlag value is: 'NO'. Hence skiping the KCD (Step) Generation for " +System.getProperty("TestScenarioName"));
			}

		}
		
		public static void KCD_AppDetails(String HeaderName, String AppDetails) {
			KCD_Header(HeaderName);
			
			String KCDMainFlag=System.getProperty("KCD_Flag");
			String KCDSubFlag=System.getProperty("KCD_SubFlag");
			if(KCDMainFlag.equalsIgnoreCase("YES")) {
				
				if(KCDSubFlag.equalsIgnoreCase("YES")) {
					
					String[] Texts=AppDetails.split("[.]",0);
					for(String PageText:Texts)
					{
						kcd.addparaBreak(1);
						kcd.updateText(PageText +".");
						kcd.addparaBreak(1);
					}
					kcd.addparaBreak(1);
				}
				else
				{
					System.out.println("KCDSubFlag value is: 'NO'. Hence skiping the KCD (AppDetails) Generation for " +System.getProperty("TestScenarioName"));
				}
			
			}
			else
			{
				System.out.println("KCDMainFlag value is: 'NO'. Hence skiping the KCD (AppDetails) Generation for " +System.getProperty("TestScenarioName"));
			}
			
			KCD_Scenario();
	}
		
		public static void KCD_Header(String text) {
			String KCDMainFlag=System.getProperty("KCD_Flag");
			String KCDSubFlag=System.getProperty("KCD_SubFlag");
			System.out.println(KCDMainFlag);
			System.out.println(KCDSubFlag);
			System.out.println(System.getProperty("TestScenarioName"));
			if(KCDMainFlag.equalsIgnoreCase("YES")) {
				
				if(KCDSubFlag.equalsIgnoreCase("YES")) {
					
					page.setAlignment(ParagraphAlignment.LEFT);
				    pageRun = page.createRun();
				    pageRun.setBold(false);
				    pageRun.setFontSize(11);
				    pageRun.setColor("0000FF");
				    pageRun.setFontFamily("Verdana");
				    kcd.addparaBreak(1);
		     	    kcd.updateText(HeaderCount+". " +text);
		     	    kcd.addparaBreak(1);
				
				}
				else
				{
					System.out.println("KCDSubFlag value is: 'NO'. Hence skiping the KCD (Header) Generation for " +System.getProperty("TestScenarioName"));
				}
			
			}
			else
			{
				System.out.println("KCDMainFlag value is: 'NO'. Hence skiping the KCD (Header) Generation for " +System.getProperty("TestScenarioName"));
			}
			HeaderCount++;
		}
		
}
		
