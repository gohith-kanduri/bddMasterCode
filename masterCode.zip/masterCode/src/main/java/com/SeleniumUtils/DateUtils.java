package com.SeleniumUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {
	
	public static String TimeNow()
	  {
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("HH-mm-ss");
	    return sdf.format(cal.getTime());
	  }
	  
	  public static String DateNow()
	  {
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");
	    return sdf.format(cal.getTime());
	  }
	  
	  public static String DateAdd()
	    throws ParseException
	  {
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	    cal.add(2, 2);
	    return sdf.format(cal.getTime());
	  }
	  
	  public static String DateNowForFolder()
	  {
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
	    return sdf.format(cal.getTime());
	  }
	  
	  public static String TimeNowForFolder()
	  {
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("HH-mm-ss");
	    return sdf.format(cal.getTime());
	  }
	  
	  public static Boolean VerifyDateFormat_MM_DD_YYYY(String strDate)
	  {
	    try
	    {
	      SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	      Date dateParsed = sdf.parse(strDate);
	      if (!sdf.format(dateParsed).equals(strDate)) {
	        return Boolean.valueOf(false);
	      }
	      return Boolean.valueOf(true);
	    }
	    catch (ParseException e) {}
	    return Boolean.valueOf(false);
	  }
	  
	  public static Boolean VerifyDateFormat_MM_DD_YY(String strDate)
	  {
	    try
	    {
	      SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
	      Date dateParsed = sdf.parse(strDate);
	      if (!sdf.format(dateParsed).equals(strDate)) {
	        return Boolean.valueOf(false);
	      }
	      return Boolean.valueOf(true);
	    }
	    catch (ParseException e) {}
	    return Boolean.valueOf(false);
	  }
	  
	  public static Boolean VerifyAmountFormatWithDollar(String strAmount)
	  {
	    if (strAmount.startsWith("$")) {
	      strAmount = strAmount.replace("$", "");
	    } else {
	      return Boolean.valueOf(false);
	    }
	    strAmount = strAmount.replace(",", "");
	    if (strAmount.matches("\\d{1, }. \\d\\d))")) {
	      return Boolean.valueOf(true);
	    }
	    return Boolean.valueOf(false);
	  }
}
