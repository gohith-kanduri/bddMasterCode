package com.SeleniumUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.CommonUtills.ConfigFileReader;
import com.TestBase.TestBase;
import com.cucumber.listener.Reporter;
import com.enums.Browsers;

import com.CommonUtills.*;
import com.BusinessComponents.Glass_Ascend_FL.CommonUtils;
import com.BusinessComponents.Glass_Ascend_NonFL.MyWorkPage;
import com.PageObjects.Glass_Ascend_FL_OR.FinancialLinesOR;
import com.PageObjects.Glass_Ascend_NonFL_OR.ApplicationCommonOR;
import com.PageObjects.Glass_Ascend_NonFL_OR.GlassAccountSetupPageOR;
import com.PageObjects.Glass_Ascend_NonFL_OR.GlassSubimission_Objects;


/*
 * Author - Chandni  Dulani
 * Date - 24-NOV-2020
 * Purpose- Contains the Common Function related to Selenium.
 */


public class SeleniumUtils extends TestBase {

	WebElement Element;
	static WebDriverWait wait;
	public TestDataManager  _testDataManage = new TestDataManager();
	protected WebDriver _Browser = null;
	public static  ConfigFileReader configFileReader ;
	
	
	
	public SeleniumUtils()
	{
		this._Browser =TestBase.driver;
	
	}
	
	
	// Added by Krishna 16/04/2019
		public void clickOnEnterKey(By locator)  {
			WebDriverWait webDriverWait = waitforElementToLoadByExplicit();
			webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
			WebElement WEBELEMENT = _Browser.findElement(locator);
			try {
				if (WEBELEMENT != null) {
					WEBELEMENT.sendKeys(Keys.ENTER);
				}
			} catch (Exception e) {
			}
		}
	/*
	 * Author - Chandni  Dulani
	 * Date - 24-NOV-2020
	 * Purpose- Return the WebElement.
	 */
	public static WebElement getLocator(By locator) throws Exception {

		try {
			return  TestBase.driver.findElement(locator);
		}

		catch (Exception ex) {
			//Assert.fail("element not find by locator '" + locator );
			throw new Exception("Unknown locator type '" + locator + "'");
		}
	}

	/*
	 * Author - Chandni  Dulani
	 * Date - 24-NOV-2020
	 * Purpose- Return the  List of WebElement.
	 */
	public static List<WebElement> getLocators(By locator) throws Exception {
		try {
			return  TestBase.driver.findElements(locator);
		} catch (Exception ex) {
			Assert.assertTrue(false);
			//Assert.fail("element not find by locator '" + locator );	
			throw new Exception("Unknown locator type '" + locator + "'");
		}
	}

	/*
	 * Author - Chandni  Dulani
	 * Date - 4-Dec-2020
	 * Purpose- Check  element is enabled  and displayed.
	 * Then click  on the element
	 */
	public static  WebElement isEnabled(By locator) throws Exception {
		
		waitLoader(2);
		WebElement ele = null; 
		try {
			
			implicitWait();
			ele =getLocator(locator);
			System.out.println(ele  +" ele  is enabled");
			if(ele==null)
			{ 
				List<WebElement> list=getLocators(locator);
				if(list.size()>0)
				{
					ele = getLocator(locator);
										
				}
			
			}
		} 
		catch (Exception ex) {
			//Assert.fail("element not enabled '" + ele );
			throw new Exception("element not enabled '" + locator + "'");
			
		}
		return ele;
	}

	/*
	 * Author - Chandni  Dulani
	 * Date - 4-Dec-2020
	 * Purpose-Wait on specify time
	 * 
	 */
	public static  void waitLoader(int count) throws InterruptedException
	{ 
		Thread.sleep(1000*count);
	}
	
	/*
	 * Author - Chandni  Dulani
	 * Date - 4-Dec-2020
	 * Purpose-Select teh Valyue from drop down list
	 * 
	 */
	
	public static void select_List_Text(By locator , String text) throws Exception
	{    
		waitLoader(5);
		WebElement Ele = getLocator(locator);
		Select ListContainer = new Select(Ele);
		ListContainer.selectByVisibleText(text);
     	waitLoader(10);
     	
	}
	
	/*
	 * Author - Chandni  Dulani
	 * Date - 4-Dec-2020
	 * Purpose-Click on the Webelement
	 * 
	 */
	
	public static void clickElement(WebElement ele) throws Exception
	{ 
		try
		{
			waitLoader(5);
			ele.click();
			waitLoader(4);
		}
		catch(Exception ex)
		{
			Assert.fail("element not clickable '" + ele );
		}
	}
	
	
	 
	 
	 public static void OpenApplication1() throws Exception
	 {
		 configFileReader = new  ConfigFileReader() ;
		 String url = configFileReader.getApplicationUrl();
		TestBase.selectBrowser(Browsers.CHROME.name());
		TestBase.driver.get(url);
	 }
	 
	 public static void implicitWait() { 
		 
		 System.out.println((" implicitly wait "));
		 TestBase.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);// channdi : change wait 300 to 60
			 
		}

		public static void explicitWaitToVisibleElement(WebElement element) {
			WebDriverWait webDriverWait = new WebDriverWait(TestBase.driver, 300);
			webDriverWait.until(ExpectedConditions.elementToBeClickable(element));
		}
		

		//Wait for page pre loader -- new  method
			public static void waitforPreLoaderToWait() {
				
				WebDriverWait driverwait = new WebDriverWait(TestBase.driver, 50);
				try {
					driverwait.until(ExpectedConditions.presenceOfElementLocated(GlassSubimission_Objects.RELOADER));
				} catch (Exception e) {
					Assert.fail("Preloader not found'" + GlassSubimission_Objects.RELOADER );
				}
			}
		
///////////////////////////////////////////////////////////////////////////////////////////////////////////////		

			//******* WaitAndSwithcToFrame ********
			public static void WaitAndSwitchToFrame(By frameElement) throws Exception{
				 driver.switchTo().defaultContent();
				 wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameElement));
				}
			
			
			
			/*
			 * Author - Manali Jadhav Date - 15-Dec-2020 Purpose- switch to Frame
			 * 
			 */
			// **********switchToFrame********************//
			public static void switchToFrame(String frameName) {
				try {

					driver.switchTo().frame(frameName);
					System.out.println("Navigated to frame " + frameName);

				} catch (NoSuchFrameException e) {

					System.out.println("Unable to locate frame " + frameName);
				}

				catch (StaleElementReferenceException e) {
					System.out.println("Frame " + frameName + " is not attached to page document ");
				}

				catch (Exception e) {
					Assert.assertTrue(false);
					System.out.println("Unable to navigate to frame " + frameName);
				}
			}

			// ********************switchToDefaultFrame********************************//
			public static void switchToDefaultFrame() {
				try {

					driver.switchTo().defaultContent();
					System.out.println("Navigated back to defaultframe");
				}

				catch (Exception e) {

					System.out.println("Unable to navigate to default frame");
				}
			}
			
			//***************************page Loader**********************//
			
			// ********************************selectDropDownValue**********************************************//

			public static void selectDropDownValue(By locator, String type, String value) throws Exception {

				Select select = new Select(getLocator(locator));
				switch (type) {
				case "value":
					select.selectByValue(value);
					break;

				case "visibleText":
					select.selectByVisibleText(value);
					break;

				case "index":
					select.selectByIndex(Integer.parseInt(value));
					break;

				default:
					System.out.println("Please select correct selection criteria");
				}
			}

			/*
			 * Author - Manali Jadhav Date - 07-Jan-2021 
			 * 
			 */
			// **********************************clickElelment******************************************************//

			public static void clickElement(By locator , String elementName)throws Exception{
					
					WebElement element = isElementLoaded(locator, elementName);
					try {
						if (element != null) {
							System.out.println("Clicking on button.." + elementName);
							element.click();
							System.out.println("Clicked on  button.." + elementName);
				}
					 else {
						System.out.println("Not Clicked on  Element.." + elementName);
					}
				} catch (Exception e) {
					System.out.println("Not Clicked on  Element.." + elementName);
					Assert.assertTrue(false);
					
				}
			}

			// ********************************ElementLoaded************************************************//

			public static WebElement isElementLoaded(By elemennt,String elementName) {
				waitforPreLoaderToWait();
				WebElement ele = null;
				//System.out.println("Waiting for element to appear on DOM.. "+elementName);
				for (int i = 1; i <= 5; i++) {
					try {
						if(i==4){
							System.out.println("50 seconds waited for " +elemennt+" but not found, hence closing the browser..!");
							Assert.assertTrue(false);
						}
						List<WebElement> list = TestBase.driver.findElements(elemennt);
						if(list.size() > 0) {
							ele = TestBase.driver.findElement(elemennt);
							//System.out.println("Element found ready to Click.." + elementName);
							break;
						}else {
							System.out.println("Waiting for-->"+elemennt+" :" +i+ ": time");
							Thread.sleep(10000);
						}
					} catch (Exception e) {
						try {
							System.out.println("Searched element in DOM  " + i+ " times for the "+elemennt+" but not found");
							Thread.sleep(10000);
							Assert.assertTrue(false);
						} catch (InterruptedException e1) {

						}
					}
				}
				return ele;
			}	
			
			
			//Krishna Kotha; 6th Sep 2021
			public  WebElement isActionsButtonEnable(By elemennt,String insuredName,String elementName) {
				waitforPreLoaderToWait();
				WebElement element = null;
				for (int i = 1; i <= 6; i++) {
					try {
						List<WebElement> list = TestBase.driver.findElements(elemennt);
						if(list.size() > 0) {
							element = TestBase.driver.findElement(elemennt);
							break;
						}else {
							Thread.sleep(10000);
							TestBase.driver.findElement(By.id("gs_InsuredName")).clear();
							TestBase.driver.findElement(By.id("gs_InsuredName")).sendKeys(insuredName);	
						}
					} catch (Exception e) {
						try {
							System.out.println("Searched element in DOM  " + i+ " times for the "+elemennt+" but not found");
							Thread.sleep(10000);
						} catch (InterruptedException e1) {

						}
					}
				}
				return element;
			}


			//************************************enterInputText************************************************************//
			
			public static boolean enterInputTextvalue(By locator, String value) throws Exception {
				
				WebElement WEBELEMENT = isElementLoaded(locator, value);

				try {
					if (WEBELEMENT != null) {
						System.out.println("Entering text as --" + value);
					 
						WEBELEMENT.sendKeys(value);
						System.out.println("Entered text as -- " + value);
						
						return true;
					} else {
						System.out.println("Not Entered text as -- " + value);
						
						return false;
					}
				} catch (Exception e) {
					System.out.println("Not Entered text as -- " + value);
					Assert.assertFalse(true);
					return false;
				}
			}

	// ===========================Migrated Method ================================================================
			
			public boolean waitForTheElementToBeLoad(By By, String elementName) throws Exception {
				WebElement elm = isElementLoaded(By,elementName);
				try {
					if (elm != null && elm.isDisplayed()) {
						return true;
					} else {
						Reporter.addStepLog(" Element should be Present"+elementName);
						if ("Account Setup".equals(elementName)) {
							System.setProperty("Access Issue", "No AccountSetup Link Found)");

						}
						return false;
					}
				} catch (Exception e) {
					
					Reporter.addStepLog(" Element not  Present"+elementName );
					Assert.assertFalse(true);
					return false;
				}
			}
			
						
			public boolean clickOnElementWithWebElement(By By, String elementName)  {
				waitforPreLoaderToWait();
				WebElement element = isElementLoaded(By, elementName);
				try {
					if (element != null) {
						System.out.println("Clicking on button.." + elementName);
						Reporter.addStepLog("Clicking on button.." + elementName);
						element.click();
						System.out.println("Clicked on  button.." + elementName);
						Reporter.addStepLog("Clicked on button.." + elementName);
						
						return true;
					} else {
						System.out.println("Not Clicked on  Element.." + elementName);
						Reporter.addStepLog(" Not Clicked on button.." + elementName);
						
						return false;
					}
				} catch (Exception e) {
					System.out.println("Not Clicked on  Element.." + elementName);
					Reporter.addStepLog(" Not Clicked on button.." + elementName);
					Assert.assertFalse(true);
					return false;
				}
			}

			
			
			public void hitGivenURL(String action, String url) {
				if (!url.equals(" ") && !url.equals(null)) {
					System.out.println("open  given URL.." + url);					
					_Browser.get(url);
					System.out.println("open given URL.." + url);
					
				} else {
				}
			}

			
			public String getTextFromElement(By by,String elementName) throws Exception{
				waitForTheElementToBeLoad(by, elementName);
				System.out.println("Getting text from"+ elementName);
				Reporter.addStepLog("Getting text from"+ elementName);
				String text = _Browser.findElement(by).getText();
				System.out.println("Text: "+ text);
				return text;
			}
			
			
			
			public void waitForPageToLoadByCounter(int counter) {
				try {
					//System.out.println("Waiting for the Elelment by counter method"+ counter);
					Thread.sleep(counter * 100);
					//System.out.println("Waiting time out for the Element"+ counter);

				} catch (Exception e) {
					Assert.assertTrue(false);
				}
			}
			public void waitforElementToLoadByCounter(int counter) {
				try {
					Thread.sleep(counter * 1000);
				} catch (Exception e) {
					Assert.assertTrue(false);
				}
			}
			
			
			
			
			public void clickOnCheckBoxToUnCheck(By elm,String checkBoxName) {
				WebDriverWait webDriverWait = waitforElementToLoadByExplicit();
				webDriverWait.until(ExpectedConditions.elementToBeClickable(elm));
				waitforElementToLoadByCounter(30);
				WebElement elment = _Browser.findElement(elm);
				try {
					System.out.println("Clicking on check box to uncheck");
					if (elment != null) {
						boolean isDisplayed = isElementDisplayed(elm);
						boolean isSelected = elment.isSelected();

						if (isDisplayed == true  & isSelected == true ) {
							Actions a = new Actions(_Browser);
							a.moveToElement(elment);
							a.click().build().perform();
							System.out.println("Clicked on check box to uncheck"+ checkBoxName);
							Reporter.addStepLog("Clicked on check box to uncheck"+ checkBoxName);
						} else {
							Reporter.addStepLog("User should be able to Click on" + checkBoxName);
							Reporter.addStepLog("User clicked on" + checkBoxName);
						}
					}
				} catch (Exception e) {
					System.out.println("User should be able to Click on" + checkBoxName+
							"User clicked on" + checkBoxName);
					Reporter.addStepLog("User should be able to Click on" + checkBoxName);
					Reporter.addStepLog("User clicked on" + checkBoxName);
					Assert.assertTrue(false);
					
				}
			}
			
			public WebDriverWait waitforElementToLoadByExplicit() {
				//System.out.println("Waiting for Elemment by Explicitwait up to-->" + 100 +"seconds");
				WebDriverWait webDriverWait = new WebDriverWait(_Browser, 100);
				//System.out.println("Waiting time out by Explicitwait up to-->" + 100 +"seconds");
				return webDriverWait;
			}
			
			
			
			public boolean isElementDisplayed(By elm){
				WebElement element = _Browser.findElement(elm);
				boolean isDisplayed= true;
				try{
					isDisplayed = element.isDisplayed();
				}catch (NoSuchElementException | ElementNotVisibleException e) {
					isDisplayed =false;
				}
				return isDisplayed;
			}
			

			// Added by Krishna 16/04/2019
			public void clickOnTabKey(By locator)  {
				WebDriverWait webDriverWait = waitforElementToLoadByExplicit();
				webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
				WebElement WEBELEMENT = _Browser.findElement(locator);
				try {
					if (WEBELEMENT != null) {
						WEBELEMENT.sendKeys(Keys.TAB);
					}
				} catch (Exception e) {
					Assert.assertTrue(false);
				}
			}

			
			
			
			public void clickOnCheckBoxToCheck(By elm,String checkBoxName) {
				WebDriverWait webDriverWait = waitforElementToLoadByExplicit();
				webDriverWait.until(ExpectedConditions.elementToBeClickable(elm));
				waitforPreLoaderToWait();
				WebElement elment = _Browser.findElement(elm);
				try {
					System.out.println("Clicking on check box to check" + checkBoxName);
					if (elment != null) {
						boolean isDisplayed = isElementDisplayed(elm);
						boolean isEnabled = elment.isEnabled();
						boolean isSelected = elment.isSelected();

						if (isDisplayed == true & isEnabled == true & isSelected == false ) {
							clickOnElementWithJavaScriptExecutor(elm,"");
							System.out.println("Clicked on check box to check" + checkBoxName);
							Reporter.addStepLog("User should be able to Click on" + checkBoxName);
							Reporter.addStepLog("User clicked on" + checkBoxName);
							
						} else {
							
						}
					}
				} catch (Exception e) {
					Assert.assertTrue(false);
				}
			}
			
			
			
			public void clickOnElementWithJavaScriptExecutor(By By,String elementName) {
				WebDriverWait webDriverWait = waitforElementToLoadByExplicit();
				webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By));
				webDriverWait.until(ExpectedConditions.elementToBeClickable(By));
				WebElement elm1 = _Browser.findElement(By);
				try {
					if (elm1 != null) {
						System.out.println("Clicking on Elelment with JavaScript Executer.." + elementName);
						JavascriptExecutor executor = (JavascriptExecutor) _Browser;
						executor.executeScript("arguments[0].click();", elm1);
						System.out.println("Clicked on Elelment with JavaScript Executer.." + elementName);
						Reporter.addStepLog("Clicking on Elelment with JavaScript Executer.." + elementName);
						
					} else {
						System.out.println("Not clicked on Element  -->" + elementName);
						Reporter.addStepLog("Not clicked on Element  -->" + elementName);
					}
				} catch (Exception e) {
					System.out.println("Not Clicked on  Elelment with JavaScript Executer.." + elementName);
					Reporter.addStepLog("Not Clicked on  Elelment with JavaScript Executer.." + elementName);
					Assert.assertTrue(false);
				}
			}
			
		public boolean enterInputTextvalue(By locator, String value, String action)
			{
				
				WebElement WEBELEMENT = isElementLoaded(locator, action);

				try {
					if (WEBELEMENT != null) {
						System.out.println("Entering text as --" + value);
						WEBELEMENT.clear(); 
						WEBELEMENT.sendKeys(value);
						System.out.println("Entered text as -- " + value);
						Reporter.addStepLog("Entered text as -- " + value);
						return true;
					} else {
						System.out.println("Not Entered text as -- " + value);
						Reporter.addStepLog("Not Entered text as -- " + value);
						return false;
					}
				} catch (Exception e) {
					System.out.println("Not Entered text as -- " + value);
					Reporter.addStepLog("Not Entered text as -- " + value);
					Assert.assertTrue(false);
					return false;
				}
			}

		
		public boolean enterInputTextvalueByJavaScript(By locator, String value, String action
				)  {
			JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) _Browser;
			/*WebDriverWait webDriverWait = waitforElementToLoadByExplicit();
			webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
			waitforElementToLoadByFluentWait(locator);
			waitforPreLoaderToWait();
			WebElement WEBELEMENT = _Browser.findElement(locator);*/
			WebElement WEBELEMENT = isElementLoaded(locator, action);
			try {
				if (WEBELEMENT != null) {
					clearText(locator, "Clear Text");
					System.out.println("Entering text with Javascript Executer as-->" + value);
					Reporter.addStepLog("Entered Text with Javascript executer as -->" + value);
					javaScriptExecutor.executeScript("arguments[0].value='" + value.trim() + "';", WEBELEMENT);
					System.out.println("Entered Text with Javascript executer as -->" + value);
					Reporter.addStepLog("Entered Text with Javascript executer as -->" + value);
					return true;
				} else {
					System.out.println("Not Entered Text with Javascript executer as -->" + value);
					Reporter.addStepLog("Not Entered Text with Javascript executer as -->" + value);
					return false;
				}
			} catch (Exception e) {
				System.out.println("Not Entered Text with Javascript executer as -->" + value);
				Reporter.addStepLog("Not Entered Text with Javascript executer as -->" + value);
				Assert.assertFalse(true);
				return false;
			}
		}
		
		
		public boolean clearText(By locator, String action) {
			WebDriverWait webDriverWait = waitforElementToLoadByExplicit();
			webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
			WebElement WEBELEMENT = _Browser.findElement(locator);
			try {
				if (WEBELEMENT != null) {
					System.out.println("Clearing Text in  --" + action);
					WEBELEMENT.clear();
					Reporter.addStepLog("Clearing Text in  --" + action);
					System.out.println("Cleared Text in-- " + action);
					return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				Reporter.addStepLog("Clearing Text in catch  --" + action);
				Assert.assertFalse(true);
				return false;
			}
		}
		
		
		public void selectDropDownValuesByEnteringText(String dataValue, By elment, By textBoxElement, String strElm,
				String valueName) throws Exception  {
			implicitWait();
			System.out.println("Selecting dropdown by entering text..");
			Reporter.addStepLog("Selecting dropdown by entering text .."+dataValue +" == " +valueName);
			if (dataValue != null) {
				waitForTheElementToBeLoad(elment, valueName);
				if ("Underwriter".equals(valueName)) {
					waitForPageToLoadByCounter(20);
				}
				clickOnElementWithActions(elment, valueName);
				waitForTheElementToBeLoad(textBoxElement, valueName);
				waitforElementToLoadByFluentWait(textBoxElement);
				switch (valueName) {
				case "Insured Product":
					enterInputTextvalueByJavaScript(textBoxElement, dataValue, "Enter Insured Product");
					break;
				case "Broker":
					enterInputTextvalue(textBoxElement, dataValue, "Enter Broker ");
					break;
				case "Underwriter":
					enterInputTextvalueByJavaScript(textBoxElement, dataValue, "Enter Underwriter");
					break;
				case "Insured Name":
					enterInputTextvalueByJavaScript(textBoxElement, dataValue, "Enter Insured Name ");
					break;
				case "State":
					enterInputTextvalueByJavaScript(textBoxElement, dataValue, "Enter State");
					break;
				case "Three Letter":
					enterInputTextvalueByJavaScript(textBoxElement, dataValue, "Enter Three Letter Code");
					break;
				case "Broker Contact":
					enterInputTextvalue(textBoxElement, dataValue, "Enter Broker contact");
					break;
				default:
					enterInputTextvalue(textBoxElement, dataValue, "Enter Value");
					break;
				}
				if ("Insured Name".equals(valueName)) {
					_Browser.findElement(textBoxElement).sendKeys(Keys.SPACE);
				}
				if ("Broker".equals(valueName)) {
					waitForPageToLoadByCounter(10);
				}
				if ("Broker Contact".equals(valueName)) {
					waitForPageToLoadByCounter(50);
				}
				WebElement selectionElement;
				if ("Marine".equals(dataValue.trim())) {
					selectionElement = getExactXpathPathAfterStringFormatting(
							GlassAccountSetupPageOR.INSURED_RESULT_DUPLICATE_VALUE, dataValue);
				}else {
					selectionElement = getExactXpathPathAfterStringFormatting(strElm, dataValue);
				}
				waitforPreLoaderToWait();
				implicitWait();
				waitForPageToLoadByCounter(10);
				clickOnElementWithWebElement(selectionElement, valueName);
				// clickOnButton(textBoxElement, "Button");
			}
		}

		public WebElement getExactXpathPathAfterStringFormatting(String locator, String value) {
			By byFinalLocator = null;
			try {
				System.out.println("Adding "+value+ " to" + locator );
				Reporter.addStepLog("Adding "+value+ " to" + locator );
				String getFinalLocator = String.format(locator, value);
				byFinalLocator = By.xpath(getFinalLocator);
				System.out.println("Added "+value+ " to" + locator );
				Reporter.addStepLog("Added "+value+ " to" + locator );
			} catch (Exception e) {
				Assert.assertTrue(false);
			}
			return _Browser.findElement(byFinalLocator);
		}
		
		
		public boolean clickOnElementWithWebElement(WebElement WebElement, String elementName)  {
			try {
				if (WebElement != null) {
					System.out.println("Clicking on button.." + elementName);
					Reporter.addStepLog( "Clicking on button.." + elementName );
					WebElement.click();
					System.out.println("Clicked on  button.." + elementName);
					Reporter.addStepLog( "Clicking on button.." + elementName );
					return true;
				} else {
					System.out.println("Not Clicked on  Element.." + elementName);
					Reporter.addStepLog( "Not Clicked on button.." + elementName );
					return false;
				}
			} catch (Exception e) {
				System.out.println("Not Clicked on  Element.." + elementName);
				Reporter.addStepLog( "Not Clicked on button.." + elementName );
				Assert.assertFalse(true);
				return false;
			}
		}
		
		
		public void clickOnElementWithActions(By By,String elementName) {
			waitforPreLoaderToWait();
			WebElement elm = isElementLoaded(By, elementName);
			//WebElement elm = _Browser.findElement(By);
			System.out.println("Clicking on Elelemnt:" + elementName);
			for (int i = 0; i < 10; i++) {
				waitforPreLoaderToWait();
				try {
					if (elm != null) {
						Actions a = new Actions(_Browser);
						a.moveToElement(elm);
						a.click().build().perform();
						System.out.println("Clicked on Elelemnt:" + elementName);
						Reporter.addStepLog( "Clicked on element with Action.." + elementName );
						break;
					} else {
						System.out.println("Not clicked on Element  -->" + elementName);
						Reporter.addStepLog( "Not Clicked on element with Action.." + elementName );
					}
				} catch (Exception e) {
					System.out.println("Not able to click on" + elementName);
					Reporter.addStepLog( "Not Able to Clicked on .." + elementName );
					Assert.assertTrue(false);
				}
			}
		}
		
		
		public boolean waitforElementToLoadByFluentWait(By locator) {
			boolean isflag = false;
			Wait<WebDriver> wait = new FluentWait<WebDriver>(_Browser)
//					.withTimeout(40, TimeUnit.SECONDS)//Decapreated
//					.pollingEvery(5, TimeUnit.SECONDS)//Decapreated
					.withTimeout(Duration.ofSeconds(100))
					.pollingEvery(Duration.ofSeconds(5))
					.ignoring(NoSuchElementException.class);
			WebElement elm = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			try {
				if (elm != null) {
					isflag = true;
				} else {
					isflag = false;
				}

			} catch (Exception e) {
				Assert.assertTrue(false);
			}
			return isflag;
		}
		
		public void presenceofElement(By locator)  {
			WebDriverWait webDriverWait = waitforElementToLoadByExplicit();
			webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
		}
		
		public void scrollingByElement(By by){
			waitForPageToLoadByCounter(50);
			JavascriptExecutor js = (JavascriptExecutor) _Browser;
			WebElement element =_Browser.findElement(by);
			System.out.println("Scrolling bar untill Element found..!");
			Reporter.addStepLog( "Scrolling bar untill Element found..!");
			js.executeScript("arguments[0].scrollIntoView();", element);
			System.out.println("Scrolling Done..! Element found:");
			Reporter.addStepLog( "Scrolling Done..! Element found:");
		}
		
		
		public String getElementClass(By element){
			return _Browser
					.findElement(element).getAttribute("class");
		}
		//Krishna Kotha; Date:17-Aug-2020
		public String getElementValue(By element){
			return _Browser
					.findElement(element).getAttribute("value");
		}
		//Krishna Kotha; Date:17-Aug-2020
		public boolean isAttribtuePresent(By by, String attribute) {
			Boolean result = false;
			WebElement element = isElementLoaded(by, "");
			try {
				String value = element.getAttribute(attribute);
				if (value != null){
					result = true;
				}
			} catch (Exception e) {
				Assert.assertTrue(false);
			}

			return result;
		}  
		
		
		public void selectDropDownByIndex(int index,By by,String elementName ) {
			WebElement elm = isElementLoaded(by, elementName);
			if (elm != null) {
				System.out.println("Selecting dropdown by By.." + elementName);
				Select select = new Select(elm);
				select.selectByIndex(index);
				implicitWait();
				System.out.println("Selected dropdown by By.." + elementName);
			}
		}
		
		
		public void selectDropDownValueByPreceedingText(String inputText, String precedingText) {

			String dropDownElement = ApplicationCommonOR.DROP_DOWN_XPATH;
			By textBoxElement = ApplicationCommonOR.DROP_DOWN_TEXTBOX_XPATH;
			String dropDownList = ApplicationCommonOR.DROP_DOWN__LIST_XPATH;

			try{
				WebElement finalDropDownElement = getExactXpathPathAfterStringFormatting(dropDownElement, precedingText);
				if (inputText != null) {
					clickOnElementWithActions(finalDropDownElement, precedingText);
					enterInputTextvalue(textBoxElement, inputText, "Enter Value");
					WebElement selectionElement = getExactXpathPathAfterStringFormatting(dropDownList, inputText);
					clickOnElementWithWebElement(selectionElement, precedingText);
				}
			}catch (Exception e) {
				Assert.assertTrue(false);
				e.printStackTrace();
			}
		}
		
		public void clickOnElementWithActions(WebElement element,String elementName) {
			waitforPreLoaderToWait();
			implicitWait();
			System.out.println("Clicking on Elelemnt:" + elementName);
			for (int i = 0; i < 10; i++) {
				waitforPreLoaderToWait();
				try {
					if (element != null) {
						Actions a = new Actions(_Browser);
						a.moveToElement(element);
						a.click().build().perform();
						System.out.println("Clicked on Elelemnt:" + elementName);
						Reporter.addStepLog("Clicked on Elelemnt:" + elementName);
						break;
					} else {
						System.out.println("Not clicked on Element  -->" + elementName);
						Reporter.addStepLog(" Not Clicked on Elelemnt:" + elementName);
					}
				} catch (Exception e) {
					System.out.println("Not able to click on" + elementName);
					Reporter.addStepLog(" Not Clicked on Elelemnt:" + elementName);
					Assert.assertTrue(false);
				}
			}
		}
		
		
		public void selectDropDownValuesWithoutEnteringText(String dataValue, By dropDownElement, String strElm
				) throws Exception {
			implicitWait();
			System.out.println("Selecting dropdown by entering text..");
			Reporter.addStepLog("Selecting dropdown by entering text..");
			clickOnElementWithActions(dropDownElement, dataValue);
			waitForPageToLoadByCounter(20);
			WebElement selectionElement=getExactXpathPathAfterStringFormatting(strElm, dataValue);

			waitforPreLoaderToWait();
			implicitWait();
			waitForPageToLoadByCounter(10);
			clickOnElementWithWebElement(selectionElement, dataValue);
		}
		public String getDayfromDate(String value) {
			System.out.println("Getting day from date");
			Reporter.addStepLog("Getting day from date");
			String strArray[] = value.split(" ");
			System.out.println("Returened day from Date");
			Reporter.addStepLog("Returened day from Date");
			return strArray[0].trim();
		}
		
		public int getHeaderCountByValue(String headercolumn, List<WebElement> elm) {
			implicitWait();
			waitForPageToLoadByCounter(20);
			int colIndex = -1;
			int counter = 0;
			System.out.println("Counting  Column Index for.."+headercolumn);
			Reporter.addStepLog("Counting  Column Index for..\"+headercolumn");
			for (Iterator<WebElement> iterator = elm.iterator(); iterator.hasNext();) {
				counter++;
				WebElement webElement = iterator.next();
				String getHeaderName = webElement.getText();
				if (getHeaderName.equals(headercolumn)) {
					colIndex = counter;
					break;
				}
			}
			System.out.println("Header Column Index of " +headercolumn+" = "+ counter);
			Reporter.addStepLog("Header Column Index of " +headercolumn+" = "+ counter);
			return colIndex;
		}
		
		
		public void selectDropDownByVisibleText(String dataValue, By by)  {
			try {
				waitForTheElementToBeLoad(by, "Select tag");
				System.out.println("Selecting dropdown by visiblity text.." + dataValue);
				WebElement elm = isElementLoaded(by, "");
				if (elm != null) {
					Select select = new Select(elm);
					select.selectByVisibleText(dataValue);
					implicitWait();
					System.out.println("Selected dropdown by Locator.." + dataValue);
					Reporter.addStepLog("Selected dropdown by Locator.." + dataValue);
				} else {
				}
			} catch (Exception e) {
				Assert.assertTrue(false);
				//pendinh
			}
		}

		
		public boolean verifyText(String expectedText){
			
			
			implicitWait();
			waitForPageToLoadByCounter(50);
			System.out.println("Verifyong given text: " +expectedText);
			Reporter.addStepLog("Verifyong given text: " +expectedText);
			String pageSource = _Browser.getPageSource();
			boolean b= pageSource.contains(expectedText);
			System.out.println("Verified text Result is : " +b);
			Reporter.addStepLog("Verified text Result is : " +b);
			return b;
		}
		

		public String getTodayDate() {
			SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yy");  
			Date date = new Date();  
			String todayDate =  formatter.format(date);
			return todayDate;
		}

		
		// Author Krishna Kotha Date:20 June 2019s
		public String getTodayDay() {
			System.out.println("Getting today date..");
			java.util.Date date = new java.util.Date();
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			System.out.println("Returened today date..");
			int day = calendar.get(Calendar.DAY_OF_MONTH);
			return Integer.toString(day);
		}
		
		
		public String getFutureDate(int numberOfDays) {
			System.out.println("Entering Valid Until Date: ");
			SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy hh:mm:ss");
			Calendar cal = Calendar.getInstance();
			System.out.println("Current Date: " + sdf.format(cal.getTime()));
			Reporter.addStepLog("Current Date: " + sdf.format(cal.getTime()));
			cal.add(Calendar.DAY_OF_MONTH, numberOfDays);
			String newDate = sdf.format(cal.getTime());
			System.out.println("Entered Valid Until Date as: " + newDate);
			Reporter.addStepLog("Entered Valid Until Date as: " + newDate);
			return newDate;
		}
		
		
		public void selectDropDownByValue(String dataValue, By loBy, String elementName) {
			try{
				waitForTheElementToBeLoad(loBy, elementName);
				System.out.println("Selecting dropdown by  Value.." + elementName);
				WebElement elm = _Browser.findElement(loBy);
				if (elm != null) {
					Select select = new Select(elm);
					select.selectByValue(dataValue);
					implicitWait();
					System.out.println("Selected dropdown by value.." + elementName);
					Reporter.addStepLog("Selected dropdown by value.." + elementName);
					
				} else {
				}
			} catch (Exception e) {
				Assert.assertTrue(false);
			}
		}
		
		
		public void doubleClickOnElement(By By, String elementName) {
			WebDriverWait webDriverWait = waitforElementToLoadByExplicit();
			webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By));
			WebElement elm = _Browser.findElement(By);
			try {
				if (elm != null) {
					System.out.println("Double clicking on -->" + elementName);
					Reporter.addStepLog("Double clicking on -->" + elementName);
					Actions a = new Actions(_Browser);
					a.doubleClick(elm).build().perform();
					System.out.println("Double clicked on -->" + elementName);
					Reporter.addStepLog("Double clicked on -->" + elementName);
					
				} else {
					System.out.println("Not clicked on -->" + elementName);
					Reporter.addStepLog("Not Double clicked on -->" + elementName);
				}
			} catch (Exception e) {
				System.out.println("Not Clicked on  Element.." + elementName);
				Reporter.addStepLog("Not Double clicked on -->" + elementName);
				Assert.assertTrue(false);
			}
		}
		
		public void explicitWaitToClickAnElement(WebElement element) {// Krishna 26-March-2020
			WebDriverWait webDriverWait = new WebDriverWait(_Browser, 40);
			webDriverWait.until(ExpectedConditions.elementToBeClickable(element));
		}
		
		
		
		public void explicitWaitToClickAnElement(By by) {// Krishna 26-March-2020
			/*WebElement element = _Browser.findElement(by);
			WebDriverWait webDriverWait = new WebDriverWait(_Browser, 40);
			webDriverWait.until(ExpectedConditions.elementToBeClickable(element));*/
		}
		
		
		public String getReferenceNumber(String ref) {
			String referenceNo = null;
			String submisssionType = _testDataManage.getData("GenericData", "SubmissionType");
			String application = _testDataManage.getData("GenericData", "Application");
			String subRunTimeFlag = _testDataManage.getData("RunControlFlag", "VentSubRunTime");
			CommonUtils commonUtilsObj= new  CommonUtils(TestBase.driver,_testDataManage);
			if (!"Delete Submission In Progress".equals(submisssionType)) {
				try {
					System.out.println("Saving Reference Number..");
					waitForPageToLoadByCounter(60);
//					if (!"GLASS".equals(application)) {
//						scrollingByElement(ApplicationCommonOR.STATUS_TEXT);
//					}
					waitForPageToLoadByCounter(50);
					List<WebElement> elm = _Browser.findElements(GlassAccountSetupPageOR.HEADER_NAME);
					int getStatusIndex = getHeaderCountByValue(ref, elm);
					System.out.println("Reference Number header is " + getStatusIndex);
					String getActualString = String.format(GlassAccountSetupPageOR.STATUS_STRING, getStatusIndex);
					By xpathString = By.xpath(getActualString);
					WebElement elment = _Browser.findElement(xpathString);
					if (elment != null) {
						referenceNo = elment.getText();
						if ("Ref Num".equals(ref.trim())) {
							System.out.println("Reference Number is" + referenceNo);
							Reporter.addStepLog("Reference Number is" + referenceNo);
							//Krishna Kotha; 21-Sep-2021; Excel sheet name changed from GenricData to RunControlFlag
							_testDataManage.putDatasheet("NAVRefNumber", "GenericData", referenceNo);
							_testDataManage.putDatasheet("NAVRefNumber", "RunControlFlag", referenceNo);
//							commonUtilsObj.checkInputInExSheet("GenericData", "NAVRefNumber", referenceNo);
							System.out.println("Reference stored in NAVRefNumber Column ..");
							Reporter.addStepLog("Reference stored in NAVRefNumber Column .." + referenceNo);
							
//							if(subRunTimeFlag.equalsIgnoreCase("No")) {
//								System.out.println("Reference stored in Related Policy Number Column ..");
//								_testDataManage.putDatasheet("Related Policy Number", "AcctSummary", referenceNo);
////							commonUtilsObj.checkInputInExSheet("AcctSummary", "Related Policy Number", referenceNo);
//								System.out.println("Reference stored in Related Policy Number Column ..");
//								Reporter.addStepLog("Reference stored in Related Policy Number Column .." + referenceNo);
//							}
							
						} else {
							System.out.println("reference Number Saved-->" + referenceNo);
							Reporter.addStepLog("reference Number Saved-->" + referenceNo);
							_testDataManage.putDatasheet("GlassRefNumber", "GenericData", referenceNo);
//							commonUtilsObj.checkInputInExSheet("GenericData", "GlassRefNumber", referenceNo);
							System.out.println("Reference stored in GlassRefNumber Column ..");
							Reporter.addStepLog("Reference stored in GlassRefNumber Column ..");
						}
					}
				} catch (Exception e) {
					e.getMessage();
					Assert.assertTrue(false);
				}
			}
			return referenceNo;
		}
		
		
		public void explicitWaitToVisibleAllElements(WebElement element) {// Krishna 26-March-2020
			WebDriverWait webDriverWait = new WebDriverWait(_Browser, 40);
			webDriverWait.until(ExpectedConditions.visibilityOfAllElements(element));
		}

		
		public boolean moveToElementByLocator(WebElement locator, By subLocator, String elementName) {
			WebElement elm = _Browser.findElement(subLocator);
			try {
				if (locator != null) {
					System.out.println("Clicking on sub Elelment.." + elementName);
					Reporter.addStepLog("Clicking on sub Elelment.." + elementName);
					Actions a = new Actions(_Browser);
					a.moveToElement(locator).perform();
					waitForTheElementToBeLoad(subLocator, elementName);
					a.moveToElement(elm);
					a.click().build().perform();
					System.out.println("Clicked on Elelment.." + elementName);
					Reporter.addStepLog("Clicking on  Elelment.." + elementName);
					
					return true;
				}  else {
					System.out.println("Not clicked on subElement  -->" + elementName);
					Reporter.addStepLog("Not Clicking on  Elelment.." + elementName);
					return false;
				}
			} catch (Exception e) {
				System.out.println("Not Clicked on Sub Element " + elementName);
				Reporter.addStepLog("Not Clicking on  Elelment.." + elementName);
				Assert.assertTrue(false);
				return false;
			}
		}
		
		
		
		/* Description: Closing Alert. due to if the alert is opened, Installments tab,Rating Overview tab and 
		Forms and Endorsement tab not able to click by automation*/
		public void closeAlertPopup() {
			implicitWait();
			List<WebElement> ele = _Browser.findElements(ApplicationCommonOR.CLOSE_ALERT);
			int size = ele.size();
			try {
				for (int i = 0; i <= size; i++) {
					List<WebElement> alerts = _Browser.findElements(ApplicationCommonOR.CLOSE_ALERT);
					boolean status2 = alerts.get(i).isDisplayed();
					boolean status1 = alerts.get(i).isEnabled();
					if (status1 && status2) {
						refreshPage();
						
						break;
					}
				}
			} catch (Exception e) {
				System.out.println("No Alert is present");
			}
		}
		
		//Krishna Kotha; Date:Feb-12-2020
		public void refreshPage() {
			System.out.println("Refresshing the Page..");
			_Browser.navigate().refresh();
			System.out.println("Refreshed the Page..");
		} 
		
		public void clickOnLinkByText(String textToClick,String stringWebElement)  {
			implicitWait();
			try {
				if (stringWebElement != null) {
					System.out.println("Clicking on element -->" + textToClick);
					waitforPreLoaderToWait();
					waitForPageToLoadByCounter(30);
					String getScenarioTabString = String.format(stringWebElement, textToClick);
					By xpathGetScenarioTab = By.xpath(getScenarioTabString);
					waitforPreLoaderToWait();
					clickOnElementWithWebElement(xpathGetScenarioTab,textToClick);
					implicitWait();
					waitForPageToLoadByCounter(60);
					System.out.println("Clicked on element -->" + textToClick);
					
				}else {
					System.out.println("Not clicked on -->" + textToClick);
				}
			} catch (Exception e) {
				System.out.println("Not Clicked on element -->" + textToClick);
				Assert.assertTrue(false);
			}
		}  
		
		
		public boolean waitForTheElementListToBeLoad(By WEBELEMENT, String action) throws Exception {
			WebElement elm = IsElementsPresentorNotForList(WEBELEMENT, action);
			try {
				if (elm != null) {
					return true;
				} else {
					
					return false;
				}
			} catch (Exception e) {
				// TODO: handle exception
				Assert.assertTrue(false);
				return false;
			}
		} 
		
		
		private WebElement IsElementsPresentorNotForList(By Locator, String action) {
			WebDriverWait webDriverWait = null;
			try {
				webDriverWait = waitforElementToLoadByExplicit();
				webDriverWait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(Locator));
			} catch (Exception e) {
				
				return null;
			}
			return _Browser.findElement(Locator);
		}
		
		
		//Krishna Kotha; Date:12-Feb-2020
		public String getElementTitle(By element){
			return  _Browser.findElement(element)
					.getAttribute("title");
		}
		
		public void selectDropDownValueByVisibleText(String dataValue, By loBy) throws Exception {
			try {
				waitForTheElementToBeLoad(loBy, "Select tag");
				System.out.println("Selecting dropdown by visiblity text.." + dataValue);
				WebElement elm = _Browser.findElement(loBy);
				if (elm != null) {
					Select select = new Select(elm);
					select.selectByVisibleText(dataValue);
					implicitWait();
					System.out.println("Selected dropdown by Locator.." + dataValue);
					Reporter.addStepLog("User  Selected " + dataValue);
				} else {
					Reporter.addStepLog("User to Select " + dataValue);
				}
			} catch (Exception e) {
				Reporter.addStepLog("User to Select " + e.getMessage());
				Assert.assertTrue(false);
			}
		}
		

		//Krishna Kotha; Date:18-Aug-2020
		public By convertStringToWebElement(String stringElement, String inputText) {
			String getScenarioTabString = String.format(stringElement, inputText);
			By element = By.xpath(getScenarioTabString);
			return element;
		}
		//Krishna Kotha; Date:18-Aug-2020
		public By convertStringToWebElement(String stringElement, int inputText) {
			String getScenarioTabString = String.format(stringElement, inputText);
			By element = By.xpath(getScenarioTabString);
			return element;
		} 
		
		
		public void selectDropDownValueFromTableWithWebElement(By elm, By elmTextBox, By elm3, String value) {
			try {
				System.out.println("Selecting dropdown value from Table.." + value);
				clickOnElementWithActions(elm,value);
				clickOnElementWithJavaScriptExecutor(elm,value);
				waitForTheElementToBeLoad(elmTextBox, "Class code");
				enterInputTextvalue(elmTextBox, value, "class Code");
				waitForPageToLoadByCounter(5);
				clickOnElementWithWebElement(elm3,value);
				System.out.println("Selected dropdown value from Table.." + value);
			} catch (Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false);
			}
		} 
		
		
		
		public void selectDropDownValueFromTable(By elm, By elmTextBox, By elm3, String value) {
			try {
				System.out.println("Selecting dropdown value from Table.." + value);
				//clickOnElementWithActions(elm,value);
				clickOnElementWithJavaScriptExecutor(elm,value);
				waitForTheElementToBeLoad(elmTextBox, "Class code");
				enterInputTextvalue(elmTextBox, value, "class Code");
				waitForPageToLoadByCounter(5);
				clickOnElementWithWebElement(elm3,value);
				System.out.println("Selected dropdown value from Table.." + value);
			} catch (Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false);
			}
		}
		
		
		public int getTodaysDay() {
			System.out.println("Getting today date..");
			java.util.Date date = new java.util.Date();
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			System.out.println("Returened today date..");
			return calendar.get(Calendar.DAY_OF_MONTH);
		}

	
		public void selectDateByFromAndTo(By elm, String dataValue, String elm2, By elm1, String action) {
			try {
				System.out.println("Selecting date by From and To.. ");
				waitForTheElementToBeLoad(elm, action);
				int startDateAndEndDate = getTodaysDay();
				clickOnElementWithWebElement(elm,"Date");
				waitForPageToLoadByCounter(10);
				String getActualTodayDateXpath = String.format(elm2, startDateAndEndDate);
				By xpathTodayDate = By.xpath(getActualTodayDateXpath);
				WebElement webElementTodayDate = _Browser.findElement(xpathTodayDate);
				if (webElementTodayDate != null) {
					_Browser.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					// need to Write - 27/06/2018
					clickOnElementWithWebElement(xpathTodayDate,"Today Date");
					System.out.println("Selected date by From and To");
				}
				waitForPageToLoadByCounter(10);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				Assert.assertTrue(false);
			}

		}
		
		
		//Krishna Kotha; Date:18-Aug-2020
		public void clickOnLinkByPreceedingText(String preceedingText,String stringWebElement) {
			implicitWait();
			try {
				if (stringWebElement != null) {
					System.out.println("Clicking on element -->" + preceedingText);
					waitforPreLoaderToWait();
					waitForPageToLoadByCounter(30);
					String getScenarioTabString = String.format(stringWebElement, preceedingText);
					By xpathGetScenarioTab = By.xpath(getScenarioTabString);
					waitforPreLoaderToWait();
					clickOnElementWithWebElement(xpathGetScenarioTab,preceedingText);
					implicitWait();
					waitForPageToLoadByCounter(60);
					System.out.println("Clicked on element -->" + preceedingText);
					
				}else {
				}
			} catch (Exception e) {
				Assert.assertTrue(false);
			}
		}
		 
		// Krishna Kotha
		public String getCurrentMonth() {
			String[] monthName = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
			Calendar cal = Calendar.getInstance();
			String month = monthName[cal.get(Calendar.MONTH)];
			System.out.println("Month name: " + month);
			return month;
		}  
		
		
		//Krishna Kotha ,March-23-2020
		public void handleGenerateDocsOKBtn(String status) throws Exception {
			String eName = _testDataManage.getData("GenericData", "EName");
			String _tlCode = _testDataManage.getData("GenericData", "Three Letter code");
			String insuredName ;
			String scenarioName = System.getProperty("ScenarioName");
			waitForPageToLoadByCounter(30);
			if ("ASCEND_EnvMonitoring".equalsIgnoreCase(scenarioName)  || "GLASS_EnvMonitoring".equalsIgnoreCase(scenarioName)) {
				insuredName = eName + "_SMOKE_" + _tlCode + "_" + getTodayDate();
			}else{
				insuredName = _testDataManage.getData("GenericData", "Insured Name");
			}
			MyWorkPage _nMyWorkPage = new MyWorkPage(_Browser,_testDataManage);
			
//			waitForPageToLoadByCounter(2000); //Added temporarily
			waitforElementToLoadByCounter(20);
			//int size = _Browser.findElements(ApplicationCommonOR.CONTINUEBTNDOC).size();
			boolean b = _Browser.getPageSource().contains("Continue");
			if (b == true) {
				_Browser.findElement(ApplicationCommonOR.CONTINUEBTNDOC).click();
				///waitforElementToLoadByCounter(10);
				refreshPage();
				presenceofElement(ApplicationCommonOR.ACTION_BTN);//checking for PIP failing for PCP,PNP,PHO
				waitforElementToLoadByFluentWait(ApplicationCommonOR.ACTION_BTN);
				_nMyWorkPage.editByNameAndAccountStatus(insuredName, status, "Document Review");
			} else {
				System.out.println("Document Review Page opened No need to click on Continue buttton..");
			}
		} 
		
		public void enterKey(){
			Actions action = new Actions(_Browser);
			action.sendKeys(Keys.ENTER);
		}
		
		
		
		public void clickOnBackSpace(By element) {
			_Browser.findElement(element).sendKeys(Keys.BACK_SPACE);
		}

		public void clickOnSpace(By element) {
			_Browser.findElement(element).sendKeys(Keys.SPACE);
		}
		
		
		
		//Krishna Kotha 17-Aug-2020
		public boolean isElementEnabled(By by) {
			WebElement element = _Browser.findElement(by);
			boolean isEnabled= true;
			try{
				isEnabled = element.isEnabled();
			}catch (NoSuchElementException | ElementNotVisibleException e) {
				isEnabled =false;
			}
			return isEnabled;

		} 
		
		
		
		//Krishna Kotha ,March-23-2020
		public void handleReleaseBtn() throws Exception {
			waitForPageToLoadByCounter(500);
			boolean b = _Browser.getPageSource().contains("View Your Accounts");
			System.out.println("View Your Accounts Button available true/false to click :"+ b);
			if (b == true) {
				try{
					_Browser.findElement(ApplicationCommonOR.VIEW_YOUR_ACCOUNTS).click();
				}catch (Exception e) {
					System.out.println("No Need to click on View Your Accounts Button..!");
				}
				waitForPageToLoadByCounter(80);
			}
		}
		
		
		public String verifyMethodExecutedOrNot(int rowIndex){
			ExcelUtils utils = new ExcelUtils();
			String result = null;
			String execution = "Executed" ;
			try{
				String referenceNumber1 = _testDataManage.getData("RunControlFlag", "GlassRefNumber").substring(0, 12);
				String referenceNumber2 = utils.getData("MethodExecution", rowIndex, 2);

				if (referenceNumber1.equals(referenceNumber2)) {
					result = utils.getData("MethodExecution", rowIndex, 3);
					if ("No".equals(result)) {
						execution = "NotExecuted";
					}
				}else{
					utils.putData(rowIndex,"MethodEecutedOrNot", "No");
					execution = "NotExecuted";
				}
			}catch (Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false);
			}
			return  execution;
		}
		
		
		public void clearDropDownSelection(By elm) {
			try {
				WebElement selectElm = _Browser.findElement(elm);
				System.out.println("Clearing Dropdown..");
				if (selectElm != null) {
					Select select = new Select(selectElm);
					select.deselectAll();
					System.out.println("Cleared Dropdown..");
				}
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Exception..");
				Assert.assertTrue(false);
			}
		} 
		
		public int getHeaderCountById(String headercolumn, List<WebElement> elm) {
			implicitWait();
			waitForPageToLoadByCounter(20);
			//System.out.println("Header Count starting.. ");
			int colIndex = -1;
			int counter = 0;
			for (Iterator<WebElement> iterator = elm.iterator(); iterator.hasNext();) {
				counter++;
				WebElement webElement = iterator.next();
				//String getHeaderName = webElement.getText();
				String getHeaderName = webElement.getAttribute("id");
				if (getHeaderName.equals(headercolumn)) {
					colIndex = counter;
					break;
				}
				//System.out.println("Header count returned.." + counter);
			}
			return colIndex;
		}
		
		public boolean isTextAvailable(String expectedText){
			implicitWait();
			waitForPageToLoadByCounter(50);
			System.out.println("Verifyong given text: " +expectedText);
			String pageSource = _Browser.getPageSource();
			boolean b= pageSource.contains(expectedText);
			System.out.println("Verified text Result is : " +b);
			return b;

		}
		
		public void explicitWaitToVisibleElementByXpath(By element) {// Gohith Kanduri 16-August-2020
			WebDriverWait webDriverWait = new WebDriverWait(_Browser, 250);
			webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(element));
		}
		
		public void selectDropDownValueByLocator(String dataValue, By loBy, String dropdown) throws Exception {
			try{
				waitForTheElementToBeLoad(loBy, dropdown);
				System.out.println("Selecting dropdown by  Value.." + dropdown);
				WebElement elm = _Browser.findElement(loBy);
				if (elm != null) {
					Select select = new Select(elm);
					select.selectByValue(dataValue);
					implicitWait();
					System.out.println("Selected dropdown by value.." + dropdown);
//					_objDetailedReport.WriteLog(Status.PASS, "User should be able to Select as : " + dataValue,
//							"User  Selected" + dataValue, null);
				} else {
//					_objDetailedReport.WriteLog(Status.FAIL, "User should be able to Select" + dataValue,
//							"User NOT  Selected as : " + dataValue, null);
				}
			} catch (Exception e) {
				Assert.assertTrue(false);
//				_objDetailedReport.WriteLog(Status.FAIL, "User should be able to Select" + dataValue,
//						"User to Select" + e.getMessage(), null);
			}
		}
		
		public void selectDropDownValueBytext(String text, By elm) {
			try {
				WebElement selectElm = _Browser.findElement(elm);
				System.out.println("Selecting dropdown by text.." + text);
				if (selectElm != null) {
					Select select = new Select(selectElm);
					select.selectByVisibleText(text);
					System.out.println("Selected dropdown by text.." + text);
				}
			} catch (Exception e) {
				Assert.assertTrue(false);
				// TODO: handle exception
			}
		}
		
		//Nikhil Tapkir Date:8th march 2021
		public boolean enterInputTextvalueByWebelement(WebElement element, String value, String action)
				throws Exception {
			System.out.println("Values are is " + value);
			waitforPreLoaderToWait();
			try {
				if (element != null) {
					System.out.println("Entering text as --" + value);
					element.clear();
					element.sendKeys(value);
					System.out.println("Entered text as -- " + value);
					Reporter.addStepLog("Entered " + action + " value is " + value);
					return true;
				} else {
					System.out.println("Not Entered text as -- " + value);
					Reporter.addStepLog("Entered " + action + " value is " + value);
					return false;
				}
			} catch (Exception e) {
				System.out.println("Not Entered text as -- " + value);
				Reporter.addStepLog("Entered " + action + " value is " + value);
				Assert.assertTrue(false);
				return false;
			}
		}
		
		public void selectDropDownValueBy(String dataValue, By loBy) {
			WebElement elm = _Browser.findElement(loBy);
			if (elm != null) {
				System.out.println("Selecting dropdown by By.." + dataValue);
				Select select = new Select(elm);
				select.selectByIndex(6);
				implicitWait();
				System.out.println("Selected dropdown by By.." + dataValue);
			}
		}
		//Nikhil Tapkir;06-May-2021
		public void validateTheElementPresent(String WebElement, String elementName) throws Exception {
			String elementXpath= String.format(WebElement, elementName);
			By element= By.xpath(elementXpath);
			boolean resultDisplay= isElementDisplayed(element);
			if(resultDisplay==true) {
				JavascriptExecutor je = (JavascriptExecutor) _Browser;
				je.executeScript("arguments[0].scrollIntoView(true);",
						_Browser.findElement(element));
				System.out.println(elementName + "is displaying");
				Reporter.addStepLog("Element Should be displayed " + elementName);
				Reporter.addStepLog("Element is Displayed " + elementName);
				Assert.assertTrue(true);
			}
			else {
				System.out.println(elementName + "is not displaying");
				Reporter.addStepLog("Element Should be displayed " + elementName);
				Reporter.addStepLog("Element is not Displayed " + elementName);
				Assert.assertTrue(false);
			}
		}
		//Nikhil Tapkir;06-June-2021
		public long getDiffBetwTwoDatesByYears(String incpDate, String excpDate) throws Exception {
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
			Date d1 = sdf.parse(incpDate);
	        Date d2 = sdf.parse(excpDate);
	        
	        long difference_In_Time = d2.getTime() - d1.getTime();
	        long difference_In_Years = (difference_In_Time/ (1000l * 60 * 60 * 24 * 365));
	        
	        System.out.print( "Difference between two dates is: "+ difference_In_Years +"Years");
			return difference_In_Years;
		}
		//Nikhil Tapkir;13-July-2021
		public void handleGenerateDocsOKBtnVentilated(String status) throws Exception {
			waitforPreLoaderToWait();
			String ventilatedInsuredName=_testDataManage.getData("GenericData", "Ventilated Insured Name");
			MyWorkPage _nMyWorkPage = new MyWorkPage(_Browser,_testDataManage);

			waitforElementToLoadByCounter(12);
			//int size = _Browser.findElements(ApplicationCommonOR.CONTINUEBTNDOC).size();
			boolean b = _Browser.getPageSource().contains("Continue");
			if (b == true) {
				_Browser.findElement(ApplicationCommonOR.CONTINUEBTNDOC).click();
				waitforElementToLoadByCounter(10);
				refreshPage();
				_nMyWorkPage.editByNameAndAccountStatus(ventilatedInsuredName, status, "Document Review");
			} else {
				System.out.println("Document Review Page opened No need to click on Continue buttton..");
			}
		} 
		//Nikhil Takir; 27th Sept 2021
		public ArrayList<String> getListWithEmptyCellValues(ArrayList<String> list){
			
			System.out.println("Size of list before modification: "+list.size());
			
			while(list.remove("")) {
				System.out.println("New modified list: "+list);
			}
			
			System.out.println("Size of list after modification: "+list.size());
			
			System.out.println("Empty cell from ArrayList Removed");
			
			System.out.println("New modified list: "+list);
			return list;
			
		}
		/* Nikhil Takir; 23rd Nov 2021
		 * Purpose: To get text from list webelements to compare
		 */
		public ArrayList<String> getTextsFromWebElements(By ele, String name){
			ArrayList<String> list= new ArrayList<String>();
			ArrayList<WebElement> elList= (ArrayList<WebElement>) _Browser.findElements(ele);

			System.out.println("Size of elList is:" +elList.size());
			for(int i=0; i<elList.size(); i++) {
				String elText= elList.get(i).getText();
				list.add(elText);
			}
			
			return list;
		}
		/* Nikhil Takir; 23rd Nov 2021
		 * Purpose: To select option based on multiple same type of inputs 
		 * Example: for PCB and PEC we have Ancillary coverage with same object but input 
		 * length is different like for PCB its Employment Professional Liability and for PEC its EPL
		 */
		public void clickOnElementWithSearch(By ele, String search1, String search2, 
				ArrayList<String> searchList) throws Exception {
			
			for(int i=0; i<searchList.size(); i++) {
				if(searchList.get(i).equalsIgnoreCase(search1)) {
					selectDropDownValueByVisibleText(search1, ele);
					break;
				}else if(searchList.get(i).equalsIgnoreCase(search2)) {
					selectDropDownValueByVisibleText(search2, ele);
					break;
				} else {
					System.out.println("No Match found");
				}
			}
		}
		/* Nikhil Tapkir Date 24th Nov 2021
		 * Purpose: To select date from ascend date field as per date provided in test data sheet
		 * Exclusion: Inceptionn date and exception date formated date objects
		 */
		public void selectDateAsTestDataSheet(By ele,String eleName, String dateInput) throws Exception {
			DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
			Date dateFormatted = df.parse(dateInput);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatted);
			int month= cal.get(Calendar.MONTH);
			int date= cal.get(Calendar.DATE);
			int year= cal.get(Calendar.YEAR);
			
			clickOnElementWithWebElement(ele,  eleName);
			selectDropDownByValue(String.valueOf(month),FinancialLinesOR.DATE_MONTH,"Month Dropdown");
			selectDropDownValueByVisibleText(String.valueOf(year),FinancialLinesOR.DATE_YEAR);
			
			List<WebElement> dateOptions= _Browser.findElements(FinancialLinesOR.DATE_DAY);
			
			for(int day=0; day<dateOptions.size(); day++) {
				String textDay= dateOptions.get(day).getText();
				if(textDay.equalsIgnoreCase(String.valueOf(date))) {
					dateOptions.get(day).click();
					break;
				}else{
					continue;
				}
			}
		}
		
		//Nikhil Tapkir; Date:29-Nov-2021
		public String getElementAttributeValue(By element, String attriName){
			return _Browser.findElement(element).getAttribute(attriName);
		}
		//Nikhil Tapkir; Date:29-Dec-2021
		public WebElement getWebElement(String eleXpath, String eleName) {
			System.out.println("Creating WebElement for: "+eleName);
			WebElement element=_Browser.findElement(By.xpath(eleXpath));
			return element;
		}
		/* Author: Nikhil Tapkir; Date:02-Feb-2022
		 * Purpose: To create new tab in same window
		 */
		public void createNewTab() {
			waitForPageToLoadByCounter(10);
			JavascriptExecutor executor = (JavascriptExecutor) _Browser;
			executor.executeScript("window.open()");
			waitForPageToLoadByCounter(10);
		}
		/* Author: Nikhil Tapkir; Date:02-Feb-2022
		 * Purpose: To create new tab in same window
		 */
		public void createNewTab(String url) {
			waitForPageToLoadByCounter(10);
			String newTabUrl= "window.open('"+url+"','')";
			JavascriptExecutor executor = (JavascriptExecutor) _Browser;
			executor.executeScript(newTabUrl);
			waitForPageToLoadByCounter(10);
		}
		/* Author: Nikhil Tapkir; Date:02-Feb-2022
		 * Purpose: To switch to next tab
		 */
		public void switchToTabWithGetWindowHandles(int tabNum) {
			
			ArrayList<String> tabs = new ArrayList<String>(_Browser.getWindowHandles());
			_Browser.switchTo().window(tabs.get(tabNum));
			System.out.println("Title of window is :"+_Browser.getTitle());
			waitForPageToLoadByCounter(50);
		}
		/* Author: Nikhil Tapkir; Date:02-Feb-2022
		 * Purpose: To get reference number from date
		 */
		public String getRefNumberFromDate(String intialProductId, String dateSetting, String particularDate) throws ParseException {
			
			String refNumber,month,date,dateString;
			
			DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
			
			if(dateSetting.equalsIgnoreCase("Present Date")) {
				Date dateObj = new Date();
				dateString = df.format(dateObj);
			}else {
				dateString=particularDate;
			}
			
			Date dateFormatted = df.parse(dateString);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatted);
			int monthCal= cal.get(Calendar.MONTH)+1;
			int dateCal= cal.get(Calendar.DATE);
			int year= cal.get(Calendar.YEAR);
			
			String numb= checkDigitAndAddPreZero(String.valueOf(randomNumbers(50)));
			
			month=checkDigitAndAddPreZero(String.valueOf(monthCal));
			date=checkDigitAndAddPreZero(String.valueOf(dateCal));
		
			refNumber=intialProductId+" "+"0"+String.valueOf(date)+String.valueOf(month)+
					numb+String.valueOf(year).substring(2)+"01";
			
			return refNumber;
		}
		/* Author: Nikhil Tapkir; Date:02-Feb-2022
		 * Purpose: To get integer from string
		 */
		public String extractInt(String value) {
			 
			value = value.replaceAll("[^\\d]", " ");
			value = value.trim();
			value = value.replaceAll(" +", " ");
			
			value=checkDigitAndAddPreZero(value);
	  
	        if (value.equals(""))
	            return "-1";
			  
			return value;
		}
		/* Author: Nikhil Tapkir; Date:02-Feb-2022
		 * Purpose: Checking integer value and adding zero at first place
		 */
		public String checkDigitAndAddPreZero(String str) {
			for(int count=0; count<str.length(); count++) {
				if(str.length()==1) {
					str="0"+str;
					break;
				}
			}
			
			return str;
		}
		/* Author: Nikhil Tapkir; Date:02-Feb-2022
		 * Purpose: Creating random numbers
		 */
		public int randomNumbers(int range) {
			
			Random randomNumb= new Random();
			System.out.println("Creating Random number in the range of "+range);
			return randomNumb.nextInt(range);
			
		}
		// Nikhil Tapkir Date:-6th Dec 2021
		public ArrayList<String> removeFirstIndexFromAList(ArrayList<String> list) {

			list.remove(0);
			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i));
			}

			return list;

		}
		/* Modifier: Nikhil Tapkir Date: 16th March 2022
		 * Purpose: To set fluent wait as per user defined timeOut and pollingTime
		 * Action: added arguments
		 */
		public boolean waitforElementToLoadByFluentWait(By locator, Duration timeOut, Duration pollingTime) {
			boolean isflag = false;
			Wait<WebDriver> wait = new FluentWait<WebDriver>(_Browser)
					.withTimeout(timeOut)
					.pollingEvery(pollingTime)
					.ignoring(NoSuchElementException.class);
	
			WebElement elm=wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			try {
				if (elm != null) {
					isflag = true;
				} else {
					isflag = false;
				}

			} catch (Exception e) {
				Assert.assertTrue(false);
			}
			return isflag;
		}
		/* Author: Nikhil Tapkir Date: 1/03/2022
		 * Purpose: To get list from a string which has number of inputs seprated by commas
		 * Action: created a method which has split() method based on comma 
		 */
		public ArrayList<String> getListFromMultiWordString(String str){
			ArrayList<String> list = new ArrayList<String>();
			String[] strnew=str.split(",");
			
			for(int count=0; count<strnew.length; count++) {
				System.out.println(strnew[count]);
				list.add(count, strnew[count]);
			}
			System.out.println(list);
			
			return list;
			
		}
		/* Author: Nikhil Tapkir Date: 25/03/2022
		 * Purpose: Get future date based on user entered date
		 * action; created method to get it
		 */
		public String getFutureDate(String localDate, long futureDuration, String durationType) 
				throws ParseException {
			DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
			Date dateFormatted = df.parse(localDate);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatted);
			int month= cal.get(Calendar.MONTH);
			int date= cal.get(Calendar.DATE);
			int year= cal.get(Calendar.YEAR);
			
			LocalDate futureDate=null;
			if(durationType.equalsIgnoreCase("Year")) {
				futureDate= LocalDate.of(year, month+1, date)
						.plusYears(futureDuration);
			}else if(durationType.equalsIgnoreCase("Month")) {
				futureDate= LocalDate.of(year, month+1, date)
						.plusMonths(futureDuration);
			}else if(durationType.equalsIgnoreCase("Days")) {
				futureDate= LocalDate.of(year, month+1, date)
						.plusDays(futureDuration);
			}else if(durationType.equalsIgnoreCase("Weeks")) {
				futureDate= LocalDate.of(year, month+1, date)
						.plusWeeks(futureDuration);
			}
			
			DateTimeFormatter form= DateTimeFormatter.ofPattern("dd-MMM-yyyy");
					
			String futDate= futureDate.format(form);
			System.out.println(futDate);
			
			return futDate;
		}
		
	public void printToReportAndConsole(String _str) {
			System.out.println(_str);
			Reporter.addStepLog(_str);
	}
		
		
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////			
}