package com.SeleniumUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.testng.TestListenerAdapter;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.SeleniumUtils.*;

public class TestNGSuiteCreation
{
//  public static OverallReport objOverAllReport;
  public static ArrayList<String> arrayListTestCaseIds;
  public static ArrayList<String> arrayListTestCaseDescriptions;
  public static ArrayList<String> arrayListBrowser;
  public static ArrayList<String> arrayListDeviceType;
  public static ArrayList<String> arrayListMobileID;
  public static ArrayList<String> arrayListMobileBrowser;
  public static ArrayList<String> arrayListSystemName;
  public static ArrayList<String> arrayListPortNo;
  public int counterSrNo = 1;
  private String ScenarioName;
  TestDataManager testDataManage = new TestDataManager();
  
  public TestNGSuiteCreation(String strScenarioName)
  {
    this.ScenarioName = strScenarioName;
    try
    {
      TestNGCreation(this.ScenarioName);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public void TestNGCreation(String ScenarioName)
  {
    Properties property = new Properties();
    try
    {
      property.load(new FileInputStream("config.ini"));
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    System.setProperty("ScenarioName", this.ScenarioName);
    
    String strURL = System.getProperty("ApplicationURL") + "\\" + "Run Manager.xls";
    System.out.println(System.getProperty("ApplicationURL") + "\\" + "Run Manager.xls");
    String ParallelCount = System.getProperty("ParallelCount");
    XmlSuite mySuite = new XmlSuite();
    mySuite.setName(ScenarioName);
    mySuite.setParallel("tests");
    mySuite.setThreadCount(Integer.parseInt(ParallelCount));
    
    this.testDataManage.initialize(null, this.ScenarioName, System.getProperty("ApplicationURL") + "Run Manager.xls");
    arrayListTestCaseIds = this.testDataManage.getExecutableDetail(this.ScenarioName, "TC_ID");
    String scenarioXlsSheetPath = System.getProperty("ApplicationURL") + System.getProperty("ApplicationName") + "\\" +this.ScenarioName + ".xls";
    System.out.println("Get actual DBpath = " + scenarioXlsSheetPath);
    for (int iTestCase = 0; iTestCase < arrayListTestCaseIds.size(); iTestCase++)
    {
      XmlTest test = new XmlTest(mySuite);
      test.setName(((String)arrayListTestCaseIds.get(iTestCase)).toString());
      Map<String, String> testParams = new HashMap<String, String>();
      testParams.put("ScenarioName", this.ScenarioName);
      testParams.put("TestcaseName", ((String)this.testDataManage.getExecutableDetail(this.ScenarioName, "TC_ID").get(iTestCase)).toString());
      testParams.put("TestcaseDescription", ((String)this.testDataManage.getExecutableDetail(this.ScenarioName, "Description").get(iTestCase)).toString());
      testParams.put("CucumberScenarioName", ((String)this.testDataManage.getExecutableDetail(this.ScenarioName, "CucumberScenarioName").get(iTestCase)).toString());
      testParams.put("Browser", ((String)this.testDataManage.getExecutableDetail(this.ScenarioName, "Browser").get(iTestCase)).toString());
      testParams.put("SystemName", ((String)this.testDataManage.getExecutableDetail(this.ScenarioName, "SystemName").get(iTestCase)).toString());
      testParams.put("PortNo", ((String)this.testDataManage.getExecutableDetail(this.ScenarioName, "PortNo").get(iTestCase)).toString());
      testParams.put("KCD_SubFlag", ((String)this.testDataManage.getExecutableDetail(this.ScenarioName, "KCD_SubFlag").get(iTestCase)).toString());
      test.setParameters(testParams);
      List<XmlClass> classes = new ArrayList();
      classes.add(new XmlClass("com.testRunner.CustomGenericRunner"));
      test.setClasses(classes);
    }
    this.testDataManage.closeConnection();
    List<XmlSuite> suites = new ArrayList<XmlSuite>();
    suites.add(mySuite);
    TestListenerAdapter tla = new TestListenerAdapter();
    TestNG tng = new TestNG();
    tng.setUseDefaultListeners(false);
    tng.setXmlSuites(suites);
    tng.addListener(tla);
    tng.run();
  }
}
