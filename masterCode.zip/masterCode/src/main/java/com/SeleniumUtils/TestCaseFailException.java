package com.SeleniumUtils;

public class TestCaseFailException
  extends Exception
{
  public TestCaseFailException(String s)
  {
    super(s);
  }
}
