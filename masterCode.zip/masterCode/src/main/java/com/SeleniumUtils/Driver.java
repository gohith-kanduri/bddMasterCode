package com.SeleniumUtils;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Properties;

import com.google.common.io.Files;

public class Driver {
	public static String strConfigPath;
	public static String strSilo = "NA";
	public static String strTestType = "NA";
	public static String getDestinationPath;
	TestDataManager testDataManage = new TestDataManager();

	public Driver() {
		String strRootPath = System.getProperty("user.dir");
		String strRootPathResult = System.getProperty("user.dir").substring(0,
				System.getProperty("user.dir").lastIndexOf("\\")); 
		System.out.println("User Directory Path is  =========== "+strRootPath);
		String strConfigFolderPath = strConfigPath;
		System.out.println(strConfigFolderPath);
		String strparentURL = strRootPath + "\\Applications\\";
		
		System.setProperty("RootPath", strRootPath);
		Properties property = new Properties();
		try {
			property.load(new FileInputStream("config.ini"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		File file = new File(System.getProperty("user.dir") + "/target/Extent");      
		String[] myFiles;    
		if (file.isDirectory()) {
		    myFiles = file.list();
		    for (int i = 0; i < myFiles.length; i++) {
		        File myFile = new File(file, myFiles[i]); 
		        myFile.delete();
		    }
		}
		
		System.setProperty("ResultPath", property.getProperty("ResultPath"));
		System.setProperty("TestType", strTestType);
		System.setProperty("ApplicationURL", strparentURL);
		System.out.println(System.getProperty("ApplicationURL") + "Run Manager.xls");
		System.setProperty("MasterFilePath", System.getProperty("ApplicationURL") + "Run Manager.xls");
		String strPath = System.getProperty("ResultPath");
		if (strPath.equalsIgnoreCase("Default")) {
			System.setProperty("ResultPath", strRootPathResult + "\\" + "TestResults\\");
			File f = new File(
					System.getProperty("user.dir") + "\\TestResults\\");
			if (f.exists() && f.isDirectory()) {
				System.out.println("INFO: Results Folder Found");
			} else {
				f.mkdir();
				System.out.println("INFO: Results Folder Not Found. so Created one as : " + f.getAbsolutePath());
			}
		} else {

			System.setProperty("ResultPath", strRootPathResult + "\\" + "TestResults\\");
			File f = new File(
					System.getProperty("user.dir") + "\\TestResults\\");
			if (f.exists() && f.isDirectory()) {
				System.out.println("INFO: Results Folder Found");
			} else {
				f.mkdir();
				System.out.println("INFO: Results Folder Not Found. so Created one as : " + f.getAbsolutePath());
			}

		}
		System.out.println(System.getProperty("ApplicationURL") + "Run Manager.xls");
		testDataManage.initialize(null, "Main", System.getProperty("MasterFilePath"));
		ArrayList<String> arrayListScenarios = testDataManage.getScenariosExecutableDetail("Main", "Test Scenarios");
		testDataManage.closeConnection();
		
		for (int iScenario = 0; iScenario < arrayListScenarios.size(); iScenario++) {
			System.out.println(arrayListScenarios.size());
			System.setProperty("ParallelCount",
					testDataManage.ScenarioData("Main", arrayListScenarios.get(iScenario), 3));
			System.setProperty("ApplicationName",
					testDataManage.ScenarioData("Main", arrayListScenarios.get(iScenario), 4));
			System.setProperty("KCD_Flag", 
					testDataManage.ScenarioData("Main", arrayListScenarios.get(iScenario), 5));
			new com.SeleniumUtils.TestNGSuiteCreation(arrayListScenarios.get(iScenario));
			copytestDataExcelToResultFolder(arrayListScenarios.get(iScenario));
		}

	}

	private void copytestDataExcelToResultFolder(String scenraioName) {
		try {			
			getDestinationPath = System.getProperty("user.dir") + "\\TestResults\\";
			getDestinationPath = getDestinationPath.replace("//", "\\");
			System.out.println("Actual time Stamp Destination is " + getDestinationPath);
			String getSourcePath = System.getProperty("ApplicationURL");
			String getActualSourceFilePath = getSourcePath + scenraioName + ".xls";
			String destinationFileName = getDestinationPath + scenraioName + "_"
					+ DateUtils.DateNow() + "_" + DateUtils.TimeNow() + ".xls";
			Path from = Paths.get(getActualSourceFilePath);
			Path to = Paths.get(destinationFileName);
			Files.copy(from.toFile(), to.toFile());
		} catch (Exception e1) {
			System.out.println(e1.getMessage());
		}
	}

	public static void main(String args[]) throws IOException, InterruptedException, TestCaseFailException {
		try {
				new Driver();
		} catch (NullPointerException e) {e.printStackTrace();
		} catch (Exception ep) {
			ep.printStackTrace();
		}
		finally {
			copyExtentReportToTestResultsFolder();
//			String BatPath = null;
//			String overAllStatus = null;
//			String passFailRate = System.getProperty("SucessRate")+"-"+System.getProperty("FailRate");
//			System.out.println("Pass Fail Rate======= "+passFailRate);
//			StringBuilder str = TestNGTestCase.strBuilder;			
//			str = str.deleteCharAt(str.lastIndexOf(","));
//			System.out.println("Data is = "+str);
//			String finaltestResult = str.toString();
//			String[] arrayTestStatus = finaltestResult.split(",");
//			int getStringArraySize = arrayTestStatus.length;
//			
//			for (int i = 0; i < getStringArraySize; i++) {
//				if ("FAIL".equals(arrayTestStatus[i])) {
//					overAllStatus = arrayTestStatus[i];
//					System.out.println("");
//					break;
//				}else{
//					overAllStatus = "PASS";
//				}
//			}
//			System.out.println("INFO: Exiting Program with Email Sending");
//			try {
//				//System.out.println("Get To Email Id " + property.getProperty("ResultsEmailTo"));
//				//System.out.println("Get Cc Email Id " + property.getProperty("ResultsEmailcc"));
//				// System.out.println("Args [1] : " + args[1]);
//				//System.out.println("Report Name is = " + System.getProperty("sanityReport"));
//				/*
//				 * if (!args[1].equalsIgnoreCase("") && !args[1].isEmpty() &&
//				 * !(args[1] == null) && !args[1].equalsIgnoreCase("-Dvalue3")
//				 * && !args[1].equalsIgnoreCase("value3") &&
//				 * !args[1].equalsIgnoreCase("%2")) {
//				 */
//				String b = property.getProperty("ResultsEmail").trim();
//				if ("TRUE".equalsIgnoreCase(property.getProperty("ResultsEmail").trim())) {
//					if ("Sanity".equalsIgnoreCase(property.getProperty("tesName").trim())) {
//						if ("True".equalsIgnoreCase(property.getProperty("Sanity").trim())) {
//							BatPath = strConfigPath + "\\SendSanityEmail.BAT";
//							System.out.println("Bat file path is1 " + BatPath);
//						}
//					} else {
//						BatPath = strConfigPath + "\\SendEmail.BAT";
//						System.out.println("Bat file path is2 = " + BatPath);
//					}
//					/*
//					String[] command = { "cmd.exe", "/C", "Start", BatPath,
//							property.getProperty("ResultsEmailTo")+"_"+property.getProperty("ResultsEmailcc")+"_"
//									+System.getProperty("sanityReport")+"_"+overAllStatus+"_"+passFailRate,
//							getDestinationPath };
//					*/
//					
//					//Author: Gohith Kanduri. Date - 08/23/2020. Modified to send email from local run
//					String[] command = { "cmd.exe", "/C", "Start", BatPath,
//							property.getProperty("ResultsEmailTo")+"_"+property.getProperty("ResultsEmailcc"),
//							getDestinationPath };
//					
//					System.out.println(command);
//					Process p = Runtime.getRuntime().exec(command);
//					p.waitFor();
//					p.destroy();
//					// System.out.println("Sent Email to :" + args[1]);
//				}
//				// }
//			} catch (InterruptedException ie) {
//			} catch (IOException ioe) {
//			} catch (ArrayIndexOutOfBoundsException arrayException) {
//				System.out.println("INFO: Second Argument is not passed");
//			} catch (NullPointerException npe) {
//			} catch (Exception e) {
//			}

		}

		System.exit(0);
	}
	
	private static void copyExtentReportToTestResultsFolder() {
		try {
			String getDestinationPath = System.getProperty("user.dir") + "\\TestResults\\";
			getDestinationPath = getDestinationPath.replace("//", "\\");
			System.out.println("Actual time Stamp Destination is " + getDestinationPath);
			String getSourcePath = System.getProperty("user.dir") + "\\target\\Extent\\Report.html";
			getSourcePath = getSourcePath.replace("//", "\\");	
			String destinationFileName = getDestinationPath + "AutomatedExecutionResults_"
					+ DateUtils.DateNow() + "_" + DateUtils.TimeNow() + ".html";
			Path from = Paths.get(getSourcePath);
			Path to = Paths.get(destinationFileName);			
			File srcFile = from.toFile();
			File destFile = to.toFile();			
//			Files.copy(srcFile.toPath(), destFile.toPath());
			Files.copy(srcFile, destFile);
			System.out.println("File copied");
			
			File htmlFile = new File(destinationFileName);
			Desktop.getDesktop().browse(htmlFile.toURI());
			
		} catch (Exception e1) {
			System.out.println(e1.getMessage());
		}
	}
}