package com.SeleniumUtils;

public class TestCaseMistmatchException
  extends Exception
{
  public TestCaseMistmatchException(String s)
  {
    super(s);
  }
}
