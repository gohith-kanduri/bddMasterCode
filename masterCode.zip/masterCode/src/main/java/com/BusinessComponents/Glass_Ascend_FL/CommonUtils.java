package com.BusinessComponents.Glass_Ascend_FL;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.PageObjects.Glass_Ascend_FL_OR.FinancialLinesOR;
import com.PageObjects.Glass_Ascend_NonFL_OR.ComponentsAndCoveragesPageOR;
import com.SeleniumUtils.SeleniumUtils;
import com.SeleniumUtils.TestDataManager;
import com.cucumber.listener.Reporter;

import junit.framework.Assert;


public class CommonUtils extends SeleniumUtils {

	/*
	 * Author: Gohith Kanduri
	 * Date:26-Aug-2020
	 * Description: Methods for common functionalities in Nav II or GLASS.
	 * Product: Financial Lines
	 */
	
	public CommonUtils(WebDriver Browser, TestDataManager testDataManage) {
		this._Browser = Browser;
		this._testDataManage = testDataManage;
	}
	
	public void handleErrorPopUpOnAccountSummaryPage() throws Exception {
		
		String insuranceProduct = _testDataManage.getData("GenericData", "Insurance Product");
		String tlCode = _testDataManage.getData("GenericData", "Three Letter code");
		if (insuranceProduct.equalsIgnoreCase("Financial Lines")) {
			waitForPageToLoadByCounter(30);
			if(tlCode.equalsIgnoreCase("RAW")) {
				navigateToPage(FinancialLinesOR.SCENARIO_LINK,  " Scenario 1");
			}else{
				navigateToPage(FinancialLinesOR.WORKSHEET, "Worksheet");
			}
			waitForPageToLoadByCounter(30);
			navigateToPage(FinancialLinesOR.ACCOUNT_SUMMARY, "Worksheet");
			waitForPageToLoadByCounter(30);
		}
		if (insuranceProduct.equalsIgnoreCase("Excess Casualty")) {
			waitForPageToLoadByCounter(30);
			navigateToPage(ComponentsAndCoveragesPageOR.OptionsPage, "Options Page");
			waitForPageToLoadByCounter(30);
			navigateToPage(ComponentsAndCoveragesPageOR.AccountSummary, "Account Summary");
			waitForPageToLoadByCounter(30);
		}
		
	}
	
	public void clickSaveButton(By saveElement) throws Exception {
		
		waitForTheElementToBeLoad(saveElement,  "Save button");	 
		implicitWait();
		clickOnElementWithWebElement(saveElement,  "Save button");
		waitforPreLoaderToWait();
		waitForPageToLoadByCounter(10);
		
	}	
	
	public void clickPackageSaveButton() throws Exception {
		
		JavascriptExecutor je = (JavascriptExecutor) _Browser;
		je.executeScript("arguments[0].scrollIntoView(true);",
				_Browser.findElement(FinancialLinesOR.PACKAGE_SAVE_BTN));
		clickOnElementWithActions(FinancialLinesOR.PACKAGE_SAVE_BTN, "Save Button");
		waitforPreLoaderToWait();
		
	}
	
	public void navigateToPage(By pageIdentifier, String pageName) throws Exception {
		
		waitForTheElementToBeLoad(pageIdentifier, pageName);
		clickOnElementWithJavaScriptExecutor(pageIdentifier, pageName);
		implicitWait();
		waitforPreLoaderToWait();
		
	}	
	
	//TODO - Decide on this placement
	public void setUWStrategy(String uwStrategy, By uwElement, String lob) throws Exception {
		enterInputTextvalueByJavaScript(uwElement, uwStrategy, lob + " Underwriting Strategy");
	}
	
	public void setGridData(ArrayList<String> getPolicyQuestions, ArrayList<String> getOptionValues,
			String GIRD_LOCATOR, int rowCounter, int questionColNum, int answerColNum, String cellName,
			String tableName) throws Exception {
		List<WebElement> GRID_OPTIONS = null;
		int counterStart;
		final String varRowsAndCols = "[%d]";

		try {
			int totalPremium = 0;
//    	 	waitforElementToLoadByCounter(3);
			GRID_OPTIONS = _Browser.findElements(By.xpath(GIRD_LOCATOR));
			System.out.println("Size of Amount=" + GRID_OPTIONS.size());
			for (counterStart = rowCounter; counterStart <= GRID_OPTIONS.size(); counterStart++) { // send
																										// counterstart

				String ratingQuestionRow = String.format(GIRD_LOCATOR + varRowsAndCols, counterStart);
				String ratingQuestionCol = String.format("//td" + varRowsAndCols, questionColNum); // send question col
																									// number
				String ratingQuestionVal = ratingQuestionRow + ratingQuestionCol;
				By xpathOfRatingQuestion = By.xpath(ratingQuestionVal);
//                  waitforElementToLoadByCounter(3);
				String getCurrentRatingQuestion = _Browser.findElement(xpathOfRatingQuestion).getText();

				if (getPolicyQuestions.contains(getCurrentRatingQuestion)
						&& !getCurrentRatingQuestion.equalsIgnoreCase("")) {
					int factorIndex = getPolicyQuestions.indexOf(getCurrentRatingQuestion);
					String getPolicyQuestion = getPolicyQuestions.get(factorIndex);
					String getPolicyAnswer = getOptionValues.get(factorIndex);					

					String answerCol = String.format("//td" + varRowsAndCols, answerColNum); // send answer col numbr
					String ratingAnswerVal = ratingQuestionRow + answerCol;
					By xpathOfAnswerCell = By.xpath(ratingAnswerVal);

					switch (tableName) {					
					case ("DNO Rating Inputs and Factors"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("EPL Rating Inputs and Factors"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("FID Rating Inputs and Factors"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;	
					case ("KNR Questions And Answers"):
						if (getPolicyQuestion.equalsIgnoreCase("Comment (Required if Yes)")) {	
							enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						}
						else {
							enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						}						
						break;
					case ("KNR Rating Inputs and Factors"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("Cyber Qualitative Questions"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("Cyber Control Cadence Questions"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;	
					case ("Cyber Content Management Questions"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;	
					case ("CyberCommonRatingFactors"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("Cyber Rating Factors"):
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("Schedule Rating Factors"):
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
						//UW General Info Prior Date
					case ("UW General Info Prior Date"):
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("General Info on Options Page"):
						if ((getPolicyQuestion.equalsIgnoreCase("Combined Aggregate Limit")) || (getPolicyQuestion.contains("%"))) {
							enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						}
						else {
							enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						}						
						break;
					case ("Rate Bearing Endorsements on Options Page"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("Area Of Practice Revenues"):
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("Excess Premium Grid"):
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						int preVal = Integer.parseInt(getPolicyAnswer); 
						totalPremium = totalPremium + preVal; 
//						String finalPremium = Integer.toString(totalPremium);
//						_testDataManage.putDatasheet("Policy Limit", "Excess", finalPremium);
//						String storeCheck = _testDataManage.getData("Excess", "Policy Limit"); 
//						if (!storeCheck.equalsIgnoreCase(finalPremium)) {
//							_testDataManage.putDatasheet("Policy Limit", "Excess", finalPremium);
//							String storeCheck2 = _testDataManage.getData("Excess", "Policy Limit");
//						}						
						break;
					case ("ANE Percent Rating Factors"):
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("ANE Rating Options"):
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("General ANE Information"):
						if ((getPolicyQuestion.equalsIgnoreCase("Show Alternate Retention Type")) 
								|| (getPolicyQuestion.equalsIgnoreCase("Multiple Policy Credit"))
									|| (getPolicyQuestion.equalsIgnoreCase("Retention Type"))) {
							enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						}
						else {
							enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
							enterJustification(ratingQuestionRow, getPolicyQuestion);
						}												
						break;
					case ("EPC Rating Inputs and Factors"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("EPC General Info"):
							enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);		
						break;
					case ("PBP Rating Factors"):
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);		
					break;
					
					case "FGT Ransomware QnA":
						if(getPolicyQuestion.equalsIgnoreCase("What EDR solution is used by the applicant?")) {
							switch (getPolicyAnswer) {
							case("1"): getPolicyAnswer="1. Bitdefender Gravityzone Ultra"; break;
							case("2"): getPolicyAnswer="2. Carbon Black EDR"; break;
							case("3"): getPolicyAnswer="3. Check Point Sandblast Agent"; break;
							case("4"): getPolicyAnswer="4. Cisco AMP for endpoints"; break;
							case("5"): getPolicyAnswer="5. CrowdStrike Falcon"; break;
							case("6"): getPolicyAnswer="6. Cybereason Defense Platform"; break;
							case("7"): getPolicyAnswer="7. CylanceProtect"; break;
							case("8"): getPolicyAnswer="8. Cynet360"; break;
							case("9"): getPolicyAnswer="9. F-Secure Rapid Decection &amp; Response"; break;
							case("10"): getPolicyAnswer="10. Kaspersky KATA"; break;
							case("11"): getPolicyAnswer="11. Malwarebytes Endpoint &amp; Response"; break;
							case("12"): getPolicyAnswer="12. McAfee Mvision"; break;
							case("13"): getPolicyAnswer="13. Microsoft Defender ATP"; break;
							case("14"): getPolicyAnswer="14. Palo Alto Cortex XDR"; break;
							case("15"): getPolicyAnswer="15. Panda Adaptive Defense 360"; break;
							case("16"): getPolicyAnswer="16. Red Canary EDR"; break;
							case("17"): getPolicyAnswer="17. SentinelOne"; break;
							case("18"): getPolicyAnswer="18. Sophos Intercept X Advanced with EDR"; break;
							case("19"): getPolicyAnswer="19. Symantec EDR"; break;
							case("20"): getPolicyAnswer="20. Trend Micro MDR"; break;
							case("21"): getPolicyAnswer="21. Another EDR solution is deployed"; break;
							case("22"): getPolicyAnswer="22. No EDR solution is deployed"; break;
							}
						} else if(getPolicyQuestion.equalsIgnoreCase("b. Which percentage of the network could be recovered from a back-up?")) {
							getPolicyAnswer = getPolicyAnswer+"%";
						} else if(getPolicyQuestion.equalsIgnoreCase("c. What's the applicant's network redundancy?")) {
							getPolicyAnswer = getPolicyAnswer+"%";
						}
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case "FGT Contract Detail":
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case "FGT L&R Coverages Grid":
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case "FGT Options, Rating Options":
						if(counterStart==24) {
							scrollingByElement(xpathOfAnswerCell);
							waitforElementToLoadByCounter(1);
						}
						
						if(getPolicyQuestion.equalsIgnoreCase("First Party Coverage") || getPolicyQuestion.equalsIgnoreCase("First Party Coverage Endorsement Type")) {
							enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						} else {
							enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						}
						
						break;
					case "FGT Options, First Party Cyber":
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case "FGT Options, Rating Input and Factors":
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case "FGT Options, Subjective Factors":
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case "FGT Options, Errors and Omissions":
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case "FGT Options, General Info":
						if(getPolicyQuestion.equalsIgnoreCase("Liability Coverage RetroDate")) {
							String _retroDate = getDateBasedOnInceptionDate(-5);
							selectDateFromUiDatePicker(xpathOfAnswerCell, _retroDate, "Liability Coverage Retro Date");
							System.out.println(""); //Debug
						} else {
							enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						}
						break;
					case ("Insurance Company Professional Liability")://Tribhuwan
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
					break;
					case ("IDE_FID Rating Inputs and Factors")://Tribhuwan
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
					break;
					case ("IDE_DNO Rating Inputs and Factors")://Tribhuwan
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
					break;
					case ("EPLI Rating Inputs and Factors")://Tribhuwan
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
					break;
					case ("IDE_KNR Rating Inputs and Factors")://Tribhuwan
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
					break;
					case ("General IDE Information")://Tribhuwan
						if(getPolicyQuestion.contains("Combined Aggregate Limit")) 
						{
							enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
						}
						else if(getPolicyQuestion.contains("Maximum Aggregate Limit")) 
						{
							enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
						}else
						{
							enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
						}
					break;
					case ("IDE_Rate Bearing Endorsements")://Tribhuwan
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
					break;
					case ("IDE_IRPM Factors")://Nikhil Tapkir
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
					break;
					case "MPLprimary_DebitsCreditsPercent":
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case "MPLprimary_DebitsCreditsComments":
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);
						break;
					case ("PLM Rating Options")://Nikhil Tapkir
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
					break;
					case ("PLM Rating And Input Factors")://Nikhil Tapkir
						enterDropDownValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
					break;
					case ("PLM IRPM Factors")://Nikhil Tapkir
						enterInputTextValuesInGrid(cellName, xpathOfAnswerCell, getPolicyQuestion, getPolicyAnswer);	
					break;
					default:
						break;
					}
					
					//UW Worksheet - PCP - KNR
					if ((getPolicyQuestion.equalsIgnoreCase("Has there been any threat or attempt at a kidnapping, extortion or detention in the last three years?")) && (getPolicyAnswer.equalsIgnoreCase("Yes"))) {
						clickOnElementWithWebElement(FinancialLinesOR.KNR_UNDERWRITING_ANALYSIS,"Underwriting Analysis"); 					
					}
					
					//Options Page - PCP, PNP, PHO
					if ((getPolicyQuestion.equalsIgnoreCase("Theft of Clients' Property Off Premises - Blanket")) && (getPolicyAnswer.equalsIgnoreCase("Added"))) {
						clickOnElementWithWebElement(FinancialLinesOR.RBE_DUMMY_CLICK,"Dummy Click for Grid Update");
					}
				}
			}
		}

		catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}	
	/* Modifier: Nikhil Tapkir Date:27th Dec 2021
	 * Purpose: To click on object, changing methods
	 * Modification: Commented previous method and added new one from selenium utils
	 */
	private void enterDropDownValuesInGrid(String cellName, By xpathOfAnswerCell, String getPolicyQuestion,
			String getPolicyAnswer) throws Exception {

		By xpathOfAnsDropDown = By.name(cellName); // pass from method
		String getAttr = _Browser.findElement(xpathOfAnswerCell).getAttribute("class");
		if (!getAttr.contains("not")) {
				waitForTheElementToBeLoad(xpathOfAnswerCell, "Answer");
				clickOnElementWithActions(xpathOfAnswerCell, "Answer");
				clickOnElementWithActions(xpathOfAnswerCell, "Answer");
				//clickOnElementWithWebElement(xpathOfAnswerCell, "Answer");
				//clickOnElementWithWebElement(xpathOfAnswerCell, "Answer");
				waitForTheElementToBeLoad(xpathOfAnsDropDown, "Answer");
				selectDropDownValueByVisibleText(getPolicyAnswer, xpathOfAnsDropDown);
			}
	}
	/* Modifier: Nikhil Tapkir Date:29th Nov 2021
	 * Purpose: To enter value in textfield after clicking on ele
	 * Modification: added xpath of textfield as temp code
	 */
	private void enterInputTextValuesInGrid(String cellName, By xpathOfAnswerCell, String getPolicyQuestion,
			String getPolicyAnswer) throws Exception {
		By xpathOfAnsDropDown = By.name(cellName); // pass from method
		String getAttr = _Browser.findElement(xpathOfAnswerCell).getAttribute("class");
		String _tlCode = _testDataManage.getData("GenericData", "Three Letter code");
		if (!getAttr.contains("not")) {
			waitForTheElementToBeLoad(xpathOfAnswerCell, "Answer");
			clickOnElementWithWebElement(xpathOfAnswerCell, "Answer");
			String val=getElementAttributeValue(xpathOfAnswerCell, "aria-describedby");
			
			if(val.contains("_RatingFactor")){
				enterInputTextvalueByJavaScript
				(By.xpath("//*[@name='RatingFactor']"), getPolicyAnswer, "Option");//Temp code
			}else if(val.contains("_Answer")) {
				enterInputTextvalueByJavaScript
				(By.xpath("//*[@name='Answer']"), getPolicyAnswer, "Option");//Temp code
			}else if(val.contentEquals("")) {
				
			}else {
				enterInputTextvalueByJavaScript(xpathOfAnsDropDown, getPolicyAnswer, "Option");
			}
			
		}
	}
	
	public void setCellValue(String GIRD_LOCATOR, int rowVal, int colVal, String cellName, String value) throws Exception {
		
		String formattedXpathString = GIRD_LOCATOR + "[" + rowVal + "]//td[" + colVal + "]";			
		By formattedXpath = By.xpath(formattedXpathString);
		String getAttr = _Browser.findElement(formattedXpath).getAttribute("class");
		if (!getAttr.contains("not")) {
			waitForTheElementToBeLoad(formattedXpath, "Answer");
			clickOnElementWithWebElement(formattedXpath, "Answer");
			By xpathOfCell = By.name(cellName);
			String getAttrOfCell = _Browser.findElement(xpathOfCell).getAttribute("role");
			if (getAttrOfCell.equalsIgnoreCase("select")) {
				selectDropDownValueByVisibleText(value, xpathOfCell);
			}
			if (getAttrOfCell.equalsIgnoreCase("textbox")) {
				enterInputTextvalueByJavaScript(xpathOfCell, value, cellName);
			}			
		}
		
	}
	
	
	private void enterJustification(String ratingQuestionRow, String getPolicyQuestion) throws Exception {
		String ratingQuestionComment = ratingQuestionRow + "//td[3]//i[2]";
		By comment = By.xpath(ratingQuestionComment);
		clickOnElementWithWebElement(comment, "Comment");
		waitForTheElementToBeLoad(FinancialLinesOR.JUSTIFICATION_TEXTBOX, "Justification Comment");
		enterInputTextvalue(FinancialLinesOR.JUSTIFICATION_TEXTBOX, getPolicyQuestion, "Justification Comment");
		clickOnElementWithWebElement(FinancialLinesOR.JUSTIFICATION_OK_BUTTON, "OK");
	}
	
	
	//Argument - No of days to be added or subtracted based on inception date displayed in Ascend
	public String getDateBasedOnInceptionDate(int daysToBeAdded) throws Exception {
		String inceptionDate = _Browser.findElement(FinancialLinesOR.ACTUAL_INCEPTION_DATE).getText();
		System.out.println("Inception Date is " +inceptionDate);
		
		DateTimeFormatter frmt = DateTimeFormatter.ofPattern("dd-MMM-yyyy" , Locale.ENGLISH);
		LocalDate date = LocalDate.parse(inceptionDate , frmt).plusDays(daysToBeAdded);				
		String formattedDate = date.format(frmt);
		System.out.println("Formatted date" +formattedDate);
		return formattedDate;
	}
	
	
	public void setRatingInputsForCoverages(int counter, List<WebElement> elmAutoModel, String dataValue, 
			WebElement ratingFactorSelection, String ratingFactorsInputsBody, String answerDropDown) {
		String finalRatingAnswerPostion = null;
		String getRatingInputFactorRow = null;
		String getActualAnswerPosition = null;
		
		try {	
			if ((!dataValue.equals("") || (!dataValue.equals(null)))) {					
					String val = ratingFactorSelection.getAttribute("id");
					int getAnswerIndex = getHeaderCountById(val, elmAutoModel);
					getRatingInputFactorRow = String.format(ratingFactorsInputsBody, counter);
					getActualAnswerPosition = String.format(FinancialLinesOR.RATING_INPUT_FACTORS_GRID_COLS, getAnswerIndex);
					finalRatingAnswerPostion = getRatingInputFactorRow + getActualAnswerPosition;
					By xpathOfAnswerCell = By.xpath(finalRatingAnswerPostion);
					String getAttr = _Browser.findElement(xpathOfAnswerCell).getAttribute("class");
					By xpathOfAnsDropDown = By.name(answerDropDown);
					if (!getAttr.contains("not")) {
						waitForTheElementToBeLoad(xpathOfAnswerCell, "Answer");
						clickOnElementWithWebElement(xpathOfAnswerCell,"Answer");
						clickOnElementWithWebElement(xpathOfAnswerCell,"Answer");
						waitForTheElementToBeLoad(xpathOfAnsDropDown, "Answer");
						selectDropDownValueByVisibleText(dataValue, xpathOfAnsDropDown);					
					}
			}
			else {
				//Print report that Value is not provided in test data sheet
			}
			waitforPreLoaderToWait();
		} catch (Exception e) {
//			_objDetailedReport.WriteLog(Status.FAIL, "Use TextField Should get Entered",
//					"Use TextField is not getting Entered", null);
		}
	}
	
	
	public void setRatingInputsTextForCoverages(int counter, List<WebElement> elmAutoModel, String dataValue, 
			WebElement ratingFactorSelection, String ratingFactorsInputsBody, String answerDropDown) {
		String finalRatingAnswerPostion = null;
		String getRatingInputFactorRow = null;
		String getActualAnswerPosition = null;
		
		try {	
			if ((!dataValue.equals("") || (!dataValue.equals(null)))) {					
					String val = ratingFactorSelection.getAttribute("id");
					int getAnswerIndex = getHeaderCountById(val, elmAutoModel);
					getRatingInputFactorRow = String.format(ratingFactorsInputsBody, counter);
					getActualAnswerPosition = String.format(FinancialLinesOR.RATING_INPUT_FACTORS_GRID_COLS, getAnswerIndex);
					finalRatingAnswerPostion = getRatingInputFactorRow + getActualAnswerPosition;
					By xpathOfAnswerCell = By.xpath(finalRatingAnswerPostion);
					By xpathOfAnsDropDown = By.name(answerDropDown);
					String getAttr = _Browser.findElement(xpathOfAnswerCell).getAttribute("class");			
					if (!getAttr.contains("not")) {
						waitForTheElementToBeLoad(xpathOfAnswerCell, "Answer");
						clickOnElementWithWebElement(xpathOfAnswerCell,"Answer");
						clickOnElementWithWebElement(xpathOfAnswerCell,"Answer");
						waitForTheElementToBeLoad(xpathOfAnsDropDown, "Answer");
							enterInputTextvalueByJavaScript(xpathOfAnsDropDown, dataValue, "Answer");									
					}
			}
			else {
				//Print report that Value is not provided in test data sheet
			}
			waitforPreLoaderToWait();
		} catch (Exception e) {
//			_objDetailedReport.WriteLog(Status.FAIL, "Use TextField Should get Entered",
//					"Use TextField is not getting Entered", null);
		}
	}
	//Nikhil Tapkir 29th July 2021
	public void checkInputInExSheet(String sheetName, String colunName, String value ) throws Exception {
		String storeCheck = _testDataManage.getData(sheetName, colunName);
        if (!storeCheck.equalsIgnoreCase(value)) {
     	   _testDataManage.putDatasheet(colunName, sheetName, value);
     	   String storeCheck1 = _testDataManage.getData(sheetName, colunName);
     	   System.out.println("Value entered correctly as: "+storeCheck1);
     	  Reporter.addStepLog("Value entered correctly in column named as .." + colunName +" And with value.. "+ storeCheck1);
        }
	}
	
	
	/*
	 * Author: Gohith Kanduri
	 * Date: 01-Sep-2020
	 * Purpose: Method to select date from UI date picker. Observed in Navigate II app for Financial Lines
	 */
	public void selectDateFromUiDatePicker(By dateElement, String dateToSelect, String eleName) throws Exception {			
		
		try {
			int i, j;
			int selectFlag = 0;
			DateTimeFormatter frmt1 = DateTimeFormatter.ofPattern( "dd-MMM-yyyy", Locale.ENGLISH ) ;
			DateTimeFormatter frmt2 = DateTimeFormatter.ofPattern("MMM", Locale.ENGLISH);
			LocalDate ld = LocalDate.parse( dateToSelect , frmt1 ) ;
			int d = ld.getDayOfMonth() ;			
			int y = ld.getYear() ;
			
			String month = frmt2.format(ld);
			String date = Integer.toString(d);
			String year = Integer.toString(y);

			waitForTheElementToBeLoad(dateElement, eleName);
			clickOnElementWithActions(dateElement, eleName);
			selectDropDownValueByVisibleText(month, FinancialLinesOR.CALENDAR_MONTH);
			selectDropDownValueByVisibleText(year, FinancialLinesOR.CALENDAR_YEAR);
			
			By xpathOfTotalRows = By.xpath(FinancialLinesOR.CALENDAR_DATE_ROWS);
			List <WebElement> CALENDER_ROWS = _Browser.findElements(xpathOfTotalRows);
			String relCurrentRow = FinancialLinesOR.CALENDAR_DATE_ROWS + FinancialLinesOR.CALENDAR_DATE_SELECTION;
			int rowCnt = CALENDER_ROWS.size();
			
			outerLoop: for (i = 1; i<=rowCnt; i++) {
				String currentRow = String.format(relCurrentRow, i);
				String currentCols = currentRow + FinancialLinesOR.CALENDAR_DATE_COL;
				By xpathOfTotalCols = By.xpath(currentCols);
				List <WebElement> CALENDER_COLS = _Browser.findElements(xpathOfTotalCols);
				int colCnt = CALENDER_COLS.size();				
				innerLoop: for (j=1; j<=colCnt; j++) {
					String currentDatePath = currentCols + FinancialLinesOR.CALENDAR_DATE_SELECTION;
					String currentRowSelection = String.format(currentDatePath, j);
					By xpathOfCurentDate = By.xpath(currentRowSelection);
					String dateVal = _Browser.findElement(xpathOfCurentDate).getText();
					if (dateVal.equalsIgnoreCase(date)) {
						clickOnElementWithActions(xpathOfCurentDate, eleName);
						selectFlag++;
						Reporter.addStepLog(eleName + " was selected");
						break innerLoop;					
					}
				}
				if (selectFlag == 1) {
					break outerLoop;					
				}
			}
			if (selectFlag == 0) {
				Reporter.addStepLog(eleName + " was not selected");
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			Reporter.addStepLog(eleName + " was not selected due to " + e.getMessage());
		}
		
	}
	
	/* Autor: Nikhil Tapkir
	 * Purpose: To automate use Go To functionality
	 * Date: 11th Jan 2022
	 */		
	public void navigateUsingGoToButton(String navigateTO, String navigateSect) {
		String destPage = String.format(FinancialLinesOR.GO_TO_NAVIGATE_TO, navigateTO);
		List<WebElement> submenu= _Browser.findElements(By.xpath(FinancialLinesOR.GO_TO_DROPDOWN_SUBMENU));
		
		clickOnElementWithActions(FinancialLinesOR.GOTO_BUTTON, "Go TO Button");
		
		System.out.println("Total Sub Menu Dropdown present are: "+submenu.size());
		
		if(navigateSect.equalsIgnoreCase("Before Divider")) 
		{//Before Option page including it
			if(navigateTO.contains("Worksheet")) {
				destPage= String.format("//*[@data-xmltagprop='GoTo']//ul//li//a//span[text()='%s']", navigateTO);
			}
			
			clickOnElementWithActions(By.xpath(destPage), navigateTO);
			Reporter.addStepLog("User naviagted to "+navigateTO);
		}
		else 
		{//After option page for single or multiple scenarios
			for(int count=1; count<=submenu.size(); count++)
			{
				String scenarioNameXpath=String.format("("+(FinancialLinesOR.GO_TO_DROPDOWN_SUBMENU)+"[%d]//a)[1]]", count);
				String scenarioName=getWebElement(scenarioNameXpath, "Sub menu Dropdown "+count).getText();
				
				if(scenarioName.equalsIgnoreCase("navigateSect")) 
				{
					String scenario=String.format(FinancialLinesOR.GO_TO_NAVIGATE_TO, scenarioName);
					System.out.println("Clicking on Scenario option: "+scenario);
					
					clickOnElementWithActions(By.xpath(scenario), scenarioName);
					
					System.out.println("User wants to click on "+navigateTO+" under "+scenarioName);
					clickOnElementWithActions(By.xpath(destPage), navigateTO);
					Reporter.addStepLog("User naviagted to "+navigateTO);
					break;
				}
				else 
				{
					continue;
				}
			}
		}
	}
	
/**
	 * This methods adds a new row in a grid using 'Add Row' button.
	 * Add parameters to Documentation.
	 * @since 22-Mar-2022
	 *
	 */
	public void createGridData(int numberOfColumns, int[] colIndexArr, String[] uiColHeaderArr,
									String[] cellNameAttributeArr, String[] cellTypeArr, String[][] sheetColArr)
	{
		boolean paramsAreValid = verifyCreateGridDataMethodParams(numberOfColumns, colIndexArr, uiColHeaderArr,
				cellNameAttributeArr, cellTypeArr, sheetColArr);
		
		if(paramsAreValid)
		{
			try
			{
				//create array with headers in sheet.
				//create array with column index. (follow order in the above array)
				//create array with cell name of each cell in the row. (follow order of the above array)
				//create array with cell type of each cell in the row. (follow order of the above array)
				//***** first get the column wise data using existing method
				//create row wise array list with elements. (as a grid may have 5 columns but we are adding only 3 rows)
				//check feasibility of above point as methods for getting column wise data already exists.
				//
				//create an array list of the array lists in the above point.
				//
				//
				//iterate through the grid to enter data.
				//utilize above methods to enter data into the grid.
				
				//decide if to create row wise array list
				
				ArrayList<ArrayList<String>>  _testDataFromSheet = new ArrayList<ArrayList<String>>();
				
				for(int i=0; i<sheetColArr.length; i++)
				{
					
				}
				
				
				
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
		
	}
	
	private boolean verifyCreateGridDataMethodParams(int numberOfColumns, int[] colIndexArr, String[] uiColHeaderArr,
			String[] cellNameAttributeArr, String[] cellTypeArr, String[][] sheetColArr)
	{
		boolean result = true;
		
		if(result && colIndexArr.length != numberOfColumns) {
			result = false;
			System.out.println("ERROR: Length of colIndexArr doesnot match with int variable numberOfColumns");
			System.out.println("Length of colIndexArr ---> " + colIndexArr.length);
			System.out.println("int variable numberOfColumns ---> " + numberOfColumns);
			printToReportAndConsole("ERROR: TEST DATA ERROR!");
			Assert.fail();
		}
		
		if(result && uiColHeaderArr.length != numberOfColumns) {
			result = false;
			System.out.println("ERROR: Length of uiColHeaderArr doesnot match with int variable numberOfColumns");
			System.out.println("Length of uiColHeaderArr ---> " + uiColHeaderArr.length);
			System.out.println("int variable numberOfColumns ---> " + numberOfColumns);
			printToReportAndConsole("ERROR: TEST DATA ERROR!");
			Assert.fail();
		}
		
		if(result && cellNameAttributeArr.length != numberOfColumns) {
			result = false;
			System.out.println("ERROR: Length of cellNameAttributeArr doesnot match with int variable numberOfColumns");
			System.out.println("Length of cellNameAttributeArr ---> " + cellNameAttributeArr.length);
			System.out.println("int variable numberOfColumns ---> " + numberOfColumns);
			printToReportAndConsole("ERROR: TEST DATA ERROR!");
			Assert.fail();
		}
		
		if(result && cellTypeArr.length != numberOfColumns) {
			result = false;
			System.out.println("ERROR: Length of cellTypeArr doesnot match with int variable numberOfColumns");
			System.out.println("Length of cellTypeArr ---> " + cellTypeArr.length);
			System.out.println("int variable numberOfColumns ---> " + numberOfColumns);
			printToReportAndConsole("ERROR: TEST DATA ERROR!");
			Assert.fail();
		}
		
		if(result && sheetColArr.length != numberOfColumns) {
			result = false;
			System.out.println("ERROR: Length of sheetColArr doesnot match with int variable numberOfColumns");
			System.out.println("Length of sheetColArr ---> " + sheetColArr.length);
			System.out.println("int variable numberOfColumns ---> " + numberOfColumns);
			printToReportAndConsole("ERROR: TEST DATA ERROR!");
			Assert.fail();
		}
		
		return result;
	}
	
}