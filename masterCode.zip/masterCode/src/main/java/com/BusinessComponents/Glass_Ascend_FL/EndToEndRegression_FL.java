package com.BusinessComponents.Glass_Ascend_FL;

import org.openqa.selenium.WebDriver;

import com.BusinessComponents.Glass_Ascend_NonFL.BinderIssued;
import com.BusinessComponents.Glass_Ascend_NonFL.PolicyIssued;
import com.SeleniumUtils.SeleniumUtils;
import com.SeleniumUtils.TestDataManager;



public class EndToEndRegression_FL extends SeleniumUtils {

	
	
	private int _issuedFlag = 1;
	public EndToEndRegression_FL(WebDriver Browser,TestDataManager testDataManage) {
		
		this._Browser = Browser;
		this._testDataManage = testDataManage;
	}
	
	public void testEndToEndRegression() throws Exception {
		String lob = _testDataManage.getData("GenericData", "Three Letter code");
		switch (lob) {
		case "PCP":
			testEndToEndPCP();
			break;
		case "PNP":
			testEndToEndPNP();
			break;
		case "CSA":
			testEndToEndCSA();
			break;
		case "TPC":
			testEndToEndCSA();
			break;
		case "MPL":
			testEndToEndMPL();
			break;
		case "PHO":
			testEndToEndPHO();
			break;
		case "CYB":
			testEndToEndCCFR();
			break;
		case "AMS": 
			testEndToEndAMC();
		case "AML": 
			testEndToEndAMC();
			break;
		case "IAE": 
			testEndToEndIAE();
			break;
		case "ANE":
			testEndToEndANE();
			break;
		case "PCB":
			testEndToEndPCB();
			break;
		case "PEC":
			testEndToEndPEC();
			break;
		default:
			break;
		}
	}
	
	//******Start of Financial Lines E2E methods******//
	
	
		/***
		 * Author: Gohith Kanduri Date:22nd April 2020
		 ***/
		public void testEndToEndPCP() throws Exception {
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);		
//			
//			if (qiFlag.equalsIgnoreCase("Yes")) {
//				_qIssued.setQuoteIssuedForPCP("S", _issuedFlag);
//			}
//			
//			if (biFlag.equalsIgnoreCase("Yes")) {
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//			
//			if (piFlag.equalsIgnoreCase("Yes")) {
//				_pIssued.setPolicyIssuedForFL("BI", _issuedFlag);
//			}

		}
		
		/***
		 * Author: Gohith Kanduri Date:7-Sep-2020
		 ***/
		public void testEndToEndPNP() throws Exception {
			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
			
			FL_QuoteIssued _qIssued = new FL_QuoteIssued(_Browser,  _testDataManage);
			BinderIssued _bIssued = new BinderIssued(_Browser,  _testDataManage);
			PolicyIssued _pIssued = new PolicyIssued(_Browser,  _testDataManage);
			
			if (qiFlag.equalsIgnoreCase("Yes")) {
				_qIssued.setQuoteIssuedForPNP("S", _issuedFlag);
			}
			
			if (biFlag.equalsIgnoreCase("Yes")) {
				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag, "New");
			}
			
			if (piFlag.equalsIgnoreCase("Yes")) {
				_pIssued.setPolicyIssuedForFL("BI", _issuedFlag);
			}

		}
		
		/***
		 * Author: Gohith Kanduri Date:22nd April 2020
		 ***/
		public void testEndToEndCSA() throws Exception {
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			
//			if (qiFlag.equalsIgnoreCase("Yes")) {
//				_qIssued.setQuoteIssuedForCSA("S", _issuedFlag);
//			}
//			
//			if (biFlag.equalsIgnoreCase("Yes")) {
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//			
//			if (piFlag.equalsIgnoreCase("Yes")) {
//				_pIssued.setPolicyIssuedForFL("BI", _issuedFlag);
//			}

		}
		
		/***
		 * Author: Gohith Kanduri Date:22nd April 2020
		 ***/
		public void testEndToEndTPC() throws Exception {
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			
//			if (qiFlag.equalsIgnoreCase("Yes")) {
//				_qIssued.setQuoteIssuedForTPC("S", _issuedFlag);
//			}
//			
//			if (biFlag.equalsIgnoreCase("Yes")) {
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//			
//			if (piFlag.equalsIgnoreCase("Yes")) {
//				_pIssued.setPolicyIssuedForFL("BI", _issuedFlag);
//			}

		}
		
		
		/***
		 * Author: Gohith Kanduri Date:22nd April 2020
		 ***/
		public void testEndToEndPHO() throws Exception {
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			if (qiFlag.equalsIgnoreCase("Yes")) {
//				_qIssued.setQuoteIssuedForPHO("S", _issuedFlag);
//			}
//			
//			if (biFlag.equalsIgnoreCase("Yes")) {
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//			
//			if (piFlag.equalsIgnoreCase("Yes")) {
//				_pIssued.setPolicyIssuedForFL("BI", _issuedFlag);
//			}

		}
		
		
		/***
		 * Author: Gohith Kanduri Date:22nd April 2020
		 ***/
		public void testEndToEndCCFR() throws Exception {
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			if (qiFlag.equalsIgnoreCase("Yes")) {
//				_qIssued.setQuoteIssuedForCCFR("S", _issuedFlag);
//			}
//			
//			if (biFlag.equalsIgnoreCase("Yes")) {
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//			
//			if (piFlag.equalsIgnoreCase("Yes")) {
//				_pIssued.setPolicyIssuedForFL("BI", _issuedFlag);
//			}

		}
		
		
		/***
		 * Author:Anusha Pawar Date:22nd April 2020
		 ***/
		public void testEndToEndMPL() throws Exception {
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			RegressionCommonMethods rcm = new RegressionCommonMethods(_Browser, _objDetailedReport, _testDataManage, null);
//			if (qiFlag.equalsIgnoreCase("Yes")) {
//				_qIssued.setQuoteIssuedForMPL("S", _issuedFlag);
//			}
//
//			if (biFlag.equalsIgnoreCase("Yes")) {
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//
//			if (piFlag.equalsIgnoreCase("Yes")) {
//				_pIssued.setPolicyIssued("BI", _issuedFlag);
//			}

		}
		
		/***
		 * Author:Anusha Pawar Date:29th Oct 2020
		 ***/
		public void testEndToEndAMC() throws Exception {
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			RegressionCommonMethods rcm = new RegressionCommonMethods(_Browser, _objDetailedReport, _testDataManage, null);
//			if (qiFlag.equalsIgnoreCase("Yes")) {
//				_qIssued.setQuoteIssuedForAMC("S", _issuedFlag);
//			}
//
//			if (biFlag.equalsIgnoreCase("Yes")) {
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//
//			if (piFlag.equalsIgnoreCase("Yes")) {
//				_pIssued.setPolicyIssued("BI", _issuedFlag);
//			}
		}
		
		/***
		 * Author:Anusha Pawar Date:13th Nov 2020
		 ***/
		public void testEndToEndIAE() throws Exception {
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			RegressionCommonMethods rcm = new RegressionCommonMethods(_Browser, _objDetailedReport, _testDataManage, null);
//			if (qiFlag.equalsIgnoreCase("Yes")) {
//				_qIssued.setQuoteIssuedForIAE("S", _issuedFlag);
//			}
//
//			if (biFlag.equalsIgnoreCase("Yes")) {
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//
//			if (piFlag.equalsIgnoreCase("Yes")) {
//				_pIssued.setPolicyIssued("BI", _issuedFlag);
//			}
		}
		
		
		/***
		 * Author: Gohith Kanduri Date:XXXXXXXXX
		 ***/
		public void testEndToEndANE() throws Exception {
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			RegressionCommonMethods rcm = new RegressionCommonMethods(_Browser, _objDetailedReport, _testDataManage, null);
//			if (qiFlag.equalsIgnoreCase("Yes")) {
//				_qIssued.setQuoteIssuedForIAE("S", _issuedFlag);
//			}
//
//			if (biFlag.equalsIgnoreCase("Yes")) {
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//
//			if (piFlag.equalsIgnoreCase("Yes")) {
//				_pIssued.setPolicyIssued("BI", _issuedFlag);
//			}
		}
		/***
		 * Author:Nikhil Tapkir Date- 18th Feb 2021
		 ***/
		public void testEndToEndPEC() throws Exception 
		{
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			String peFlag = _testDataManage.getData("GenericData", "PE Flag");
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			RegressionCommonMethods rcm = new RegressionCommonMethods(_Browser, _objDetailedReport, _testDataManage, null);
//			if (qiFlag.equalsIgnoreCase("Yes")) 
//			{
//				_qIssued.setQuoteIssuedForPEC("S", _issuedFlag);
//			}
//
//			if (biFlag.equalsIgnoreCase("Yes")) 
//			{
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//
//			if (piFlag.equalsIgnoreCase("Yes")) 
//			{
//				_pIssued.setPolicyIssued("BI", _issuedFlag);
//			}
//			
//			if (peFlag.equalsIgnoreCase("Yes")) 
//			{
//				policyEndorsedForAllLOB("PI");
//			}
		}
		/***
		 * Author:Nikhil Tapkir Date- 18th Feb 2021
		 ***/
		public void testEndToEndPCB() throws Exception 
		{
//			String qiFlag = _testDataManage.getData("GenericData", "QI Flag");
//			String biFlag = _testDataManage.getData("GenericData", "BI Flag");
//			String piFlag = _testDataManage.getData("GenericData", "PI Flag");
//			String peFlag = _testDataManage.getData("GenericData", "PE Flag");
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			RegressionCommonMethods rcm = new RegressionCommonMethods(_Browser, _objDetailedReport, _testDataManage, null);
//			if (qiFlag.equalsIgnoreCase("Yes")) 
//			{
//				_qIssued.setQuoteIssuedForPCB("S", _issuedFlag);
//			}
//
//			if (biFlag.equalsIgnoreCase("Yes")) 
//			{
//				_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			}
//
//			if (piFlag.equalsIgnoreCase("Yes")) 
//			{
//				_pIssued.setPolicyIssued("BI", _issuedFlag);
//			}
//			
//			if (peFlag.equalsIgnoreCase("Yes")) 
//			{
//				policyEndorsedForAllLOB("PI");
//			}
		}
		/***
		 * Author:Nikhil Tapkir Date- 5th April 2021
		 ***/
		public void policyEndorsedForAllLOB(String status) throws Exception {
//			String insuredName = _testDataManage.getData("GenericData", "Insured Name");
//			NavigatorMyWorkPage _nMyWorkPage = new NavigatorMyWorkPage(_Browser, _objDetailedReport, _testDataManage, null);
//			String endorseType = _testDataManage.getData("FormsAndEndorsement", "Type");
//			String endorseWay = _testDataManage.getData("FormsAndEndorsement", "Endorse Way");
//			EndorsementPageForAllLOB endorse = new EndorsementPageForAllLOB(_Browser, _objDetailedReport, _testDataManage,
//					null);
//			if(status.equalsIgnoreCase("PI"))
//			{
//				if(endorseWay.equalsIgnoreCase("PI to PE")) 
//				{
//					endorse.setPolicyEndorsedForAll("PI", endorseType, endorseType, _issuedFlag);
//				} 
//				else if (endorseWay.equalsIgnoreCase("EPR to PE"))
//				{
//					endorse.setEndorsmentPendingReviewForAll("PI", endorseType, endorseType, _issuedFlag);
//					endorse.setEndorsementPendingReviewToPolicyEndorsed("IEPR", endorseType, _issuedFlag);
//				}
//			}
//			
//			String getStatus2 = _nMyWorkPage.getInsuredNameStatusByPassingvalue(insuredName, _objDetailedReport);
//			getReferenceNumber("Ref Num");
//			_nMyWorkPage.setStatusInReport(getStatus2, _objDetailedReport);
		}
		
		public void testPI_IPE() throws Exception {
			
//			EndorsementPageForAllLOB endorse = new EndorsementPageForAllLOB(_Browser, _objDetailedReport, _testDataManage,
//					null);
//			
//				endorse.setPolicyEndorsedForAll("PI", "Internal", "Internal", _issuedFlag);
		}
		/***
		 * Author:Nikhil Tapkir Date- 7th April 2021
		 ***/
		public void policyRenewalForAllLOB() throws Exception {
//			NavigatorQuoteIssued _qIssued = new NavigatorQuoteIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorBinderIssued _bIssued = new NavigatorBinderIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			NavigatorPolicyIssued _pIssued = new NavigatorPolicyIssued(_Browser, _objDetailedReport, _testDataManage, null);
//			_qIssued.setRenewalQuoteIssuedForAll("S");
//			_bIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag);
//			_pIssued.setPolicyIssued("BI", _issuedFlag);
		}
		
		//Extra Methods
		public void delInProgress() throws Exception {
//			String insuredName = _testDataManage.getData("GenericData", "Insured Name");
//			NavigatorMyWorkPage _nMyWorkPage = new NavigatorMyWorkPage(_Browser, _objDetailedReport, _testDataManage, null);
//			_nMyWorkPage.editByNameAndAccountStatus(insuredName, "QIP", _objDetailedReport, "Delete In Progress");
//			_nMyWorkPage.clickOnProdeedYesButton();
//			waitforPreLoaderToWait();
		}
		
		public void delBindInProgress() throws Exception {
//			String insuredName = _testDataManage.getData("GenericData", "Insured Name");
//			NavigatorMyWorkPage _nMyWorkPage = new NavigatorMyWorkPage(_Browser, _objDetailedReport, _testDataManage, null);
//			_nMyWorkPage.editByNameAndAccountStatus(insuredName, "BIP", _objDetailedReport, "Delete In Progress");
//			_nMyWorkPage.clickOnProdeedYesButton();
//			waitforPreLoaderToWait();
		}
		
		public void issuePolicyFinally() throws Exception {
			
//			String insuredName = _testDataManage.getData("GenericData", "Insured Name");
//			NavigatorMyWorkPage _nMyWorkPage = new NavigatorMyWorkPage(_Browser, _objDetailedReport, _testDataManage, null);
//			DocumentReviewPage _dReviewPage = new DocumentReviewPage(_Browser, _objDetailedReport, _testDataManage, null);
//			
//				_nMyWorkPage.editByNameAndAccountStatus(insuredName, "PIP", _objDetailedReport, "Document Review");
//				_dReviewPage.setDocumentReviewPage(1);
				
		}
			

}
