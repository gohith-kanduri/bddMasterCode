
/*
 * Author - Chandni  Dulani
 * Date - 24-NOV-2020
 * Purpose- Contains the OS LIST.
 */

package com.enums;

public enum OS {

	WINDOW,
	MAC
}
