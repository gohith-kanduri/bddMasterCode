
/*
 * Author - Chandni  Dulani
 * Date - 24-NOV-2020
 * Purpose- Contains the Browser LIST.
 */

package com.enums;

public enum Browsers {
	
	CHROME,
	FIREFOX,
	IE

}
