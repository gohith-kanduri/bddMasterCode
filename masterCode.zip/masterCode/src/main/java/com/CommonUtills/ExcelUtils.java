package com.CommonUtills;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
public class ExcelUtils {

	String filePath = System.getProperty("user.dir")+ "//VerifyTestMethods.xls";



	public String getData(String sheetName,int rowIndex,int columnIndex){
		FileInputStream fis = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet;
		String data = null;
		File file=new File(filePath);
		try {
			fis = new FileInputStream(file);
			workbook = new HSSFWorkbook(fis);
			sheet = workbook.getSheet("MethodExecution");
			HSSFRow row = sheet.getRow(rowIndex);
			data = row.getCell(columnIndex).getStringCellValue();

		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return data;
	}

	public void putData(int rowIndex,String columnHeaderName,String value){
		FileInputStream fis = null;
		FileOutputStream fos = null ;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet;

		String sheetName = "MethodExecution";
		int columnIndex = getHeaderColumnIndex(columnHeaderName);

		File file=new File(filePath);
		try {
			fis = new FileInputStream(file);
			workbook = new HSSFWorkbook(fis);
			sheet = workbook.getSheet(sheetName);
			HSSFRow row = sheet.getRow(rowIndex);
			row.createCell(columnIndex).setCellValue(value);
			fos = new FileOutputStream(filePath);
			workbook.write(fos);

		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void putMultipleData(int rowFrom, int rowTo, String columnHeadeName, String value){
		FileInputStream fis = null;
		FileOutputStream fos = null ;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet;
		String sheetName = "MethodExecution";
		int columnNumber = getHeaderColumnIndex(columnHeadeName);


		File file=new File(filePath);
		try {
			fis = new FileInputStream(file);
			workbook = new HSSFWorkbook(fis);
			sheet = workbook.getSheet(sheetName);

			for (int rowIndex = rowFrom; rowIndex < rowTo; rowIndex++) {
				HSSFRow row = sheet.getRow(rowIndex);
				row.createCell(columnNumber).setCellValue(value);
				fos = new FileOutputStream(filePath);
				workbook.write(fos);
			}


		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public int getHeaderColumnIndex(String headerName){
		FileInputStream fis = null;
		FileOutputStream fos = null ;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet;
		int cellIndex = 0;
		int cellNumebr = 0;

		String sheetName = "MethodExecution";

		File file=new File(filePath);
		try {
			fis = new FileInputStream(file);
			workbook = new HSSFWorkbook(fis);
			sheet = workbook.getSheet(sheetName);

			HSSFRow row = sheet.getRow(0);
			for (int columnIndex = 0; columnIndex < row.getLastCellNum(); columnIndex++) {
				String cellData = row.getCell(columnIndex).getStringCellValue();
				if (headerName.equalsIgnoreCase(cellData)) {
					cellIndex = cellNumebr;
					break;
				}else{
					cellNumebr++;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return cellIndex;
	}
}
