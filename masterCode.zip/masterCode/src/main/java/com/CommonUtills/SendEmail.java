package com.CommonUtills;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class SendEmail {
      
	
	Properties property;
	
	String BatPath= "C:\\Users\\LTI1061\\eclipse-workspace\\GlobalSpecialtyBddFW\\src\\main\\resources\\VB_Scripts\\SendEmail.BAT"; //System.getProperty("user.dir") +"src\\main\\resources\\VB_Scripts\\SendEmail.BAT";
	String DestinationPath=	"C:\\Users\\LTI1061\\eclipse-workspace\\GlobalSpecialtyBddFW\\target\\Extend\\report.html";
	public static  ConfigFileReader configFileReader ;
	public void SendMail() throws IOException, InterruptedException
	{     
		
		configFileReader = new  ConfigFileReader() ;
		String ResultsEmailTo=configFileReader.getEmailTo();
		String ResultsEmailcc=configFileReader.getEmailCC();
		System.out.println(ResultsEmailTo   +" ---"+ResultsEmailcc);
			
			  System.out.println(BatPath +" BatPath----- "+ DestinationPath );
			  String[] command = { "cmd.exe", "/C", "Start", BatPath, ResultsEmailTo+"_"+ResultsEmailcc,DestinationPath }; 
			  System.out.println(command); 
			  Process p = Runtime.getRuntime().exec(command);
					  p.waitFor();
					//  p.destroy();
			 
	}
	
}
