package com.CommonUtills;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

 // Purnendu Kumar, 4/12/2020
public class TestDataManage_old {
	public  HSSFWorkbook workbook;
	public  HSSFSheet sheet;
	
	public String path;
	public String sheetname;
	public String columnname;
	public String testname;
	public TestDataManage_old(String path, String sheetname, String columnname, String testname) {
		this.path=path;
		this.sheetname=sheetname;
		this.columnname=columnname;
		this.testname=testname;
	}
	
	
             public String getData(String requiredColumn) throws IOException {
 	        	
            	 
 			try {
					workbook=new HSSFWorkbook(new FileInputStream(new File(path)));
				} catch (Exception e) {
					
					e.printStackTrace();
				}
 			int sheets=workbook.getNumberOfSheets();
 			String CellVal="";
 			for(int i=0;i<sheets;i++)
 			{
 				if(workbook.getSheetName(i).equalsIgnoreCase(sheetname))
 				{
 					HSSFSheet sheet=workbook.getSheetAt(i);
 					Iterator<Row> rows = sheet.iterator();
 					Row firstrow=rows.next();
 					Iterator<Cell> ce = firstrow.cellIterator();
 					
 					int k=0;
 					int column=0;
 					while(ce.hasNext())
 					{
 					Cell value = ce.next();
 					if(value.getStringCellValue().equalsIgnoreCase(columnname))
 					{
 						column=k;					
 					}
 					k++;
 					}
 					
 					int c=1;
 					int rowNum=1;
 					while(rows.hasNext())
 					{
 						Row r=rows.next();
 						
 						if(r.getCell(column).getStringCellValue().equalsIgnoreCase(testname))
 						{
 							
 							rowNum=c;	
 						}
 						c++;
 					}
 					Iterator<Cell> ce2 = firstrow.cellIterator();
 					int j=0;
 					int reqcol=0;
 					while(ce2.hasNext())
						{
							
 						if(ce2.next().getStringCellValue().equalsIgnoreCase(requiredColumn))
							{
 						reqcol=j;
							CellVal=sheet.getRow(rowNum).getCell(reqcol).getStringCellValue();

							}
 						j++;
						}
					
 					
 				}            				
 				
 			} return CellVal;

 		
  }
	


}
