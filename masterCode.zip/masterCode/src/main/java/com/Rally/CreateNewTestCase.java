package com.Rally;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;

import com.rallydev.rest.RallyRestApi;

/*Author: Krishna Kotha; 
 *Date:27-May-2021
 *Description: Create New Test Case for UserStory
 **/
public class CreateNewTestCase extends RallyUtils{
	
	public  void createTestCaseforUserStory()
			throws URISyntaxException, IOException, FileNotFoundException {

		RallyRestApi restApi = getRestApi();
		
		String userRef = getUserRef(restApi, USER_EMAIL);

		String userName = getUserName(restApi, USER_EMAIL);

		String workSpaceRef = getWorkSpaceRef(restApi, WORKSPACE);

		String projectRef = getProjectRef(restApi, PROJECT_NAME);
		
		String iterationTestFolderRef = getTestFolderRef(restApi, TEST_FOLDER);
		
		String userStoryRef = getUserStoryRef(restApi, USER_STORY_ID);
		
		createNewTestCaseForUserStory(restApi,workSpaceRef, userRef, projectRef, userStoryRef,iterationTestFolderRef);
	}
	
}
