package com.Rally;

import com.SeleniumUtils.TestDataManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rallydev.rest.RallyRestApi;
import com.rallydev.rest.request.CreateRequest;
import com.rallydev.rest.request.DeleteRequest;
import com.rallydev.rest.request.GetRequest;
import com.rallydev.rest.request.QueryRequest;
import com.rallydev.rest.request.UpdateRequest;
import com.rallydev.rest.response.CreateResponse;
import com.rallydev.rest.response.DeleteResponse;
import com.rallydev.rest.response.GetResponse;
import com.rallydev.rest.response.QueryResponse;
import com.rallydev.rest.response.UpdateResponse;
import com.rallydev.rest.util.Fetch;
import com.rallydev.rest.util.QueryFilter;
import com.rallydev.rest.util.Ref;

import java.io.RandomAccessFile;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.commons.codec.binary.Base64;
/*Author: Krishna Kotha; 
 *Date:27-May-2021
 *Description: Create New Defect for user story, if the test run fails
 **/
public class CreateNewDefectWithAttachment extends RallyUtils {


	public  void createDefectWithReportAttachment()
			throws URISyntaxException, IOException, FileNotFoundException {

		RallyRestApi restApi = getRestApi();
		
		String userRef = getUserRef(restApi, USER_EMAIL);

		String userName = getUserName(restApi, USER_EMAIL);

		String workSpaceRef = getWorkSpaceRef(restApi, WORKSPACE);

		String projectRef = getProjectRef(restApi, PROJECT_NAME);

		String testCaseRef = getTestCaseRef(restApi, TC_ID, WORKSPACE);

		String userStoryRef = getUserStoryRef(restApi, USER_STORY_ID);

		createDefectWithReportAttachmentForUserStory(restApi, userRef, projectRef, userStoryRef);
	}
	public void doNotDelete() {
		String SERVER = "https://rally1.rallydev.com/";
		String API_KEY = "_cCXu3OZQQhqvSGYsDyrde5eGcPG90MemPAI6v2Y90w";
		String WORKSPACE_REF = "Global Specialty";
		String PROJECT_REF = "Squishy Blue Dolphins";
		String APPLICATION_NAME = "Squishy Blue Dolphins";
		String WSAPI_VERSION = "v2.0";
		String USER_EMAIL = "krishna.kotha@thehartford.com";
		String PROXY_SERVER = null;
		String PROXY_USERNAME = null;
		String PROXY_PASSWORD = null;
		String USER_STORY_ID = "US15756";
		String TC_ID = "TC7129";
		String BUILD_NUMBER = "1.0";

	}

}
