package com.Rally;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.WebDriver;

import com.SeleniumUtils.SeleniumUtils;
import com.SeleniumUtils.TestDataManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rallydev.rest.RallyRestApi;
import com.rallydev.rest.request.CreateRequest;
import com.rallydev.rest.request.QueryRequest;
import com.rallydev.rest.response.CreateResponse;
import com.rallydev.rest.response.QueryResponse;
import com.rallydev.rest.util.Fetch;
import com.rallydev.rest.util.QueryFilter;
import com.rallydev.rest.util.Ref;

import junit.framework.Assert;

/*
 * Krishna Kotha: 15th-may-2021
 * Description: Common methods for Rally TestCases, User Stories and Defects
 */
public class RallyUtils extends SeleniumUtils {

	static TestDataManager _testDataManage = new TestDataManager();

	public RallyUtils() {
	}

	final String SERVER = _testDataManage.getData("Rally_TestData", "Rally_Url");
	final String WSAPI_VERSION = _testDataManage.getData("Rally_TestData", "WsApi_Version");
	final String API_KEY = _testDataManage.getData("Rally_TestData", "API_Key");
	final String USER_EMAIL = _testDataManage.getData("Rally_TestData", "User_Email");
	final String WORKSPACE = _testDataManage.getData("Rally_TestData", "WorkSpace_Name");
	final String PROJECT_NAME = _testDataManage.getData("Rally_TestData", "Project_Name");
	final String TEST_FOLDER = _testDataManage.getData("Rally_TestData", "IterationFolderName");
	final String USER_STORY_ID = _testDataManage.getData("Rally_TestData", "Rally_UserStory_ID");
	final String TC_ID = _testDataManage.getData("Rally_TestData", "Rally_TC_ID");
	String BUILD_NUMBER = _testDataManage.getData("Rally_TestData", "Build_Number");
	final String PROXY_SERVER = null;
	final String PROXY_USERNAME = null;
	final String PROXY_PASSWORD = null;

	public  RallyRestApi getRestApi() throws URISyntaxException {
		RallyRestApi restApi = null;
		if (API_KEY != null && !API_KEY.equals("")) {
			restApi = new RallyRestApi(new URI(SERVER), API_KEY);
		}
		if (PROXY_SERVER != null) {
			URI uri = new URI(PROXY_SERVER);
			if (PROXY_USERNAME != null) {
				restApi.setProxy(uri, PROXY_USERNAME, PROXY_PASSWORD);
			} else {
				restApi.setProxy(uri);
			}
		}
		//restApi.setWsapiVersion(WSAPI_VERSION);
		restApi.setApplicationName(PROJECT_NAME);
		return restApi;
	}
	protected static String getUserName(RallyRestApi restApi, String USER_EMAIL) throws IOException {
		System.out.println("Getting User Name..");
		QueryRequest userRequest = new QueryRequest("User");
		userRequest.setFetch(new Fetch("UserName", "Subscription", "DisplayName"));
		userRequest.setQueryFilter(new QueryFilter("UserName", "=", USER_EMAIL));
		QueryResponse userQueryResponse = restApi.query(userRequest);
		JsonArray userQueryResults = userQueryResponse.getResults();
		JsonElement userQueryElement = userQueryResults.get(0);
		JsonObject userQueryObject = userQueryElement.getAsJsonObject();
		String userName = userQueryObject.get("_refObjectName").getAsString();
		System.out.println("User Name: " + userName);
		return userName;
	}
	protected static String getUserRef(RallyRestApi restApi, String USER_EMAIL) throws IOException {
		System.out.println("Getting User Reference..");
		QueryRequest userRequest = new QueryRequest("User");
		userRequest.setFetch(new Fetch("UserName", "Subscription", "DisplayName"));
		userRequest.setQueryFilter(new QueryFilter("UserName", "=", USER_EMAIL));
		QueryResponse userQueryResponse = restApi.query(userRequest);
		JsonArray userQueryResults = userQueryResponse.getResults();
		JsonElement userQueryElement = userQueryResults.get(0);
		JsonObject userQueryObject = userQueryElement.getAsJsonObject();
		String userRef = userQueryObject.get("_ref").getAsString();
		System.out.println("User Ref: " + userRef);
		return userRef;
	}
	protected static String getTestCaseRef(RallyRestApi restApi, final String TC_ID, final String workSpaceRef)
			throws IOException {
		QueryRequest testCaseRequest = new QueryRequest("TestCase");
		testCaseRequest.setFetch(new Fetch("FormattedID", "Name"));
		testCaseRequest.setWorkspace(workSpaceRef);
		testCaseRequest.setQueryFilter(new QueryFilter("FormattedID", "=", TC_ID));
		QueryResponse testCaseQueryResponse = restApi.query(testCaseRequest);
		System.out.println("TestCase RestAPI: " + testCaseQueryResponse.getResults());
		JsonObject testCaseJsonObject = testCaseQueryResponse.getResults().get(0).getAsJsonObject();
		String testCaseRef = testCaseJsonObject.get("_ref").getAsString();
		System.out.println("TestCase Response: " + testCaseRef);
		return testCaseRef;
	}

	protected static String getUserStoryRef(RallyRestApi restApi, String USER_STORY_ID) throws IOException {
		System.out.println("Getting User Story Reference..");
		QueryRequest userStoryRequest = new QueryRequest("HierarchicalRequirement");
		userStoryRequest.setFetch(new Fetch("FormattedID", "Name"));
		userStoryRequest.setQueryFilter(new QueryFilter("FormattedID", "=", USER_STORY_ID));
		QueryResponse userStoryQueryResponse = restApi.query(userStoryRequest);
		JsonObject existUserStoryJsonObject = userStoryQueryResponse.getResults().get(0).getAsJsonObject();
		String userStoryRef = existUserStoryJsonObject.getAsJsonObject().get("_ref").getAsString();
		System.out.println("User Story Ref: " + userStoryRef);
		return userStoryRef;
	}
	protected static String getTestFolderRef(RallyRestApi restApi, String testFolder) throws IOException {
		System.out.println("Getting User Story Reference..");
		QueryRequest userStoryRequest = new QueryRequest("TestFolder");
		userStoryRequest.setFetch(new Fetch("FormattedID", "Name"));
		userStoryRequest.setQueryFilter(new QueryFilter("FormattedID", "=",testFolder)); //Sprint202108 
		QueryResponse userStoryQueryResponse = restApi.query(userStoryRequest);
		JsonObject existUserStoryJsonObject = userStoryQueryResponse.getResults().get(0).getAsJsonObject();
		String userStoryRef = existUserStoryJsonObject.getAsJsonObject().get("_ref").getAsString();
		System.out.println("User Story Ref: " + userStoryRef);
		return userStoryRef;
	}
	protected static String getProjectRef(RallyRestApi restApi, String PROJECT_REF) throws IOException {
		System.out.println("Getting Project Reference..");
		QueryRequest projectRequest = new QueryRequest("Project");
		projectRequest.setFetch(new Fetch("Name", "Owner", "Projects"));
		projectRequest.setQueryFilter(new QueryFilter("Name", "=", PROJECT_REF));
		QueryResponse projectQueryResponse = restApi.query(projectRequest);
		String projectRef = projectQueryResponse.getResults().get(0).getAsJsonObject().get("_ref").getAsString();
		System.out.println("Project Ref: " + projectRef);
		return projectRef;
	}

	protected static String getWorkSpaceRef(RallyRestApi restApi, String WORKSPACE_REF) throws IOException {
		System.out.println("Getting WorkSpace Reference..");
		QueryRequest workspaceRequest = new QueryRequest("Workspace");
		workspaceRequest.setFetch(new Fetch("Name", "Owner", "Projects"));
		workspaceRequest.setQueryFilter(new QueryFilter("Name", "=", WORKSPACE_REF));
		QueryResponse workspaceQueryResponse = restApi.query(workspaceRequest);
		String workspaceRef = workspaceQueryResponse.getResults().get(0).getAsJsonObject().get("_ref").getAsString();
		System.out.println("WorkSpace Ref: " + workspaceRef);
		return workspaceRef;
	}
	protected void createNewTestCaseForUserStory(RallyRestApi restApi,String workSpaceRef, String userRef,
			String projectRef, String userStoryRef,String iterationFolderRef)  {
		String testcaseDescription = _testDataManage.getData("GenericData", "Description");
		try {
			String scenarioName = System.getProperty("ScenarioName");
		System.out.println("Creating TestCase..!");
		JsonObject newTestCase = new JsonObject();
		newTestCase.addProperty("Name", scenarioName+": Created By Automation Script"); //"Test Case Created By Automation Script..!"
		newTestCase.addProperty("Owner", userRef);
		newTestCase.addProperty("Project", projectRef);
		newTestCase.addProperty("TestFolder", iterationFolderRef);
		newTestCase.addProperty("WorkProduct", userStoryRef);
		newTestCase.addProperty("Type", "Functional");
		newTestCase.addProperty("Method", "Automated"); 
		newTestCase.addProperty("Priority", "None"); 
		newTestCase.addProperty("Description",testcaseDescription);
		newTestCase.addProperty("Notes", "The test case  has been created by Automation script..!");
		newTestCase.addProperty("Objective", "The test case  has been created by Automation script..!");
		newTestCase.addProperty("Pre-Conditions", "The test case  has been created by Automation script..!");
	
		CreateRequest newTestCaseRequest = new CreateRequest("TestCase", newTestCase);
		CreateResponse createResponse = restApi.create(newTestCaseRequest);
		if (createResponse.wasSuccessful()) {
			String testCaseID = createResponse.getObject().get("FormattedID").getAsString();
			String tcRef = getTestCaseRef(restApi, testCaseID, workSpaceRef);
			String reltiveTcRef = Ref.getRelativeRef(createResponse.getObject().get("_ref").getAsString());
			System.out.println(String.format("Test Case ID: %s", testCaseID));
			System.out.println(String.format("Test Case Ref: %s", tcRef));
			_testDataManage.putDatasheet("Rally_TC_Ref", "Rally_TestData", tcRef);
			_testDataManage.putDatasheet("Rally_TC_ID", "Rally_TestData", testCaseID);
			System.out.println("Testcase ID stored in Tetdata sheet: "+ testCaseID);
			//attachReportToDefect(restApi, userRef, relativeDefectRef);
		} else {
			String[] createErrors;
			createErrors = createResponse.getErrors();
			System.out.println("Error occurred creating a defect: ");
			for (int j = 0; j < createErrors.length; j++) {
				System.out.println(createErrors[j]);
			}
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	protected void createDefectWithReportAttachmentForUserStory(RallyRestApi restApi, String userRef,
			String userName, String userStoryRef) throws IOException, FileNotFoundException {
		String tcRef = _testDataManage.getData("Rally_TestData", "Rally_TC_Ref");
		System.out.println("Creating Defect..!");
		JsonObject newDefect = new JsonObject();
		newDefect.addProperty("Name", "Defect Created By Automation Script");
		newDefect.addProperty("Owner", userRef);
		newDefect.addProperty("SubmittedBy", userRef);
		newDefect.addProperty("TestCase", tcRef);
		newDefect.addProperty("Priority", "Low"); // High Attention
		newDefect.addProperty("Severity", "Minor Problem"); // Major Problem
		//newDefect.addProperty("Requirement", userStoryRef);
		newDefect.addProperty("Description",
				"This Defect has been created by Automation script..Please refer attached Report for more details.!");
		newDefect.addProperty("Notes", "This Defect has been created by Automation script..!");

		CreateRequest defectCreateRequest = new CreateRequest("defect", newDefect);
		CreateResponse createResponse = restApi.create(defectCreateRequest);
		if (createResponse.wasSuccessful()) {
			String defectID = createResponse.getObject().get("FormattedID").getAsString();
			String defectRef = createResponse.getObject().get("_ref").getAsString();
			String relativeDefectRef = Ref.getRelativeRef(defectRef);
			System.out.println(String.format("Defect ID: %s", defectID));
			System.out.println(String.format("Defect Ref: %s", relativeDefectRef));
			System.out.println(String.format("Relative Defect Ref %s", defectRef));
			attachReportToDefect(restApi, userRef, relativeDefectRef);
		} else {
			String[] createErrors;
			createErrors = createResponse.getErrors();
			System.out.println("Error occurred creating a defect: ");
			for (int j = 0; j < createErrors.length; j++) {
				System.out.println(createErrors[j]);
			}
		}
	}
	protected static void updateTestCaseResultWithAttachment(String testCaseReult, final String workSpafeRef,
			String BUILD_NUMBER, RallyRestApi restApi, String userRef, String testCaseRef)
			throws IOException, URISyntaxException {
		try {
			System.out.println("Creating Test Case Result...");
			JsonObject newTestCaseResult = new JsonObject();
			newTestCaseResult.addProperty("Verdict", testCaseReult);
			newTestCaseResult.addProperty("Date", getTodayDateAndTime());
			newTestCaseResult.addProperty("Notes", "The Test Case has run by Automation Scripts..!");
			newTestCaseResult.addProperty("Build", BUILD_NUMBER);
			newTestCaseResult.addProperty("Tester", userRef);
			newTestCaseResult.addProperty("TestCase", testCaseRef);
			newTestCaseResult.addProperty("Method", "Automated");
			newTestCaseResult.addProperty("Workspace", workSpafeRef);

			CreateRequest createRequest = new CreateRequest("testcaseresult", newTestCaseResult);
			CreateResponse createResponse = restApi.create(createRequest);
			
			if (createResponse.wasSuccessful()) {
				System.out.println("Attachmenting Report to Test Case");
				attachReportToTestCase(restApi, createResponse.getObject().get("_ref").getAsString(), userRef, workSpafeRef);
			} else {
				String[] createErrors;
				createErrors = createResponse.getErrors();
				System.out.println("Error occurred creating Test Case Result: ");
				for (int i = 0; i < createErrors.length; i++) {
					System.out.println(createErrors[i]);
				}
			}

		} finally {
			restApi.close();
		}
	}
	
	protected static void attachReportToTestCase(RallyRestApi restApi, String testCaseResultRef, String userRef, String workspaceRef)
			throws URISyntaxException, IOException {

		String imageFilePath = System.getProperty("user.dir") + "\\target\\Extent\\";
		String imageFileName = "Report.html";
		String fullImageFile = imageFilePath + imageFileName;
		String imageBase64String;
		long attachmentSize;

		// Open file
		RandomAccessFile myImageFileHandle = new RandomAccessFile(fullImageFile, "r");

		try {
			long longLength = myImageFileHandle.length();
			long maxLength = 5000000;
			if (longLength >= maxLength)
				throw new IOException("File size >= 5 MB Upper limit for Rally.");
			int fileLength = (int) longLength;

			// Read file and return data
			byte[] fileBytes = new byte[fileLength];
			myImageFileHandle.readFully(fileBytes);
			imageBase64String = Base64.encodeBase64String(fileBytes);
			attachmentSize = fileLength;

			// First create AttachmentContent from image string
			JsonObject myAttachmentContent = new JsonObject();
			myAttachmentContent.addProperty("Content", imageBase64String);
			CreateRequest attachmentContentCreateRequest = new CreateRequest("AttachmentContent", myAttachmentContent);
			attachmentContentCreateRequest.addParam("workspace", workspaceRef);
			CreateResponse attachmentContentResponse = restApi.create(attachmentContentCreateRequest);
			String myAttachmentContentRef = attachmentContentResponse.getObject().get("_ref").getAsString();
			System.out.println("Attachment Content created: " + myAttachmentContentRef);

			// Now create the Attachment itself
			JsonObject myAttachment = new JsonObject();
			myAttachment.addProperty("TestCaseResult", testCaseResultRef);
			myAttachment.addProperty("Content", myAttachmentContentRef);
			myAttachment.addProperty("Name", "Report.html");
			myAttachment.addProperty("Description", "Attachment From Automation Script");
			myAttachment.addProperty("ContentType", "image/png");
			myAttachment.addProperty("Size", attachmentSize);
			myAttachment.addProperty("User", userRef);

			CreateRequest attachmentCreateRequest = new CreateRequest("Attachment", myAttachment);
			attachmentCreateRequest.addParam("workspace", workspaceRef);
			CreateResponse attachmentResponse = restApi.create(attachmentCreateRequest);
			String myAttachmentRef = attachmentResponse.getObject().get("_ref").getAsString();
			System.out.println("Attachment  created: " + myAttachmentRef);
			if (attachmentResponse.wasSuccessful()) {
				System.out.println("Successfully created Attachment..!");
			} else {
				String[] attachmentContentErrors;
				attachmentContentErrors = attachmentResponse.getErrors();
				System.out.println("Error occurred creating Attachment: ");
				for (int j = 0; j < attachmentContentErrors.length; j++) {
					System.out.println(attachmentContentErrors[j]);
				}
			}
		} catch (Exception e) {
			System.out.println("Exception occurred while attempting to create Content and/or Attachment: ");
			e.printStackTrace();
		}
	}
	protected void attachReportToUserStory(RallyRestApi restApi, String userRef, String userStoryRef)
			throws IOException {
		String imageFilePath = System.getProperty("user.dir") + "\\target\\Extent\\";
		String imageFileName = "Report.html";
		String fullImageFile = imageFilePath + imageFileName;
		String imageBase64String;
		long attachmentSize;

		try {
			// Open file
			RandomAccessFile myImageFileHandle = new RandomAccessFile(fullImageFile, "r");
			// Get and check length
			long longlength = myImageFileHandle.length();
			// Max upload size for Rally attachments is 5MB
			long maxAttachmentLength = 5120000;
			if (longlength > maxAttachmentLength)
				throw new IOException("File size too big for Rally attachment, > 5 MB");

			// Read file and return data
			byte[] fileBytes = new byte[(int) longlength];
			myImageFileHandle.readFully(fileBytes);
			imageBase64String = Base64.encodeBase64String(fileBytes);
			attachmentSize = longlength;

			// First create AttachmentContent from image string
			JsonObject myAttachmentContent = new JsonObject();
			myAttachmentContent.addProperty("Content", imageBase64String);
			CreateRequest attachmentContentCreateRequest = new CreateRequest("AttachmentContent", myAttachmentContent);
			CreateResponse attachmentContentResponse = restApi.create(attachmentContentCreateRequest);
			String myAttachmentContentRef = attachmentContentResponse.getObject().get("_ref").getAsString();
			System.out.println("Attachment Content created: " + myAttachmentContentRef);

			// Now create the Attachment itself
			JsonObject myAttachment = new JsonObject();
			myAttachment.addProperty("Artifact", userStoryRef);
			myAttachment.addProperty("Content", myAttachmentContentRef);
			myAttachment.addProperty("Name", "Report.html");
			myAttachment.addProperty("Description", "Attachment from Automation script");
			myAttachment.addProperty("ContentType", "html/png");
			myAttachment.addProperty("Size", attachmentSize);
			myAttachment.addProperty("User", userRef);

			CreateRequest attachmentCreateRequest = new CreateRequest("Attachment", myAttachment);
			CreateResponse attachmentResponse = restApi.create(attachmentCreateRequest);
			String myAttachmentRef = attachmentResponse.getObject().get("_ref").getAsString();
			System.out.println("Attachment  created: " + myAttachmentRef);

			if (attachmentResponse.wasSuccessful()) {
				System.out.println("Successfully created Attachment");
			} else {
				String[] attachmentContentErrors;
				attachmentContentErrors = attachmentResponse.getErrors();
				System.out.println("Error occurred creating Attachment: ");
				for (int i = 0; i < attachmentContentErrors.length; i++) {
					System.out.println(attachmentContentErrors[i]);
				}
			}
		} catch (Exception e) {
			System.out.println("Exception occurred while attempting to create Content and/or Attachment: ");
			e.printStackTrace();
		}

		finally {
			restApi.close();
		}
	}

	
	protected static void attachReportToDefect(RallyRestApi restApi, String userRef, String defectRelativeRef)
			throws FileNotFoundException {
		System.out.println("Attaching Report to Defect..");
		String imageFilePath = System.getProperty("user.dir") + "\\target\\Extent\\";
		String imageFileName = "Report.html";
		String fullImageFile = imageFilePath + imageFileName;
		String imageBase64String;
		long attachmentSize;

		RandomAccessFile myImageFileHandle = new RandomAccessFile(fullImageFile, "r");
		try {
			long longLength = myImageFileHandle.length();
			long maxLength = 5000000;
			if (longLength >= maxLength)
				throw new IOException("File size >= 5 MB Upper limit for Rally.");
			int fileLength = (int) longLength;

			// Read file and return data
			byte[] fileBytes = new byte[fileLength];
			myImageFileHandle.readFully(fileBytes);
			imageBase64String = Base64.encodeBase64String(fileBytes);
			attachmentSize = fileLength;

			// First create AttachmentContent from image string
			JsonObject myAttachmentContent = new JsonObject();
			myAttachmentContent.addProperty("Content", imageBase64String);
			CreateRequest attachmentContentCreateRequest = new CreateRequest("AttachmentContent", myAttachmentContent);
			CreateResponse attachmentContentResponse = restApi.create(attachmentContentCreateRequest);
			String myAttachmentContentRef = attachmentContentResponse.getObject().get("_ref").getAsString();
			System.out.println("Attachment Content created: " + myAttachmentContentRef);

			// Now create the Attachment itself
			JsonObject myAttachment = new JsonObject();
			myAttachment.addProperty("Artifact", defectRelativeRef);
			myAttachment.addProperty("Content", myAttachmentContentRef);
			myAttachment.addProperty("Name", "Report.html");
			myAttachment.addProperty("Description", "Attached from Automation Script");
			myAttachment.addProperty("ContentType", "html/png");
			myAttachment.addProperty("Size", attachmentSize);
			myAttachment.addProperty("User", userRef);

			CreateRequest attachmentCreateRequest = new CreateRequest("Attachment", myAttachment);
			CreateResponse attachmentResponse = restApi.create(attachmentCreateRequest);
			String myAttachmentRef = attachmentResponse.getObject().get("_ref").getAsString();
			System.out.println("Attachment  created: " + myAttachmentRef);

			if (attachmentResponse.wasSuccessful()) {
				System.out.println("Successfully attached Report to Defect..!");
			} else {
				String[] attachmentContentErrors;
				attachmentContentErrors = attachmentResponse.getErrors();
				System.out.println("Error occurred creating Attachment: ");
				for (int j = 0; j < attachmentContentErrors.length; j++) {
					System.out.println(attachmentContentErrors[j]);
				}
			}
		} catch (Exception e) {
			System.out.println("Exception occurred while attempting to create Content and/or Attachment: ");
			e.printStackTrace();
		}

	}
	public static String getTodayDateAndTime() {
		TimeZone est = TimeZone.getTimeZone("America/New_York");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);  
		sdf.setTimeZone(est);
		Date date = new Date();  
		String todayDate =  sdf.format(date);
		System.out.println(todayDate);
		return todayDate;
	}
	public void doNotDelete() {

		// https://rally1.rallydev.com/slm/webservice/v2.0/workspace/321361512976
		// "https://rally1.rallydev.com/slm/webservice/v2.0/subscription/19315804245
		// https://rally1.rallydev.com/slm/webservice/v2.0/Workspace/321361512976/Projects
		// https://rally1.rallydev.com/slm/webservice/v2.0/user/336462366180
		// https://rally1.rallydev.com/slm/webservice/v2.0/Workspace/
		// https://rally1.rallydev.com/slm/webservice/v2.0/workspaceconfiguration/321361512976
		// https://rally1.rallydev.com/slm/webservice/v2.0/project/
		// https://rally1.rallydev.com/slm/webservice/v2.0/TestCaseResult/create

		/*
		 * protected static final String SERVER = "https://rally1.rallydev.com";
		 * protected static final String WSAPI_VERSION = "v2.0";
		 * 
		 * protected static final String API_KEY =
		 * "_cCXu3OZQQhqvSGYsDyrde5eGcPG90MemPAI6v2Y90w"; protected static final String
		 * USER_EMAIL = "krishna.kotha@thehartford.com"; protected static final String
		 * PROXY_SERVER = null; //protected static final String PROXY_SERVER =
		 * "//http://127.0.0.1:9000/localproxy-1620620421.pac";
		 * 
		 * protected static final String PROXY_USERNAME = null; protected static final
		 * String PROXY_PASSWORD = null; protected static final String WORKSPACE_REF =
		 * "/workspace/321361512976"; protected static final String PROJECT_REF =
		 * "/project/477697362132"; protected static final String APPLICATION_NAME =
		 * "Squishy Blue Dolphins"; protected static final String USER_STORY =
		 * "US15736"; protected static final String TC_ID ="TC5862";
		 */
	}

}
