package com.Rally;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.commons.codec.binary.Base64;

import com.SeleniumUtils.TestDataManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rallydev.rest.RallyRestApi;
import com.rallydev.rest.request.CreateRequest;
import com.rallydev.rest.request.QueryRequest;
import com.rallydev.rest.util.Fetch;
import com.rallydev.rest.response.CreateResponse;
import com.rallydev.rest.response.QueryResponse;
import com.rallydev.rest.util.QueryFilter;

public class RunTestCaseAndUpdateTestResults extends RallyUtils {
	
	public  void testcaseResultUpdate(String testCaseReult) throws URISyntaxException, IOException {

		RallyRestApi restApi = getRestApi();
		
       String userRef = getUserRef(restApi, USER_EMAIL);
		
		String userName = getUserName(restApi, USER_EMAIL);
        
		String workSpaceRef = getWorkSpaceRef(restApi, WORKSPACE);
		
		String projectRef = getProjectRef(restApi, PROJECT_NAME);
		
		String testCaseRef = getTestCaseRef(restApi, TC_ID, WORKSPACE);
		
		updateTestCaseResultWithAttachment(testCaseReult, workSpaceRef, BUILD_NUMBER, restApi, userRef, testCaseRef);

	}
	
	
	public void donotDelete() {
		/*
		 * String SERVER = "https://rally1.rallydev.com/"; String API_KEY =
		 * "_cCXu3OZQQhqvSGYsDyrde5eGcPG90MemPAI6v2Y90w"; String WORKSPACE_REF =
		 * "/workspace/321361512976"; String PROJECT_REF = "/project/477697362132";
		 * String APPLICATION_NAME = "Squishy Blue Dolphins"; String WSAPI_VERSION =
		 * "v2.0"; String USER_EMAIL = "krishna.kotha@thehartford.com"; String
		 * PROXY_SERVER = null; String PROXY_USERNAME = null; String PROXY_PASSWORD =
		 * null; String TC_ID = "TC7129"; String BUILD_NUMBER = "1.0";
		 */
	}
}
