package com.Rally;

import com.SeleniumUtils.TestDataManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rallydev.rest.RallyRestApi;
import com.rallydev.rest.request.CreateRequest;
import com.rallydev.rest.request.DeleteRequest;
import com.rallydev.rest.request.GetRequest;
import com.rallydev.rest.request.QueryRequest;
import com.rallydev.rest.request.UpdateRequest;
import com.rallydev.rest.response.CreateResponse;
import com.rallydev.rest.response.DeleteResponse;
import com.rallydev.rest.response.GetResponse;
import com.rallydev.rest.response.QueryResponse;
import com.rallydev.rest.response.UpdateResponse;
import com.rallydev.rest.util.Fetch;
import com.rallydev.rest.util.QueryFilter;
import com.rallydev.rest.util.Ref;

import java.io.RandomAccessFile;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.commons.codec.binary.Base64;

/*Author: Krishna Kotha; 
 *Date:22nd-May-2021
 *Description: To attach execution Report for User Story
 **/
public class AttachReportForUserStory extends RallyUtils {

	public void attachExecutionReportForUserStory() throws URISyntaxException, IOException {

		RallyRestApi restApi = getRestApi();

		String userRef = getUserRef(restApi, USER_EMAIL);

		String userName = getUserName(restApi, USER_EMAIL);

		String workSpaceRef = getWorkSpaceRef(restApi, WORKSPACE);

		String projectRef = getProjectRef(restApi, PROJECT_NAME);

		String userStoryRef = getUserStoryRef(restApi, USER_STORY_ID);

		attachReportToUserStory(restApi, userRef, userStoryRef);
	}

	public  void attachReportToUserStory(RallyRestApi restApi, String userRef, String userStoryRef)
			throws IOException {
		String imageFilePath = System.getProperty("user.dir") + "\\target\\Extent\\";
		String imageFileName = "Report.html";
		String fullImageFile = imageFilePath + imageFileName;
		String imageBase64String;
		long attachmentSize;

		try {
			// Open file
			RandomAccessFile myImageFileHandle = new RandomAccessFile(fullImageFile, "r");
			// Get and check length
			long longlength = myImageFileHandle.length();
			// Max upload size for Rally attachments is 5MB
			long maxAttachmentLength = 5120000;
			if (longlength > maxAttachmentLength)
				throw new IOException("File size too big for Rally attachment, > 5 MB");

			// Read file and return data
			byte[] fileBytes = new byte[(int) longlength];
			myImageFileHandle.readFully(fileBytes);
			imageBase64String = Base64.encodeBase64String(fileBytes);
			attachmentSize = longlength;

			// First create AttachmentContent from image string
			JsonObject myAttachmentContent = new JsonObject();
			myAttachmentContent.addProperty("Content", imageBase64String);
			CreateRequest attachmentContentCreateRequest = new CreateRequest("AttachmentContent", myAttachmentContent);
			CreateResponse attachmentContentResponse = restApi.create(attachmentContentCreateRequest);
			String myAttachmentContentRef = attachmentContentResponse.getObject().get("_ref").getAsString();
			System.out.println("Attachment Content created: " + myAttachmentContentRef);

			// Now create the Attachment itself
			JsonObject myAttachment = new JsonObject();
			myAttachment.addProperty("Artifact", userStoryRef);
			myAttachment.addProperty("Content", myAttachmentContentRef);
			myAttachment.addProperty("Name", "Report.html");
			myAttachment.addProperty("Description", "Attachment from Automation script");
			myAttachment.addProperty("ContentType", "html/png");
			myAttachment.addProperty("Size", attachmentSize);
			myAttachment.addProperty("User", userRef);

			CreateRequest attachmentCreateRequest = new CreateRequest("Attachment", myAttachment);
			CreateResponse attachmentResponse = restApi.create(attachmentCreateRequest);
			String myAttachmentRef = attachmentResponse.getObject().get("_ref").getAsString();
			System.out.println("Attachment  created: " + myAttachmentRef);

			if (attachmentResponse.wasSuccessful()) {
				System.out.println("Successfully created Attachment");
			} else {
				String[] attachmentContentErrors;
				attachmentContentErrors = attachmentResponse.getErrors();
				System.out.println("Error occurred creating Attachment: ");
				for (int i = 0; i < attachmentContentErrors.length; i++) {
					System.out.println(attachmentContentErrors[i]);
				}
			}
		} catch (Exception e) {
			System.out.println("Exception occurred while attempting to create Content and/or Attachment: ");
			e.printStackTrace();
		}

		finally {
			restApi.close();
		}
	}

}
