package com.PageObjects.Glass_Ascend_NonFL_OR;


import org.openqa.selenium.By;

public class ApplicationCommonOR {

	//Krishna Kotha;Date:04-Sep-2019  //following-sibling
	public static final String DROP_DOWN_XPATH = ".//*[contains(text(),'%s')]/following-sibling::div//span[@class='selection']/span/span[1]"; 
	public final static By DROP_DOWN_TEXTBOX_XPATH = By.xpath(".//input[@class='select2-search__field']");//[@role='textbox']
	public static final String DROP_DOWN__LIST_XPATH = ".//*[@class='select2-results']/ul/li[contains(text(),'%s')]";//Krishna
	public static final String DROP_DOWN_XPATH_BY_PRECEEDING_TEXT= "//label[contains(text(),'%s')]/following-sibling::div/select";

	/*
	 * subjectivity Page OR
	 */

	public static final By RELOADER = By.xpath(".//*[@id='preloader'][@style='display: none;']"); 
	public static final String ERROR_VALIDATION_ACK = ".//*[@id='modal-error-block']/following-sibling::table//tr[%d]/td//input[@id='Acknowledged']";

	public static final By ERROR_ACK_TR = By.xpath(".//*[@id='modal-error-block']/following-sibling::table//tr//input[@id='Acknowledged'][@type='checkbox']"); 

    public static final By SAVE_FORMS = By.id("scenario-save");
	public static final By SUBJECTIVEITY_HEADER = By.xpath(".//*[@id='gview_selectedGrid']/*[@class='ui-jqgrid-hdiv']//th/div");
	public static final String RECIEVED_STRING = ".//*[@id='gview_selectedGrid']/*[@class='ui-jqgrid-bdiv']//tr[%d]";
	public static final String SUBSTRING_RECIEVED_CHECKBOX = "/td[%d]/input";
	public static final By RECIEVED_TR_LIST = By.xpath(".//*[@id='gview_selectedGrid']/*[@class='ui-jqgrid-bdiv']//tr");
	public static final By SUBJECTIVITY_CHECKBOX = By.xpath(".//*[@id='NoSubjectivitiesApply']");

	/* Component And Coverage Page OR 
	 /*
	 */
	public static final String EXCESS_HEADER_LIST_DIV = ".//*[@id='components-tab']//legend[contains(text(),'Excess')]/following-sibling::section[2]";
	public static final String EXCESS_HEADER_LIST = "//*[@class='ui-jqgrid-hdiv']//th/div";
	public static final By EXCESS_FINAL_HEADER_LIST = By.xpath(EXCESS_HEADER_LIST_DIV + EXCESS_HEADER_LIST);
	public static final String EXCESS_COMPONENT_NAME = ".//*[@id='components-tab']//legend[contains(text(),'Excess')]/following-sibling::section[2]//*[@class='ui-jqgrid-bdiv']//tr[2]/td[contains(text(),'%s')]";
	public static final String EXCESS_COMPONENT_EDIT_SECTION = "/../td[%d]";
	public static final By LIMITS_HEADER_CYBER = By.xpath(".//*[@id='gview_limits']//div[@class='ui-jqgrid-hdiv']//tr/th//div");
	public static final String LIMITS_EDIT_SECTION = ".//*[@id='gbox_limits']//tr[2]/td[%d]";

	/*
	 * Navigator Clearance Page OR 
	 */	

	public static final By CLEARANCE_RESULT = By.xpath(".//div[@class='modal-dialog']/div[@id='clearance-results-modal-content']");
	public static final By TEMP_IR_NUMBER = By.xpath(".//input[@id='temp-ir-number']");
	public static final String PROCEED_TO_QUOTE = ".//button[@type='button'][contains(text(),'%s')]";
	public static final  By IMAGERIGHT_PROCEED_POPUP = By.xpath(".//div[@class='modal-content']/div[@class='modal-footer']/button[contains(text(),'Proceed')][@id='modal-ir-not-found-proceed']");
	public static final By IR_NOT_FOUND_PROCEED =By.xpath(".//*[@id='modal-ir-not-found-proceed']");
	public static final String DECLINE_SUBMISSION_RESONS = ".//*[@id='decline-sub-reasons']/li/a[contains(text(),'%s')]";
	public static final String CLOSE_SUBMISSION_RESONS = ".//*[@id='close-sub-reasons']/li/a[contains(text(),'%s')]";
	public static final By VALIDATE_PACKAGE = By.xpath(".//*[@id='package-validate']");
	public static final By SAVE_PACKAGE= By.xpath(".//span[@id='package-save']");//Krishna 
	public static final By ACKNOWLEDGED=By.xpath("//input[@id='Acknowledged']");//Krishna
	public static final By CONTINUEBTNDOC=By.xpath("//button[@id='modal-finalizing-continue'][text()='Continue']");

	/*
	 * Login Page OR Date :- 08-01-2018 Author :- LNT
	 */
	public static final By LOGIN_EMAIL_TXT = By.name("Email");
	public static final By LOGIN_PWD_TXT = By.name("Password");
	public static final By LOGIN_BTN = By.xpath("//button[contains(text(),'Login')]");
	/*
	 * Navigator My Work Page
	 */
	public final static By ACTION_PROGRESS_MODAL = By.xpath(".//*[@id='action-progress-modal-body']");
	public final static By ACTION_PROGRESS_MODAL_CLOSE = By.xpath(".//*[@id='action-progress-modal-close']");
	//Added by Krishna Kotha 06-06-19
	public final static By CLEAR_CONTINUE= By.xpath(".//*[contains(text(),'Clear and Continue')]");//Krishna
	public final static By PROCEEDTO_QUOTE = By.xpath(".//button[@id='clearance-results-modal-proceed-to-quote']");//Krishna
	public final static By ACTION_PROGRESS_MODAL_PROCEED_YES = By.xpath(".//*[@id='action-progress-modal-proceed']");//Krishna
	
	public final static By ACTION_MESSAGE = By.xpath(".//*[@id='quote-processed-alert']//h4");
	public final static String INSUREDNAME = "Insured Name";
	public final static String INSUREDNAME_GLASS = "Primary Insured Name";
	public final static String ACTIONS = "Actions";
	public final static String STATUS = "Status";
	public final static By ACTIONS_DROPDOWN = By.xpath(".//button[contains(text(),'Actions')]");
	public final static By ACTIONS_LIST = By.xpath(".//*[@id='myWorkGridParent']//*[@class='ui-jqgrid-bdiv']//*[@id='myWorkGrid']//tr");
	public final static By HEADER_NAME = By
			.xpath(".//*[@id='gview_myWorkGrid']//*[@class='ui-jqgrid-hdiv']//table/thead/tr[1]/th/div");
	public final static By STATUS_TEXT = By.xpath(".//div[starts-with(text(),'Status')]");
	public final static By ASCNEND_REFNUMBER = By.id("gs_ReferenceNumber");//Krishna
	public final static By ASCNEND_INSUREDNAME = By.id("gs_InsuredName");//Krishna
	
	public final static By STATUS_SELECT_DROPDOWN = By.xpath("//*[@id='gs_RiskStatusName']");
	public final static By INCEPTION_DROPDOWN = By.xpath(".//*[@id='gs_EffectiveDateDisplay']");
	public final static String TABLE_SEARCHFILTER = ".//*[@id='gview_myWorkGrid']//*[@class='ui-jqgrid-hdiv']//table/thead/tr[2]/th[%d]/div/*[@class='ui-search-table']/tbody/tr/td/input";
	public final static By REF_TEXTBOX = By.name("ReferenceNumber");
	public final static By ACTONS_HEADER = By.id("jqgh_myWorkGrid_act");
	public final static String ACTION_BTN_MYWORK = ".//*[@id='myWorkGrid']/tbody/tr[2]/td[%d]/div/button";
	public final static By ACTION_BTN= By.xpath(".//*[@id='myWorkGrid']/tbody/tr[2]/td[1]/div/button");//Krishna 4th Oct 2019
	//public final static String ACTION_BTN_MYWORK = ".//*[@id='myWorkGrid']/tbody/tr[2]/td[5][contains(text(),'%s')]/../td[1]";
	public final static String ACTION_BTN_INPROGRESS = ".//*[@id='myWorkGrid']/tbody/tr[2]/td[%d]/span[2]";	
	public final static String ACTION_LISTTAG = ".//*[@id='myWorkGrid']/tbody/tr[2]/td[%d]/div/button";
	public final static String SUBACTION_LISTTAG = "/following-sibling::ul/li/a[contains(text(),'%s')]";
	public final static String SUB_ACTION_LIST_TAG = "/../ul/li/a[contains(text(),'%s')]";
	public final static By MYWORK_DIV = By.xpath(".//*[@id='myWorkGridParent']");
	public final static By SCENARIO_BIND_POPUP = By.xpath(".//*[@id='bind-scenario-modal-content']");
	public final static By INITIATE_BIND_PROCEED_BTN = By.xpath(".//*[@id='initiate-bind-proceed']");
	public final static By ADDREMARK_TEXTAREA = By.xpath(".//*[@id='Comment']");
	public final static By ADD_BTN = By.xpath(".//*[@id='modal-add-comment']");
	public final static By MY_WORK_LINK = By.xpath(".//span[contains(text(),'My Work')]");
	public final static By MY_WORK_BUTTON = By.xpath("//ul/li[@id='header-internal-index']/a/i");//Krishna Kotha 22-June-2020
	public final static String TR_SEARCH_CLEAR = ".//*[@id='gview_myWorkGrid']//*[@class='ui-jqgrid-hdiv']//table/thead/tr[2]/th[%d]//table/tbody/tr/td[3]";

	/*
	 * Navigator General Info Page OR
	 */
	
	public final static By CARRIER = By.xpath("//span[@id='select2-CarrierId-container']");
	public final static By UW_BRANCH = By.xpath("//span[@id='select2-BranchId-container']");
	
	public final static By NYFTZ_CHECKBOX = By.id("NewYorkFreeTradeZone");
	public final static By NYFTZ_CLASSCODE = By.id("ClassCode");
	public final static By NUMBER_OF_US_EMPLOYEE = By.xpath(".//*[contains(text(),'Number of US Employees:')]/following-sibling::div/input");
	public final static By OVER_ALL_GROSS_REVENUE = By.xpath(".//label[contains(text(),'OverallGrossRevenues:')]/following-sibling::div/input");
	public final static By DO_NOT_REVENUE = By.xpath(".//*[@id='DoNotRenew']");
	public final static By NOTELIGIBLE_FOR_EXPRENEW = By.id("IsNotEligibleForExpeditedRenewal");
	public final static By FAC_APPLIES = By.xpath(".//*[@id='FacApplies']");
	
	public final static By SPECIALRISK_CODE = By.xpath("//label[contains(text(),'Special Risk Code:')]//following::div/span/span/span/span");
	public final static By EXTERNAL_REFNUMBER = By.xpath("//label[contains(text(),'External Reference Number:')]//following::div/input");
	//Krishna
	public static final By SIGNATORY = By.xpath(".//*[contains(text(),'Signatory:')]/following-sibling::div//span[@class='selection']/span/span[1]"); 
	public static final String SIGNATORY_LIST = ".//*[@class='select2-results']/ul/li[contains(text(),'%s')]";
	public static final By REVENUE = By.xpath("//*[@data-xmltag='Revenue']");
	public static final By DESCRIPTION = By.xpath("//textarea[@data-xmltag='DescriptionOfOperations']");
	public static final By PUBLIC_COMPANY = By.xpath("//*[@data-xmltag='IsPublicCompany']");
	public static final By RUN_OFF = By.xpath("//*[@data-xmltag='IsRunOff']");
	public static final By PRODUCT = By.xpath(".//*[@name='ProductId']/following-sibling::span//*[@id='select2-ProductId-container']");
	

	/****Expiring Information****/
	public final static By EXPIFNO_ADD_BTN = By.xpath(".//*[@id='expiringinformationGrid_iladd']/div");
	public final static By EXPINFO_CARRIER = By.xpath(".//*[@name='Carrier']");
	public final static By EXPINFO_POLICYNO = By.xpath(".//*[@name='PolicyReference']"); 
	public final static By EXPINFO_EFFECTIVEDATE = By.name("EffectiveDate");
	public final static By EXPINFO_EXPIRATIONDATE = By.name("ExpirationDate");
	public final static By EXPINFO_LIMIT = By.name("Limit");
	public final static By EXPINFO_ATTACHMENT = By.name("Attachment");
	public final static By EXPINFO_PREMIUM = By.name("Premium");

	/*******/
	public final static By OVERALL_GROSS_REVENUE_NP3 = By.xpath(".//*[contains(text(),'Overall Gross Revenues:')]/following-sibling::div/input");
	public final static By COMMON_LIST_GETTER = By.xpath(".//span[@class='select2-results']/ul/li[1]");
	// Old OR
	//public final static By DEPARTMENT_CODE_CONTAINER = By.xpath(".//*[@id='select2-questionid7225-container']");
	// New OR
	public final static By DEPARTMENT_CODE_CONTAINER = By.xpath(".//*[contains(text(),'Department Code:')]/following-sibling::div//span[@class='selection']/span[1]");
	//Old OR
	//public final static String DEPARTMENT_CODE_STRING = (".//*[@id='select2-questionid7225-results']/li[contains(text(),'%s')][1]");
	// New OR
	
	//   COmponent coverage TRIA 
	
	public final static By TRIA_APPLIES = By.xpath("//input[@data-comp-id='6']");
	public final static By APPLY_TRIA = By.xpath("//span[text()='Apply']");
	
	public final static By TREATY_APPLIES = By.id("TreatyApplies");//Krishna Kotha 16-oct-2019
	public final static By REASON_TREATY_DOESNOT_APPLY = By.xpath("//input[@id='ReasonTreatyDoesNotApply']");
	public final static String DEPARTMENT_CODE_STRING = ".//*[@class='select2-results']/ul/li[contains(text(),'%s')]";
	public final static By PRIMARY_LAYER = By.xpath(".//*[contains(text(),'Primary')]/preceding-sibling::input");
	public final static By OVERRIDE_GENINFO = By
			.xpath(".//*[@class='checkbox-inline'][contains(text(),'Override')]/input");
	public final static By CHECKBOX_STATUS = By.xpath(".//*[@id='QuoteBinderValidUntilDateOverride']");
	public final static By VALIDUTILDATE = By.xpath(".//*[@id='QuoteBinderValidUntilDate']");
	public final static By VALID_DATE_DONE = By
			.xpath(".//*[@class='ui-datepicker-buttonpane ui-widget-content']/*[contains(text(),'Done')]");
	public final static String VALID_DATE = ".//div[@id='ui-datepicker-div']/table/tbody/tr/td/a[contains(text(),'%s')]";
	public final static By ENDORSMENT_DESC = By.xpath(".//*[@id='EndorsementDescription']");
    
	public final static By ENDORSEMENT_EFFECTIVE_DATE = By.xpath(".//*[@id='EndorsementEffectiveDate']");
	public final static By ENDORSEMENT_EFFECTIVE_DATE_DONE = By
			.xpath(".//*[@class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all']/*[contains(text(),'Done')]");
	public final static By GENERATE_DOCS = By.xpath(".//*[@id='package-generate-docs']");
	public final static By CANCELLATION_REASON_CONTAINER = By
			.xpath(".//*[@id='select2-EndorsementCancellationReasonId-container']");
	public final static String CANCELLATION_RESON_LIST = ".//*[@id='select2-EndorsementCancellationReasonId-results']/li[contains(text(),'%s')]";
	public final static By SEARCH_BOX = By.xpath(".//*[@class='select2-search select2-search--dropdown']//input[@class='select2-search__field']");
	
	public final static By SEARCH_BOX1 = By.xpath("//*[@class='select2-search__field']");

	public final static By GROSS_REVENUE_PL = By.xpath(".//*[contains(text(),'Gross Revenue:')]/following-sibling::div/input");
	
	
	public final static By ASSUMED = By.id("choice6561");
	
	/*
	 * Navigator Broker Info Page OR
	 */

	public final static By BROKERTYPE_ID = By.xpath(".//*[@id='select2-BrokerTypeId-container']");	
	public final static By BROKERCONTACT = By.xpath(".//*[@id='select2-brokercontactmastercode-container']");
	public final static By BROKER_INPUT_TXT = By.xpath(".//input[@class='select2-search__field']");	
	public final static String BROKERTYPE_RESULT=".//ul[@id='select2-BrokerTypeId-results']/li[contains(text(),'%s')]";
	public final static String BROKERCONTACT_RESULT=".//ul[@id='select2-brokercontactmastercode-results']/li[contains(text(),'%s')]";
	public final static By COMMISSION_LINK = By.xpath(".//*[@id='initiate-commission-modal']");	//Krishna Kotha;Date:08-June-2021
	public final static By COMMISSION_TESTBOX = By.xpath(".//*[@id='commission-modal-comm-percent']");	//Krishna Kotha;Date:08-June-2021
	public final static By COMMISSION_APPLYTOALL = By.xpath(".//*[@id='commission-modal-apply-all']");	//Krishna Kotha;Date:08-June-2021
	public final static By COMMISSION_SAVE = By.xpath(".//*[@id='commission-modal-save']");	//Krishna Kotha;Date:08-June-2021
	
	//Mohammad Faisal; 01-Mar-2022
	public static final By BROKERCOMPANY = By.xpath("//*[@id='select2-editBrokersSelect-container']");
	public static final By BROKERTYPE = By.xpath("//*[@id='select2-BrokerTypeId-container']");
	public static final By NPN_FIELD = By.xpath("//*[@id='select2-npn-display-name-container']");
	public static final By NEW_NPN_LINK = By.xpath(".//*[@href='#add-npn']");
	public static final By NPN_FIRST_NAME = By.xpath("//*[@id='npnfirstnamebox']");
	public static final By NPN_MIDDLE_NAME = By.xpath("//*[@id='npnmiddleinitialbox']");
	public static final By NPN_LAST_NAME = By.xpath("//*[@id='npnlastnamebox']");
	public static final By NPN_EMAIL = By.xpath("//*[@id='npnemailbox']");
	public static final By NPN_NUMBER = By.xpath("//*[@id='npnbox']");
	
	
	/*
	 * Navigator Insured Page OR 
	 */
	public final static By SIC_CODE_ID = By
			.xpath("//label[contains(text(),'Primary SIC Code')]/following-sibling::div/span");

	public final static By PRIMARY_SIC_TEXTBOX = By.xpath(".//input[@class='select2-search__field']");

	public final static By BUSINESS_TYPE_SELECT_TAG = By.xpath(".//*[@name='BusinessTypeId']");
	public final static By BUSINESS_TYPE = By.xpath(".//*[@class='ui-jqgrid-hdiv']//tr/th/div");
	public final static String BUSINESSTYPE_SELECT = ".//*[@class='ui-jqgrid-bdiv']//tr[2]/td[%d]";
	public final static By SIC_CODE_TEXTBOX = By.xpath(".//input[@class='select2-search__field']");
	public final static String SIC_CODE_LIST = ".//ul[@class='select2-results__options']/li[contains(text(),'%s')]";
	public final static By PRIMARY_SIC_CODE = By
			.xpath("//label[contains(text(),'SIC Category')]/following-sibling::div/span");
	public final static String PRIMARY_SIC_LIST = (".//*[@class='select2-results__options']/li[contains(text(),'%s')]");

	public static final By NAICS_CODE = By
			.xpath(".//*[contains(text(),'%s')]/following-sibling::div//span[@class='selection']/span/span[1]");
	public final static By NAICS_CODE_TEXTBOX = By.xpath(".//input[@class='select2-search__field']");
	public static final String NAICS_CODE_LIST = ".//*[@class='select2-results']/ul/li[contains(text(),'%s')]";//Krishna
	
	public static final By INDUSTRY_CODE = By.xpath(".//*[contains(text(),'%s')]/following-sibling::div//span[@class='selection']/span/span[1]"); 
	public static final String INDUSTRY_CODE_LIST = ".//*[@class='select2-results']/ul/li[contains(text(),'%s')]";//Krishna
	
	public static final By COMPANY_SIZE = By.xpath(".//*[contains(text(),'%s')]/following-sibling::div//span[@class='selection']/span/span[1]"); 
	public static final String COMPANY_SIZE_LIST = ".//*[@class='select2-results']/ul/li[contains(text(),'%s')]";//Krishna
	
	public static final By TAX_DISTRICT_CODE = By.xpath("//*[@id='TaxDistrictCode']");
	
	/*
	
	 * document Review Page - OR
	 */
	public final static By ACCOUNT_STATUS = By.xpath("//ol[@class='flat-account-detail']//li[5]");
	
	public final static String SEND_TO_BROKER_CHECKBOX = ".//*[@class='tree-documents']/div/div[2]/strong[contains(text(),'%s')]//../preceding-sibling::div/label/*[@id='SendToBroker_33881']";
	public final static String VIEW_DOC_SEND_TO_BROKER = ".//*[@class='tree-documents']/div/div[2]/i[@class='fa fa-circle-thin']/../strong[contains(text(),'%s')]/preceding-sibling::a[2]";
	public final static By SEND_TO_TEXTBOX = By.xpath(".//*[@id='send-to']");
	public final static By CARBON_COPY_TEXTBOX = By.xpath(".//*[@id='carbon-copy']");
	public final static By RELEASE_BTN = By.xpath(".//*[@id='doc-review-release']");
	public final static By VIEW_YOUR_ACCOUNTS = By.xpath("//*[@id='modal-releasing-continue']");
	public final static By REVIEWED_DOCUMENT = By.xpath(".//*[@id='ReviewCheck']");
	public final static By MAKECHANGES = By.xpath(".//*[@id='doc-review-make-changes']");
	public final static By SEND_FOR_REVIEW = By.xpath(".//*[@id='doc-review-send-for-review']");
	public final static By MYWORK_GRID = By.xpath(".//*[@id='myWorkGridParent']");
	public final static By VIEW_LINK = By.xpath(".//*[@class='tree-documents']/div/div[2]/i[@class='fa fa-circle-thin']/../a[contains(text(),'View')]");//krishna 5th- March-2020
	public final static By VIEW_DOC_LIST = By.xpath(".//*[@class='tree-documents']/div/div[2]/i[@class='fa fa-circle-thin']/../strong/preceding-sibling::a[2]");
	public final static By REVIEWER_CONTAINER = By.xpath(".//*[@id='select2-ReviewerId-container']");
	public final static By REVIEWER_TEXTBOX = By.xpath(".//input[@class='select2-search__field']");
	public final static String REVIEWER_LIST = ".//*[@id='select2-ReviewerId-results']/li[contains(text(),'%s')]";
	public final static By DOCUMENT_VIEW_STATUS = By.xpath(".//*[@class='tree-documents']/div/div[2]/i[@class='fa fa-circle-thin']/../strong");
	public final static By VIEW_ACCOUNT_BTN = By.xpath(".//*[@id='modal-releasing-continue']");
	
	public final static By APPROVER_CONTAINER = By.xpath("//span[@id='select2-ApprovedBy-container']");
	public final static By APPROVER_TEXTBOX = By.xpath("//input[@class='select2-search__field']");
	public final static String APPROVER_LIST = ".//*[@id='select2-ApprovedBy-results']/li[contains(text(),'%s')]";
	
	public final static By APPROVED_DATE = By.xpath("//input[@id='DateApproved']");
	public final static String APPROVED_DATE_LIST = ".//*[@class='ui-datepicker-calendar']//tr/td/a[contains(text(),'%d')]";
	

	/*****NP3*************************/

	/*
	 * Component and Coverage Page
	 */

	public final static By POLLUTION_LEGAL_LIABILITY_TR=By.xpath(".//*[@id='pollutionlegalliabilityParent']//*[@class='ui-jqgrid-bdiv']//tr");
	public final static By POLLUTION_LEGAL_LIABILITY = By.xpath(".//*[@id='pollutionlegalliabilityParent']//*[@class='ui-jqgrid-hdiv']//tr/th/div");
	public final static String POLL_LEGAL_LIABILITY_EACH_ROW = ".//*[@id='pollutionlegalliabilityParent']//*[@class='ui-jqgrid-bdiv']//tr[%d]";
	public final static String POLL_LEGAL_LIAB_EACH_TBL_DATA = "/td[%d]";
	/** Coverage: Contractor Pollution Liability**/
	public final static By LIMITS_TBL_TR_LIST = By.xpath(".//*[@data-grid-caption='Limits & Deductibles']//*[@class='ui-jqgrid-bdiv']//tr");
	public final static String LIMITS_TR = ".//*[@data-grid-caption='Limits & Deductibles']//*[@class='ui-jqgrid-bdiv']//tr[%d]";
	public final static By DELETE_BTN = By.xpath(".//*[@id='del_btn']/div");
	public final static By EXPOSURE = By.xpath(".//li/a[contains(text(),'Exposures')]");
	
	
	//EXCESS-Integrated
	public final static By EXCESS_INTEGRATED_COPOMENT = By.xpath("//legend[contains(text(),'Excess Integrated')]/following::span[contains(text(),'Select a Coverage')][1]");
	public final static By EXCESS_ADD_BUTTON = By.xpath("//legend[contains(text(),'Excess Integrated')]//following::span[8]");
	
	public final static By EXCESS_INTEGRATED_HEADER = By.xpath("//*[@id='excessintegratedParent']//*[@class='ui-jqgrid-hdiv']//tr/th/div");
	public final static By EXCESS_INTEGRATED_ROWS= By.xpath("//*[@id='excessintegratedParent']//*[@class='ui-jqgrid-bdiv']//tr");
	public final static String EXCESS_INTEGRATED_ROW_INDEX= "//*[@id='excessintegratedParent']//*[@class='ui-jqgrid-bdiv']//tr[%d]";
	public final static String EXCESS_INTEGRATED_EACH_DATA_INDEX =  "/td[%d]";
	
	
	
	//Author Krishna Kotha;Date:05-Sep-2019
	public final static By CARGO = By.xpath("//div[@id='gview_cargo']/div[@class='ui-jqgrid-hdiv']//tr/th/div");
	public final static By CARGO_TR=By.xpath("//div[@id='gview_cargo']/div[@class='ui-jqgrid-bdiv']//tr");
	public final static String CARGO_EACH_ROW = "//div[@id='gview_cargo']/div[@class='ui-jqgrid-bdiv']//tr[%d]";
	public final static String CARGO_EACH_TBL_DATA = "/td[%d]";
	
	/*
	 * Renewal Submission
	 */

	public final static By SUBMISSION_TYPE_REN_CHCKBOX= By.xpath(".//*[@id='SubmissionTypeRenew']");
	public final static By EXPIRING_INFO_BTN = By.xpath(".//*[@id='get-expiring-info']");
	public final static By RENEWAL_SEARCH = By.xpath(".//*[@id='renewal-search']");
	public final static By RENEWAL_SEARCH_TEXT = By.xpath(".//*[@id='renewal-search-text']");
	public final static By POLICY_RESULT_TR = By.xpath(".//*[@id='gview_RenewalClearanceGrid']//*[@class='ui-jqgrid-bdiv']//tr[2]");
	public final static By HEADER_LIST = By.xpath(".//*[@class='ui-jqgrid-hdiv']//th/div");
	public final static String VERIFED_ASSOCIATED_LINK = ".//*[@id='accountsetupgrid']//tr[%d]";
	public final static String VERFIED_ASSOCIATED_TD = "/td[%d]";
	public final static By VERIFIED_ASSOCIATED_TR = By.xpath(".//*[@id='accountsetupgrid']//tr");
	public final static By SAVE_AND_VERIFY_ANOTHER_BTN = By.xpath(".//*[@id='verify-insured-modal-save-add']");
	public final static By SAVE_AND_CLOSE_BTN = By.xpath(".//*[@id='verify-insured-modal-save-close']"); 
	public final static By NEW_INSURED_RADIO_BTN = By.xpath(".//*[@id='PisInsuredSelect']");


	/************************ NP3 Limit Deductible Pollution Liability for Transportation Activity **/

	public final static By LIMIT_TBL_TR_LIST = By.xpath(".//*[@id='limitDeductibleGrid']//tr");
	public final static String LIMIT_TBL_TR = ".//*[@id='limitDeductibleGrid']//tr[%d]";

	public final static By NOT_RATED = By.xpath(".//button[contains(text(),'Not rated')]");
	
	
	public final static By IMAGE_RIGHT_ERR = By.xpath("//div[text()='ImageRight file is locked. You must unlock the task in ImageRight before releasing']");
	//Forms And Endorsment
	/*****************************************/

	public final static By FILLINS_EDITLINK = By.xpath(".//*[@id='selectedGrid']//tr/td[contains(text(),'Incomplete')]/../td[contains(text(),'Edit')]");
	//1-09-2019

	public final static By VIEWLINK = By.xpath(".//*[@id='selectedGrid']/tbody/tr[3]//following-sibling::td[contains(text(),'View')]");
	
	public final static By CLOSE = By.xpath("//button[text()='Close']");
	
	
	public final static String COMMON_SELECT_RESULTS_GRID_LIST = ".//span[@class='select2-results']/ul/li[contains(text(),'%s')]";

	//02-02-2019
	//Endorsement Section OR :
	public final static By ENDORSEMENT_EFFECTIVEDATE = By.xpath(".//*[@id='EndorsementEffectiveDate']");

	//02-25-2019
	public final static By EXPIRINGINFO_ADDING_BUTTON = By.xpath(".//*[@id='expiringinformationGrid_iladd']/div");
	public final static By GENERALINFO_CARRIER = By.name("Carrier");
	public final static By GENERALINFO_POLICYREF = By.name("PolicyReference");
	public final static By GENERALINFO_CURRENCY = By.name("CurrencyId");

	/*******Adding New Broker Account*******/

	public final static By BROKER_CONTACT = By.xpath(".//*[@id='broker-contact-add']");
	public final static By FIRSTNAME = By.xpath(".//*[@id='firstnamebox']");
	public final static By LASTNAME = By.xpath(".//*[@id='lastnamebox']");
	public final static By EMAIL = By.xpath(".//*[@id='emailbox']");
	public final static By PHONE = By.xpath(".//*[@id='phonebox']");
	public final static By COMPANY_ADD = By.xpath(".//*[@id='companyaddressbox']");
	public final static By CITY = By.xpath(".//*[@id='citybox']");
	public final static By POSTAL_CODE = By.xpath(".//*[@id='postalbox']");	
	public final static By COUNTRY = By.xpath(".//*[@id='countrylookup']");
	public final static By SAVE_CHANGE = By.xpath(".//*[@id='edit-brokercontact-modal-submit']");	
	
	/****** Alert Pop up*******/
	public final static By CLOSE_ALERT = By.xpath("//a[@class='close']");
	
	/*Left Navigation for EXC*/
	
	public final static By LEFT_NAV_LIST = By.xpath("//li//a//span[@class='pop-menu-header']");
	public final static String LEFT_NAV_LIST_NAMES = "//li[%d]//a//span[@class='pop-menu-header']";
	
	//Buttons at Bottom of page
	public static final By SAVE_BUTTON_BOTTOM = By.xpath("//*[@id='coverage-display-save-bottom']");
	public static final By RATE_BUTTON_BOTTOM = By.xpath("//*[@id='coverage-display-save-bottom']/preceding-sibling::div/button[1]");
	public static final By GOTO_BUTTON_BOTTOM = By.xpath("//*[@id='coverage-display-save-bottom']/following-sibling::div/button[1]");
	
	//Top Navigation
	public static final String TOP_NAVIGATION_PAGE = "//*[@id='layout-container-tabs']//*[contains(text(),'%s')]";
	
	/*Request Policy Renewal*/
	public final static By REQ_POLICY_REN = By.xpath(".//span[contains(text(),'Request Policy Renewal')]");
	public final static By PRODUCT_ID = By.xpath(".//select[@id='rrmRenewalsProductId']");
	public static final By REFERENCE_NUMBER = By.xpath(".//input[@id='rrmRenewalsReferenceNumber']");
	public static final By INSURED_NAME = By.xpath(".//input[@id='rrmRenewalsInsuredName']");
	public static final By EFFECTIVE_DATE = By.xpath(".//input[@id='effectiveDate']");
	public static final By EXPIRY_DATE = By.xpath(".//input[@id='expiryDate']");
	public static final By COUNTRY_CONTAINER = By.xpath(".//select[@id='countryLookup']");
	public static final By STATE = By.xpath(".//select[@id='stateLookup']");
	public static final By REQ_POLICY_REN_SUBMIT = By.xpath(".//*[@id='rrmRenewals-getPolicy-submit']");
	public static final By VISION_CONV_STATUS = By.xpath(".//*[@id='rrmRenewalsGetPolicyResult']/li");
	public static final By PRODUCT_CODE = By.xpath(".//select[@id='productCodeLookup']");
	public static final By DEPARTMENT = By.xpath(".//select[@id='departmentLookup']");
	public static final By POLICY_REF_NUMBER = By.xpath(".//input[@id='PolicyReference']");
	public static final By CARRIER_SELECT_BOX = By.xpath("//*[@id='select2-carrierLookup-container']");
	public static final By UNDERWRITER_SELECT_BOX = By.xpath("//*[@id='select2-underwriterLookup-container']");
	public static final By UNDERWRITER_DROPDOWN_BOX =  By.xpath(".//select[@id='underwriterLookup']");
	public static final By DEPARTMENT_SELECT_BOX = By.xpath("//*[@id='select2-departmentLookup-container']");
	public static final By INDUSTRY_CLASS =  By.xpath(".//select[@id='industryClassLookup']");
	public static final By PRIMARY_EXCESS =  By.xpath("//*[@name='primaryExcessId']");
	public static final By BROKER_CONTACT_CONTAINER =By.xpath(".//*[@id='select2-brokerContactSelect-container']");
	public static final String BROKER_CONTACT_RESULT_TEXTSEARCH = ".//*[@id='select2-brokerContactSelect-results']/li[contains(text(),'%s')][1]";
	public static final By BROKER_CONTAINER = By.xpath(".//*[@id='select2-brokerSelect-container']");
	public static final String BROKER_RESULT_TEXTSEARCH =".//*[@id='select2-brokerSelect-results']/li[contains(text(),'%s')][1]";
	public static final By WINS_PSUBM_NUMBER = By.xpath(".//input[@id='WinsSubmissionNumberForRenewal']");
	public static final By REQ_POLICY_SUBMIT = By.xpath(".//button[@id='rrmRenewals-Policy-submit']");
	
}
