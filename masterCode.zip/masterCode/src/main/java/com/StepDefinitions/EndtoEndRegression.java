package com.StepDefinitions;

import com.BusinessComponents.Glass_Ascend_FL.FL_QuoteIssued;
import com.BusinessComponents.Glass_Ascend_NonFL.BinderIssued;
import com.BusinessComponents.Glass_Ascend_NonFL.EndToEndRegression;
import com.BusinessComponents.Glass_Ascend_NonFL.NavigatorLogin;
import com.BusinessComponents.Glass_Ascend_NonFL.PolicyIssued;
import com.BusinessComponents.Glass_Ascend_NonFL.QuoteIssued;
import com.SeleniumUtils.SeleniumUtils;
import com.SeleniumUtils.TestDataManager;
import com.TestBase.TestBase;
import com.cucumber.listener.Reporter;

import cucumber.api.java.en.*;

public class EndtoEndRegression extends SeleniumUtils {
	
	private int _issuedFlag = 1;
 
	public TestDataManager _testDataManage = new TestDataManager();	
	
	EndToEndRegression EndToEndRegression_obj= new EndToEndRegression(TestBase.driver,_testDataManage);
	
	QuoteIssued _nonFLNbQuoteIssue = new QuoteIssued(TestBase.driver,_testDataManage);
	FL_QuoteIssued _finLinesNbQuoteIssue = new FL_QuoteIssued(TestBase.driver,_testDataManage);
	BinderIssued _binderIssued = new BinderIssued(TestBase.driver,_testDataManage);
	PolicyIssued _policyIssued = new PolicyIssued(TestBase.driver,_testDataManage);	
	
	@Given("Performed the EndtoEndTest for Quote,Binder, Policy for all LOB")
	 public void Navigate_To_Navigator() throws Exception
	{		
		System.out.println("call");
		EndToEndRegression_obj.testEndToEndRegression();
		Reporter.addStepLog("*******testEndToEndRegression********");	  
	}
	
	@Then("Issue Quote for New Business Account")
	 public void issue_NB_Quote() throws Exception
	{		
		String QI_Flag = _testDataManage.getData("UserFlags", "QI_Flag");
		if (QI_Flag.equalsIgnoreCase("Yes")) {
			System.out.println("call");
			String insProduct = _testDataManage.getData("GenericData", "Insurance Product");
			if (insProduct.equalsIgnoreCase("Financial Lines")) {
				_finLinesNbQuoteIssue.setQuoteIssuedForAll("S", _issuedFlag);
			}
			else {
				_nonFLNbQuoteIssue.setQuoteIssuedForAll("S", _issuedFlag);
			}			
		}
		else {
			Reporter.addStepLog("NB Quote Issue flag is NOT switched on. Hence skippig this step");
		}
			  
	}
	
	@Then("Issue Binder for New Business Account")
	 public void issue_NB_Binder() throws Exception
	{	
		String BI_Flag = _testDataManage.getData("UserFlags", "BI_Flag");
		if (BI_Flag.equalsIgnoreCase("Yes")) {
			System.out.println("call");
			String insProduct = _testDataManage.getData("GenericData", "Insurance Product");
			if (insProduct.equalsIgnoreCase("Financial Lines")) {
				_binderIssued.setBinderIssuedForAllLOBs("QI", _issuedFlag, "New");
			}
			else {
				
			}		
			
		}
		else {
			Reporter.addStepLog("NB Binder Issue flag is NOT switched on. Hence skippig this step");
		}
			  
	}
	
	@Then("Issue Policy for New Business Account")
	 public void issue_NB_Policy() throws Exception
	{		
		String PI_Flag = _testDataManage.getData("UserFlags", "PI_Flag");
		if (PI_Flag.equalsIgnoreCase("Yes")) {
			System.out.println("call");
			String insProduct = _testDataManage.getData("GenericData", "Insurance Product");
			if (insProduct.equalsIgnoreCase("Financial Lines")) {
				_policyIssued.setPolicyIssuedForFL("BI", _issuedFlag);
			}
			else {
				
			}
		}
		else {
			Reporter.addStepLog("NB Policy Issue flag is NOT switched on. Hence skippig this step");
		}
		  
	}
    
	@Then("set the PolicyEndorsed for all LOB")
	public void setPolicyEndored() throws Exception
	{   
		String PE_Flag = _testDataManage.getData("UserFlags", "PE_Flag");
		if (PE_Flag.equalsIgnoreCase("Yes")) {
			Reporter.addStepLog("*******setPlocyEndoresed********");
			EndToEndRegression_obj.testPI_PE();
		}
		else {
			Reporter.addStepLog("Policy Endorse flag is NOT switched on. Hence skippig this step");
		}		
	}
   @Then("Performed the Renewal")
   public void testRenewel() throws Exception
   {
	   EndToEndRegression_obj.testRenewal();
   }
   
   @Then("Perform Renewal GLASS Submission")
   public void issue_Ren_Submission() throws Exception
   {
	   String Ren_Sub_Flag = _testDataManage.getData("UserFlags", "Ren_Sub_Flag");
	   if (Ren_Sub_Flag.equalsIgnoreCase("Yes")) {
		   Reporter.addStepLog("Renewal Submission");
		   EndToEndRegression_obj.testRenGlassSubmission();
	   }
	   else {
		   Reporter.addStepLog("Renewal GLASS Submission flag is NOT switched on. Hence skippig this step");
	   }
   }
   
   @Then("Issue Renewal Quote")
   public void issue_Ren_Quote() throws Exception
   {
	   String Ren_QI_Flag = _testDataManage.getData("UserFlags", "Ren_QI_Flag");
	   if (Ren_QI_Flag.equalsIgnoreCase("Yes")) {
		   Reporter.addStepLog("Renewal Quote");
		   EndToEndRegression_obj.testRenQuoteIssue();
	   }
	   else {
		   Reporter.addStepLog("Renewal Quote Issue flag is NOT switched on. Hence skippig this step");
	   }	  
   }
   
   @Then("Issue Renewal Binder")
   public void issue_Ren_Binder() throws Exception
   {
	   String Ren_BI_Flag = _testDataManage.getData("UserFlags", "Ren_BI_Flag");
	   if (Ren_BI_Flag.equalsIgnoreCase("Yes")) {
		   Reporter.addStepLog("Renewal Binder");
		   EndToEndRegression_obj.testRenBinderIssue();
	   }
	   else {
		   Reporter.addStepLog("Renewal Binder Issue flag is NOT switched on. Hence skippig this step");
	   }
   }
   
   @And("Issue Renewal Policy")
   public void issue_Ren_Policy() throws Exception
   {
	   String Ren_PI_Flag = _testDataManage.getData("UserFlags", "Ren_PI_Flag");
	   if (Ren_PI_Flag.equalsIgnoreCase("Yes")) {
		   Reporter.addStepLog("Renewal Policy");
		   EndToEndRegression_obj.testRenPolicyIssue();
	   }
	   else {
		   Reporter.addStepLog("Renewal Policy Issue flag is NOT switched on. Hence skippig this step");
	   }
	   
   }
   
	// Krishna Kotha Date:18-June-2021
	@Then("^Performed Policy Issued on Add Layer$")
	public void testEndToENdForAddLayerAccount() throws Exception {
		NavigatorLogin US_NavigatorLogin_Obj = new NavigatorLogin(TestBase.driver, _testDataManage);
		US_NavigatorLogin_Obj.navigateLogin();
		String addLayerFlag = _testDataManage.getData("GenericData", "AddLayerFlag");
		if ("Yes".equalsIgnoreCase(addLayerFlag)) {
			EndToEndRegression_obj.testEndToEndRegression();
		} else {
			System.out.println("AddLayerFlag given as No in Test data sheet. Hence this method not executed..!");
		}
	}
	
	@Then("^Issue Quote for Ventilated Policy$")
   public void issue_Quote_Ventilated_Policy() throws Exception
   {
	   String Vent_QI_flag = _testDataManage.getData("UserFlags", "Vent_QI_flag");
	   if (Vent_QI_flag.equalsIgnoreCase("Yes")) {
		   Reporter.addStepLog("Quote for Ventilated Policy");
		   _finLinesNbQuoteIssue.setQuoteIssuedForVentilatedP("S", _issuedFlag);
	   }
	   else {
		   Reporter.addStepLog("Ventilated Policy Issue flag is NOT switched on. Hence skippig this step");
	   }
   }
   
   @Then("^Issue Binder for Ventilated Policy$")
   public void issue_Binder_Ventilated_Policy() throws Exception
   {
	   String Vent_BI_flag = _testDataManage.getData("UserFlags", "Vent_BI_flag");
	   if (Vent_BI_flag.equalsIgnoreCase("Yes")) {
		   Reporter.addStepLog("Binder for Ventilated Policy");
		   _binderIssued.setBinderIssuedForVentilatedP("QI", _issuedFlag, "New");
	   }
	   else {
		   Reporter.addStepLog("Ventilated Policy Issue flag is NOT switched on. Hence skippig this step");
	   }
   }
   
   @Then("^Issue Policy for Ventilated Policy$")
   public void issue_Policy_Ventilated_Policy() throws Exception
   {
	   String Vent_PI_flag = _testDataManage.getData("UserFlags", "Vent_PI_flag");
	   if (Vent_PI_flag.equalsIgnoreCase("Yes")) {
		   Reporter.addStepLog("Policy for Ventilated Policy");
		   _policyIssued.setPolicyIssuedForVentilatedP("BI", _issuedFlag);
	   }
	   else {
		   Reporter.addStepLog("Ventilated Policy Issue flag is NOT switched on. Hence skippig this step");
	   }
   }

//   =========================================================================================================================================================
}
