/*
 * Author - Chandni  Dulani
 * Date - 2-DEC-2020
 * Purpose- Executed Before an dAfter the Every Scenario.. 
 */

package com.StepDefinitions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.google.common.io.Files;
import org.junit.Assume;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

import com.Rally.CreateNewTestCase;
import com.Rally.RunTestCaseAndUpdateTestResults;
import com.SeleniumUtils.TestDataManager;
import com.TestBase.TestBase;
import com.cucumber.listener.Reporter;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks {

	public static TestBase testBase;
	public String ScenarioName;
	public String TestCaseName;
	public TestDataManager testDataManager = new TestDataManager();	
	public static FileOutputStream fos = null;
	public static XWPFDocument doc = null;
	public static XWPFParagraph paraTitle = null;
	public static XWPFRun paraRun = null;
	public static Scenario scenario;
	public String lob;  
	/*
	 * Author - Chandni Dulani Date - 2-DEC-2020 Purpose- Initialize the Broswer.
	 */

	@Before
	public void initializeTest(Scenario scenario) throws Exception {
		String sName = scenario.getName();
	    initiateKCD();
//		Reporter.assignAuthor("Created BY - Chandni Dulani");
		Reporter.assignAuthor("McKinsey Automation Initiatives");
		Reporter.addScenarioLog(sName + " begins");
		System.out.println(System.getProperty("CucumberScenarioName"));
		if (!sName.equalsIgnoreCase((System.getProperty("CucumberScenarioName")))) {
//			Reporter.addScenarioLog("Custom Test Runner executes the entire Feature file. "
//					+ "\n"
//					+ "So skipping " + sName + " as it's not needed to be executed as part of this test case");			
			Assume.assumeTrue(false);
		}
		else {
			setSystemArguments();
			invokeTestCaseDataSheet();
			invokeBrowser();
			System.out.println("Begin");
			lob = testDataManager.getData("GenericData", "Three Letter code");			
			System.out.println(scenario.getName());
		}	
		System.out.println(scenario.getName());

	}

	private void setSystemArguments() throws Exception {

		System.out.println(System.getProperty("TestCaseName"));
		System.out.println(System.getProperty("TestcaseDescription"));
		System.out.println(System.getProperty("TestScenarioName"));
		System.out.println(System.getProperty("CucumberScenarioName"));
		System.out.println(System.getProperty("Browser"));
		System.out.println(System.getProperty("SystemName"));
		System.out.println(System.getProperty("PortNo"));
		System.out.println(System.getProperty("KCD"));
		System.out.println(System.getProperty("KCD_Flag"));
		System.out.println(System.getProperty("TestDataPath"));

	}

	private void invokeTestCaseDataSheet() throws Exception {

		String scenarioSheetPath = System.getProperty("ApplicationURL") + System.getProperty("ApplicationName") + "\\" + System.getProperty("TestScenarioName") + ".xls";
		System.out.println(scenarioSheetPath);
		System.setProperty("DBPath", scenarioSheetPath);
		this.testDataManager.initializeTestData(System.getProperty("TestCaseName"), "Buisness Flow", scenarioSheetPath.replaceFirst("/", ""));

		System.out.println("Executing test case " + System.getProperty("TestCaseName"));

	}

	private void invokeBrowser() throws Exception {

		TestBase.selectBrowser(System.getProperty("Browser"));

	}
	
		
	public void initiateKCD() throws IOException {
		doc = new XWPFDocument();
		paraTitle = doc.createParagraph();
		paraTitle.setAlignment(ParagraphAlignment.CENTER);
		paraRun = paraTitle.createRun();
		paraRun.setBold(true);
		paraRun.setColor("000080");
		paraRun.setFontFamily("Verdana");
		paraRun.setFontSize(15);
		paraRun.setUnderline(UnderlinePatterns.SINGLE);
		paraRun.setText("This doc explains Business/Application flow of feature: " +System.getProperty("TestScenarioName"));
	    
		
		//kc.KCD_AppDetails(testDataManager.getData("KCD_Page", "Application_Details_Header"),testDataManager.getData("KCD_Page", "Application_Details"));
	}
	
	
	/*
	 * Author - Chandni Dulani Date - 2-DEC-2020 Purpose- Capture Screenshot and
	 * Closed the browser.
	 */
	@After
	public void endTest(Scenario scenario) throws IOException {
		if (TestBase.driver != null) {
			String scenarioName = scenario.getName();
            if (scenarioName.equalsIgnoreCase((System.getProperty("CucumberScenarioName")))) {
            	System.setProperty("ScenarioName", scenarioName);
    			captureScreenshotIfScenarioFailed(scenario);
    			rallyConfiguration(scenario);
            }
			
		}
	}

	public void captureScreenshotIfScenarioFailed(Scenario scenario) {

		if (scenario.isFailed()) {
			String screenshotName = scenario.getName().replaceAll(" ", "_");
			System.out.println(screenshotName);
			try {

				final byte[] screenshot = ((TakesScreenshot) TestBase.driver).getScreenshotAs(OutputType.BYTES);
				scenario.embed(screenshot, "image/png"); // ... and embed it in

				File sourcePath = ((TakesScreenshot) TestBase.driver).getScreenshotAs(OutputType.FILE);
				File destinationPath = new File(
						System.getProperty("user.dir") + "/target/" + screenshotName + " - " + timestamp() + ".png");
				File alternateDestinationPath = new File(
						System.getProperty("user.dir") + "/target/Extent/" + screenshotName + " - " + timestamp() + ".png");
				// Copy taken screenshot from source location to destination location
				Files.copy(sourcePath, destinationPath); // This attach the specified
				Files.copy(sourcePath, alternateDestinationPath);
				Reporter.addScreenCaptureFromPath(destinationPath.toString());
			} catch (WebDriverException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		} else {
			try {
				System.out.println("Sceanrio Passed: "+scenario.getName());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			try {
				writeToFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		TestBase.driver.quit();
	}

	// Krishna Kotha; Date:07-June-2021
	public void rallyConfiguration(Scenario scenario) {
		

		try {
			String rallyReportFlag = testDataManager.getData("Rally_TestData", "IntegrateRally");
			String createNewTestcase = testDataManager.getData("Rally_TestData", "Create_NewTestCase");
			String updateTestcaseResult = testDataManager.getData("Rally_TestData", "Update_TestcaseResult");
			
			if (rallyReportFlag.equalsIgnoreCase("Yes")) {
				if (createNewTestcase.equalsIgnoreCase("Yes")) {
					CreateNewTestCase newTestcase = new CreateNewTestCase();
					newTestcase.createTestCaseforUserStory();
				} else {
					System.out.println("User has given flag as NO to create new test case in Rally. If you want to create, please update required testdata.!");
					//Reporter.addStepLog("User has given flag as NO, to create new test case. If you want ro create, please update required testdata.!");
				}
				String scenarioStatus = scenario.getStatus(); 
				if (scenarioStatus.equalsIgnoreCase("Passed")) {
					if (updateTestcaseResult.equalsIgnoreCase("Yes")) {
						RunTestCaseAndUpdateTestResults testCaseRun = new RunTestCaseAndUpdateTestResults();
						testCaseRun.testcaseResultUpdate("Pass");
					} else {
						System.out.println("User has given flag as NO, for Rally configuration. If you want ro Update test case result in Rally Please update required testdata.!");
						Reporter.addStepLog("User has given flag as NO, for Rally configuration. If you want ro Update test case results in Rally Please update required testdata.!");
					}
				} else {
					if (updateTestcaseResult.equalsIgnoreCase("Yes")) {
						RunTestCaseAndUpdateTestResults testCaseRun = new RunTestCaseAndUpdateTestResults();
						testCaseRun.testcaseResultUpdate("Fail");
					} else {
						System.out.println("User has given flag as NO, to Run and Update test case results..!");
						Reporter.addStepLog("User has given flag as NO, to Run and Update test case results..!");
					}
					/*Not required create defect as of now hence commented below code.
					 * String createNewDefect = testDataManager.getData("Rally_TestData",
					 * "Create_NewDefect"); if (createNewDefect.equalsIgnoreCase("Yes")) { 
					 * CreateNewDefectWithAttachment createDefect = new
					 * CreateNewDefectWithAttachment();
					 * createDefect.createDefectWithReportAttachment(); }
					 */ 
				}
			}else {
				System.out.println("User has given flag as NO, for Rally configuration. If you want ro create test case in Rally Please update required testdata.!");
				Reporter.addStepLog("User has given flag as NO, for Rally configuration. If you want ro create test case in Rally Please update required testdata.!");
			}
			Thread.sleep(4000);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public static String timestamp() {
		return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date());
	}
	
	public void writeToFile() throws IOException {
		//fos = new FileOutputStream(System.getProperty("user.dir") + "/target/" +System.getProperty("TestScenarioName")+".docx");		
		
		String KCDMainFlag=System.getProperty("KCD_Flag");
		String KCDSubFlag=System.getProperty("KCD_SubFlag");
		System.out.println(KCDMainFlag);
		System.out.println(KCDSubFlag);
		System.out.println(System.getProperty("TestScenarioName"));
		if(KCDMainFlag.equalsIgnoreCase("YES")) {
			
			if(KCDSubFlag.equalsIgnoreCase("YES")) {
				fos = new FileOutputStream(System.getProperty("user.dir") + "/target/" +System.getProperty("TestScenarioName")+".docx");
				doc.write(fos);
				fos.close();
			}
		
		}

		doc.close();
	}

}
