$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("GlassSubmission.feature");
formatter.feature({
  "line": 1,
  "name": "To Perfomed the Glass SUbmission",
  "description": "",
  "id": "to-perfomed-the-glass-submission",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Validate Glass Submission",
  "description": "",
  "id": "to-perfomed-the-glass-submission;validate-glass-submission",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@GlassSubmission"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User Navigate to Glass",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User clicks on SetUp New Account",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "User enter the temp id",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "User select the Insurance Product from Drop Down",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "user Select the three Letter code",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "User Select  the underwriter",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "User select the Broker  and Broker Contact  from Drop Down",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "User select the Inception and ExpireDate",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "User Add the New Insured",
  "keyword": "Then "
});
formatter.step({
  "line": 14,
  "name": "User Add the Insured Address",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "User click on Triage button",
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "Click on Continue",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "User Click on NameInsured Clearence Page",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "User Continue on Gernal Info Page",
  "keyword": "Then "
});
formatter.step({
  "line": 19,
  "name": "User Choose the ClearedSubmission",
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "Click on Finish button",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "Validate Submission is created successfully on Glass",
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "Close the browser",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});